/* SING_SHOW — SILNIK (ukryte okno). Jedyny właściciel stanu live'a.
   Wejścia: eventy TikTok (tiktok-event), donejty (tipped-donation), komendy z okien (engine-cmd).
   Wyjście: api.statePublish(state) → main → widgety (HTTP) + okna (IPC "state").
   Tu żyje: playlista + tapy + odblokowania, armata giftów, donejty + lektor, RANKING-HYBRYDA,
   dźwięki (powiadomienie/odblokowanie/armata/muzyka/podkłady), sesja, tryb demo.
*/
(() => {
  const api = window.api;
  const now = () => Date.now();
  const uid = (p = "x") => p + now().toString(36) + Math.random().toString(36).slice(2, 7);
  const clamp01 = (v) => Math.max(0, Math.min(1, Number(v) || 0));

  // ====== STAN ======
  const S = {
    profile: null,
    tiktok: { connected: false, connecting: false, username: "", viewerCount: 0, reason: "" },
    session: { startedAt: now(), demo: false },
    playlist: { items: [], nowId: null, name: "" },
    taps: { session: 0, progress: 0, unlockCount: 0, sinceUnlock: new Map() },
    unlock: { lastAt: 0, title: "", artist: "", by: "" },
    cannon: { charge: 0, shots: 0, fireAt: 0, lastBy: "", contrib: new Map(), items: [], plug: null, lastBlast: null },
    donations: [],
    alert: null,
    funds: { total: 0, byGoal: {}, donors: new Map() },
    ranking: new Map(),      // key → { nick, pts }
    boosts: new Map(),       // key → until(ms)
    top1: null,
    giftFeed: [],
    events: [],
    backing: { file: null, playing: false, pos: 0, dur: 0, volume: 0.8, itemId: null },
    ttsState: { speaking: false, queued: 0 },
    hint: null,              // krótki komunikat dla czytnika { text, at }
  };

  // ====== RANKING — HYBRYDA (formuła 1:1 z KVRINA_SHOW) ======
  const W_SHARE = 50, W_FOLLOW = 30, W_CHAT = 1, TAPS_PER_POINT = 5;
  const BOOST_MIN_COINS = 100, BOOST_MS = 3 * 60 * 1000, BOOST_MULT = 1.10;
  const RANKING_MAX = 2000, RANKING_KEEP = 1000;

  function keyOf(nick) {
    return String(nick || "").normalize("NFD").replace(/[̀-ͯ]/g, "").replace(/ł/g, "l").toLowerCase().replace(/\s+/g, " ").trim();
  }
  function nickOf(p) {
    const n = (p && (p.nickname || p.displayName || p.uniqueId || p.user && (p.user.nickname || p.user.uniqueId))) || "";
    return String(n).trim() || "TT_Anon";
  }
  function likeDelta(p) {
    for (const k of ["likeCount", "likes", "count", "amount", "repeatCount", "delta", "value"]) {
      const n = Number(p && p[k]);
      if (Number.isFinite(n) && n > 0 && n < 1e6) return n;
    }
    return 1;
  }
  function maybeBoost(nick, coins) {
    if ((Number(coins) || 0) < BOOST_MIN_COINS) return;
    const k = keyOf(nick); if (!k) return;
    S.boosts.set(k, now() + BOOST_MS);
  }
  function multFor(nick) {
    const k = keyOf(nick); if (!k) return 1;
    const until = S.boosts.get(k); if (!until) return 1;
    if (now() >= until) { S.boosts.delete(k); return 1; }
    return BOOST_MULT;
  }
  function addPoints(nick, pts, label) {
    const k = keyOf(nick); const p = Number(pts) || 0;
    if (!k || !p) return;
    const cur = S.ranking.get(k) || { nick, pts: 0 };
    cur.nick = nick; cur.pts += p;
    S.ranking.set(k, cur);
    if (S.ranking.size > RANKING_MAX) {
      const top = Array.from(S.ranking.entries()).sort((a, b) => b[1].pts - a[1].pts).slice(0, RANKING_KEEP);
      S.ranking = new Map(top);
    }
    pushEvent({ type: "pkt", nick, points: p, label });
  }
  function award(nick, base, label) { addPoints(nick, base * multFor(nick), label); }
  function rankingTop(n = 20) {
    const arr = Array.from(S.ranking.values()).map((r) => ({ nick: r.nick, points: Math.round(r.pts) }));
    arr.sort((a, b) => b.points - a.points || String(a.nick).localeCompare(String(b.nick), "pl"));
    return arr.slice(0, n);
  }

  function pushEvent(ev) { S.events.unshift({ ts: now(), ...ev }); if (S.events.length > 80) S.events.length = 80; }

  // ====== PLAYLISTA ======
  const P = () => S.profile || {};
  function items() { return S.playlist.items; }
  function nowItem() { return items().find((i) => i.id === S.playlist.nowId) || null; }
  function pending() { return items().filter((i) => i.status !== "done" && i.status !== "skipped" && i.id !== S.playlist.nowId); }
  function nextItem() { return pending()[0] || null; }
  function effectiveThreshold() {
    const t = P().taps || {};
    const base = Math.max(1, Number(t.perSong) || 500);
    const g = Math.max(0, Number(t.growthPercent) || 0) / 100;
    const grown = Math.round(base * Math.pow(1 + g, S.taps.unlockCount));
    const nx = pending().find((i) => i.status === "locked");
    if (nx && Number(nx.threshold) > 0) return Math.round(Number(nx.threshold));
    return grown;
  }
  function makeItem(o) {
    return { id: uid("s"), title: String(o.title || "").trim().slice(0, 120), artist: String(o.artist || "").trim().slice(0, 80), file: o.file || null,
      status: o.status || "locked", threshold: o.threshold ? Number(o.threshold) : null, order: o.order || null, addedAt: now(), doneAt: null, manual: !!o.manual };
  }
  function parseLines(text) {
    const out = [];
    for (let raw of String(text || "").split(/\r?\n/)) {
      let line = raw.trim();
      if (!line || line.startsWith("#")) continue;
      let threshold = null;
      const m = line.match(/\|\s*(\d+)\s*$/); if (m) { threshold = Number(m[1]); line = line.slice(0, m.index).trim(); }
      let artist = "", title = line;
      const mm = line.match(/^(.+?)\s+[-–—]\s+(.+)$/); if (mm) { artist = mm[1].trim(); title = mm[2].trim(); }
      out.push({ title, artist, threshold });
    }
    return out;
  }
  // Zamówienie z wiadomości: "Zaśpiewaj proszę Sanah – Szampan ❤️" → "Sanah – Szampan"
  function cleanOrderText(msg) {
    let t = String(msg || "").trim();
    t = t.replace(/^(?:(?:prosz[eę]|poprosz[eę]|bardzo|mo[zż]e|mo[zż]esz|czy|hej|hello|cze[sś][cć]|za[sś]piewaj|za[sś]piewasz|zagraj|zagrasz|pu[sś][cć]|piosenk[aęi]|utw[oó]r|please|sing|play|prosze)(?=[\s,:!\-–—]|$)[\s,:!\-–—]*)+/i, "");
    t = t.replace(/[\s,.!?:;\-–—]+$/g, "").replace(/[\u{1F300}-\u{1FAFF}\u{2600}-\u{27BF}\u{FE0F}\u{2764}]/gu, "").trim();
    return t || String(msg || "").trim();
  }
  function ensureFirstUnlocked() {
    // Pierwsza oczekująca piosenka jest zawsze dostępna, jeśli nic nie leci (start playlisty).
    if (!S.playlist.nowId) { const f = pending()[0]; if (f && f.status === "locked") f.status = "unlocked"; }
  }
  function setNow(id, opts = {}) {
    const it = items().find((i) => i.id === id);
    if (!it) return;
    const prev = nowItem();
    if (prev && prev.id !== it.id && prev.status === "now") { prev.status = opts.prevStatus || "done"; prev.doneAt = now(); }
    it.status = "now";
    S.playlist.nowId = it.id;
    pushEvent({ type: "song", title: it.title });
    stopBacking();
    if ((P().backing || {}).autoplay && it.file) playBacking(it.id);
  }
  function unlockNext(by, reason) {
    const nx = pending().find((i) => i.status === "locked");
    if (!nx) return false;
    nx.status = "unlocked";
    S.taps.unlockCount++;
    S.unlock = { lastAt: now(), title: nx.title, artist: nx.artist, by: by || "", id: nx.id };
    S.taps.sinceUnlock = new Map();
    playSfx("odblokowanie");
    pushEvent({ type: "unlock", title: nx.title, by, reason });
    return true;
  }
  function topTapper() {
    let best = null;
    for (const [k, v] of S.taps.sinceUnlock) if (!best || v.n > best.n) best = { nick: v.nick, n: v.n };
    return best ? best.nick : "";
  }
  function onTaps(nick, delta) {
    const d = Math.max(0, Number(delta) || 0); if (!d) return;
    S.taps.session += d; S.taps.progress += d;
    if (nick) { const k = keyOf(nick); const cur = S.taps.sinceUnlock.get(k) || { nick, n: 0 }; cur.n += d; S.taps.sinceUnlock.set(k, cur); }
    let guard = 0;
    while (guard++ < 20) {
      const th = effectiveThreshold();
      if (S.taps.progress < th) break;
      if (!pending().some((i) => i.status === "locked")) break; // nic do odblokowania — licznik czeka
      const by = topTapper();
      S.taps.progress = (P().taps || {}).carryOver === false ? 0 : S.taps.progress - th;
      unlockNext(by, "tapy");
    }
  }
  function cmdNext(force) {
    const cur = nowItem(); const nx = nextItem();
    if (!nx) { if (cur) { cur.status = "done"; cur.doneAt = now(); S.playlist.nowId = null; stopBacking(); } hint("Koniec playlisty"); return; }
    if (nx.status === "locked") {
      if (!force) { hint("Następna jest zablokowana — poczekaj na tapy albo ODBLOKUJ"); return; }
      nx.status = "unlocked"; pushEvent({ type: "unlock", title: nx.title, reason: "dalej-wymuszone" });
    }
    setNow(nx.id, { prevStatus: "done" });
  }
  function cmdSkip() {
    const cur = nowItem(); const nx = nextItem();
    if (cur) { cur.status = "skipped"; cur.doneAt = now(); }
    if (nx) { if (nx.status === "locked") nx.status = "unlocked"; setNow(nx.id); } else { S.playlist.nowId = null; stopBacking(); }
  }
  function cmdPrev() {
    const done = items().filter((i) => (i.status === "done" || i.status === "skipped") && i.doneAt).sort((a, b) => b.doneAt - a.doneAt);
    const prev = done[0]; if (!prev) return;
    const cur = nowItem(); if (cur) { cur.status = "unlocked"; }
    prev.doneAt = null; prev.status = "now"; S.playlist.nowId = prev.id; stopBacking();
  }
  function hint(text) { S.hint = { text, at: now() }; }

  // ====== ARMATA GIFTÓW ======
  function onGift(nick, coins, giftName, giftImage) {
    const c = Math.max(0, Number(coins) || 0);
    S.giftFeed.unshift({ ts: now(), nick, coins: c, gift: giftName, img: giftImage || "" }); if (S.giftFeed.length > 60) S.giftFeed.length = 60;
    // Gifty widoczne w armacie — widget układa z nich stos i to nimi wybucha.
    if (c > 0) {
      const poj = Math.max(5, Number((P().cannon || {}).capacity) || 100);
      S.cannon.items.push({ id: uid("g"), img: giftImage || "", name: giftName || "", coins: c, nick });
      if (S.cannon.items.length > poj) S.cannon.items.splice(0, S.cannon.items.length - poj);
    }
    maybeBoost(nick, c);
    const cp = P().cannon || {};
    if (cp.enabled !== false && c > 0) {
      S.cannon.charge += c;   // monety liczymy dalej — do statystyki "kto ładuje"
      const k = keyOf(nick); const cur = S.cannon.contrib.get(k) || { nick, coins: 0 }; cur.coins += c; S.cannon.contrib.set(k, cur);
      // Duży gift zatyka rurę. Licznik sztuk leci dalej — korek wylatuje dopiero przy wystrzale.
      const progKorka = Math.max(1, Number(cp.plugCoins) || 500);
      if (c >= progKorka) {
        S.cannon.plug = { img: giftImage || "", name: giftName || "", coins: c, nick, at: now() };
        pushEvent({ type: "plug", nick, coins: c });
      }
      // Wystrzał liczony w SZTUKACH: gdy rura mieści już tyle giftów, ile wynosi pojemność.
      const pojemnosc = Math.max(5, Number(cp.capacity) || 100);
      if (S.cannon.items.length >= pojemnosc) {
        let best = null; for (const v of S.cannon.contrib.values()) if (!best || v.coins > best.coins) best = v;
        S.cannon.shots++; S.cannon.fireAt = now(); S.cannon.lastBy = best ? best.nick : nick;
        // Migawka zawartości rury z chwili wystrzału — widget rozrzuca dokładnie to, co w niej było
        // (razem z korkiem). Bez tego wyrzucałby zastępcze prezenty, bo rura jest już pusta.
        S.cannon.lastBlast = { at: S.cannon.fireAt, items: S.cannon.items.slice(-40), plug: S.cannon.plug };
        S.cannon.charge = cp.carryOver === false ? 0 : Math.max(0, S.cannon.charge - S.cannon.charge);
        S.cannon.contrib = new Map();
        S.cannon.items = [];    // po wystrzale rura jest pusta
        S.cannon.plug = null;   // korek też wylatuje
        playSfx("armata");
        pushEvent({ type: "cannon", by: S.cannon.lastBy });
        if (cp.unlockSong) unlockNext(S.cannon.lastBy, "armata");
      }
    }
    const gt = Number((P().taps || {}).giftCoinsAsTaps) || 0;
    if (gt > 0) onTaps(nick, c * gt);
  }

  // ====== DONEJTY (Tipped) ======
  function onDonation(d) {
    const tp = P().tipped || {};
    const amount = Number(d.amount) || 0;
    const readTh = Number(tp.readThreshold) || 0;
    const don = { ...d, status: "below", order: false, readAt: null, spoken: false, shownAt: null };
    if (d.goal && amount < readTh) don.status = "fund";
    else if (amount >= readTh && amount > 0) don.status = "unread";
    // kasa
    S.funds.total = Math.round((S.funds.total + amount) * 100) / 100;
    const goalKey = d.goal || (don.status === "unread" ? "Donejty" : "Pozostałe wpłaty");
    S.funds.byGoal[goalKey] = Math.round(((S.funds.byGoal[goalKey] || 0) + amount) * 100) / 100;
    const dk = keyOf(d.nick); const cur = S.funds.donors.get(dk) || { nick: d.nick, sum: 0 }; cur.sum = Math.round((cur.sum + amount) * 100) / 100; S.funds.donors.set(dk, cur);
    // zamówienie piosenki
    if (don.status === "unread" && tp.ordersEnabled && amount >= (Number(tp.orderThreshold) || Infinity) && d.message) {
      don.order = true;
      const parsed = parseLines(cleanOrderText(d.message))[0] || { title: d.message };
      const it = makeItem({ ...parsed, status: "unlocked", order: { by: d.nick, amount, donationId: d.id } });
      // wskakuje zaraz za aktualnie śpiewaną
      const arr = items(); const idx = S.playlist.nowId ? arr.findIndex((i) => i.id === S.playlist.nowId) : -1;
      arr.splice(idx + 1, 0, it);
      pushEvent({ type: "order", nick: d.nick, title: it.title, amount });
    }
    S.donations.unshift(don); if (S.donations.length > 500) S.donations.length = 500;
    api.logAppend({ file: "wplaty_log.jsonl", line: JSON.stringify({ ts: don.ts, nick: don.nick, amount, message: don.message, goal: don.goal, status: don.status, order: don.order, signed: don.signed, source: don.source }) }).catch(() => {});
    if (don.status === "unread") {
      showAlert(don);
      playSfx("powiadomienia");
      if (tp.autoDismiss) setTimeout(() => { if (don.status === "unread") markRead(don.id); }, (Number(tp.alertSeconds) || 8) * 1000);
      const tt = P().tts || {};
      if (tt.enabled && tt.auto !== false) speakDonation(don);
    }
    pushEvent({ type: "don", nick: d.nick, amount, status: don.status });
  }
  function showAlert(don) { don.shownAt = now(); S.alert = { id: don.id, nick: don.nick, amount: don.amount, message: don.message, goal: don.goal, order: don.order, at: now() }; }
  function markRead(id) { const d = S.donations.find((x) => x.id === id); if (d) { d.status = "read"; d.readAt = now(); } }
  function currentDonation() { return S.donations.filter((d) => d.status === "unread").sort((a, b) => a.ts - b.ts)[0] || null; }
  function speakDonation(don) {
    const tt = P().tts || {};
    const kw = Number(don.amount) || 0;
    const kwTxt = kw % 1 ? kw.toFixed(2).replace(".", ",") : String(Math.round(kw));
    let msg = tt.withMessage === false ? "" : String(don.message || "");
    let text = String(tt.template || "{nick} wpłaca {kwota} złotych. {wiadomosc}").replace("{nick}", don.nick || "ktoś").replace("{kwota}", kwTxt).replace("{wiadomosc}", msg);
    if (don.goal) text += ` Na cel: ${don.goal}.`;
    text = text.replace(/\s+/g, " ").trim().slice(0, Math.max(40, Number(tt.maxChars) || 220));
    don.spoken = true;
    api.ttsSpeak({ text }).catch(() => {});
  }

  // ====== DŹWIĘK (w silniku, bo zawsze żyje) ======
  let _snd = { folders: {}, baseUrl: "http://127.0.0.1:8760/dzwieki", library: [] };
  const _audio = { powiadomienia: null, odblokowanie: null, armata: null, muzyka: null };
  let _lastSfxAt = {};
  let _musicList = [], _musicIndex = 0;
  const _enc = (n) => encodeURIComponent(String(n || ""));
  async function refreshSound() {
    try {
      const r = await api.soundState(); if (!r || !r.ok) return;
      _snd = r; const playing = _musicList[_musicIndex] || null;
      _musicList = (r.folders && r.folders.muzyka) || [];
      if (playing) { const i = _musicList.indexOf(playing); _musicIndex = i >= 0 ? i : 0; }
      applyMusic();
    } catch {}
  }
  function playSfx(kind) {
    try {
      const s = P().sound || {};
      const enabledKey = { powiadomienia: "notifyEnabled", odblokowanie: "unlockEnabled", armata: "cannonEnabled" }[kind];
      const volKey = { powiadomienia: "notifyVolume", odblokowanie: "unlockVolume", armata: "cannonVolume" }[kind];
      const fileKey = { powiadomienia: "notifyFile", odblokowanie: "unlockFile", armata: "cannonFile" }[kind];
      if (s[enabledKey] === false) return;
      const files = (_snd.folders && _snd.folders[kind]) || []; if (!files.length) return;
      const t = now(); if (t - (_lastSfxAt[kind] || 0) < 400) return; _lastSfxAt[kind] = t;
      const file = (s[fileKey] && files.includes(s[fileKey])) ? s[fileKey] : files[0];
      if (!_audio[kind]) _audio[kind] = new Audio();
      const a = _audio[kind]; a.src = `${_snd.baseUrl}/${kind}/${_enc(file)}`; a.volume = clamp01(s[volKey] ?? 0.8); a.currentTime = 0; a.play().catch(() => {});
    } catch {}
  }
  function playMusicAt(i) {
    if (!_musicList.length) return;
    _musicIndex = ((i % _musicList.length) + _musicList.length) % _musicList.length;
    const s = P().sound || {};
    if (!_audio.muzyka) {
      _audio.muzyka = new Audio();
      _audio.muzyka.addEventListener("ended", () => { const ss = P().sound || {}; if (!ss.musicEnabled) return; if (ss.musicShuffle && _musicList.length > 1) { let n = _musicIndex; while (n === _musicIndex) n = Math.floor(Math.random() * _musicList.length); playMusicAt(n); } else playMusicAt(_musicIndex + 1); });
      _audio.muzyka.addEventListener("error", () => setTimeout(() => playMusicAt(_musicIndex + 1), 800));
    }
    _audio.muzyka.src = `${_snd.baseUrl}/muzyka/${_enc(_musicList[_musicIndex])}`;
    _audio.muzyka.volume = clamp01(s.musicVolume ?? 0.15);
    _audio.muzyka.play().then(reportPlaying).catch(() => {});
  }
  function applyMusic() {
    const s = P().sound || {};
    if (_audio.muzyka) _audio.muzyka.volume = clamp01(s.musicVolume ?? 0.15);
    if (s.musicEnabled && _musicList.length) { if (!_audio.muzyka || _audio.muzyka.paused) playMusicAt(s.musicShuffle ? Math.floor(Math.random() * _musicList.length) : _musicIndex); }
    else if (_audio.muzyka && !_audio.muzyka.paused) _audio.muzyka.pause();
    reportPlaying();
  }
  function reportPlaying() { try { const t = (_audio.muzyka && !_audio.muzyka.paused && _musicList[_musicIndex]) || null; api.soundReportPlaying({ track: t, playing: !!t }); } catch {} }

  // ---- podkłady ----
  let _backing = null;
  function ensureBacking() {
    if (_backing) return _backing;
    _backing = new Audio();
    _backing.addEventListener("timeupdate", () => { S.backing.pos = _backing.currentTime || 0; S.backing.dur = _backing.duration || 0; publishSoon(true); });
    _backing.addEventListener("ended", () => { S.backing.playing = false; publishSoon(); });
    _backing.addEventListener("pause", () => { S.backing.playing = false; publishSoon(); });
    _backing.addEventListener("play", () => { S.backing.playing = true; publishSoon(); });
    _backing.addEventListener("error", () => { S.backing.playing = false; hint("Nie mogę odtworzyć podkładu"); publishSoon(); });
    return _backing;
  }
  function playBacking(itemId) {
    const it = items().find((i) => i.id === itemId) || nowItem();
    if (!it || !it.file) { hint("Ta piosenka nie ma podkładu"); return; }
    const a = ensureBacking();
    const url = `${_snd.baseUrl}/podklady/${_enc(it.file)}`;
    if (S.backing.itemId !== it.id || !a.src || !a.src.endsWith(_enc(it.file))) { a.src = url; S.backing.pos = 0; }
    S.backing.itemId = it.id; S.backing.file = it.file;
    a.volume = clamp01(S.backing.volume);
    a.play().catch(() => {});
  }
  function pauseBacking() { if (_backing) _backing.pause(); }
  function stopBacking() { if (_backing) { _backing.pause(); try { _backing.currentTime = 0; } catch {} } S.backing.playing = false; S.backing.pos = 0; }
  function seekBacking(pos) { if (_backing && Number.isFinite(Number(pos))) { try { _backing.currentTime = Math.max(0, Number(pos)); } catch {} } }
  function setBackingVolume(v) { S.backing.volume = clamp01(v); if (_backing) _backing.volume = S.backing.volume; }

  // ====== SESJA (zapis/odczyt) ======
  let _saveTimer = null;
  function scheduleSave() { if (_saveTimer) return; _saveTimer = setTimeout(saveSession, 1500); }
  function sessionData() {
    return {
      savedAt: now(), session: S.session, playlist: S.playlist,
      taps: { session: S.taps.session, progress: S.taps.progress, unlockCount: S.taps.unlockCount },
      unlock: S.unlock, cannon: { charge: S.cannon.charge, shots: S.cannon.shots, fireAt: S.cannon.fireAt, lastBy: S.cannon.lastBy },
      donations: S.donations.slice(0, 300), funds: { total: S.funds.total, byGoal: S.funds.byGoal, donors: Array.from(S.funds.donors.values()) },
      ranking: Array.from(S.ranking.entries()).map(([k, v]) => [k, v.nick, v.pts]), top1: S.top1, giftFeed: S.giftFeed.slice(0, 40),
      backingVolume: S.backing.volume,
    };
  }
  async function saveSession(slug) { _saveTimer = null; try { await api.sessionSave(sessionData(), slug || (S.profile && S.profile.slug)); } catch {} }
  async function loadSession(slug) {
    try {
      const d = await api.sessionLoad(slug || (S.profile && S.profile.slug));
      if (!d || typeof d !== "object") return;
      if (d.playlist && Array.isArray(d.playlist.items)) S.playlist = { items: d.playlist.items, nowId: d.playlist.nowId || null, name: d.playlist.name || "" };
      if (d.taps) { S.taps.session = Number(d.taps.session) || 0; S.taps.progress = Number(d.taps.progress) || 0; S.taps.unlockCount = Number(d.taps.unlockCount) || 0; }
      if (d.unlock) S.unlock = { ...S.unlock, ...d.unlock, lastAt: 0 };
      if (d.cannon) { S.cannon.charge = Number(d.cannon.charge) || 0; S.cannon.shots = Number(d.cannon.shots) || 0; S.cannon.lastBy = d.cannon.lastBy || ""; S.cannon.items = Array.isArray(d.cannon.items) ? d.cannon.items : []; S.cannon.plug = d.cannon.plug || null; }
      if (Array.isArray(d.donations)) S.donations = d.donations;
      if (d.funds) { S.funds.total = Number(d.funds.total) || 0; S.funds.byGoal = d.funds.byGoal || {}; S.funds.donors = new Map((d.funds.donors || []).map((x) => [keyOf(x.nick), x])); }
      if (Array.isArray(d.ranking)) S.ranking = new Map(d.ranking.map(([k, nick, pts]) => [k, { nick, pts: Number(pts) || 0 }]));
      if (d.top1) S.top1 = d.top1;
      if (Array.isArray(d.giftFeed)) S.giftFeed = d.giftFeed;
      if (d.session && d.session.startedAt) S.session.startedAt = d.session.startedAt;
      if (Number.isFinite(Number(d.backingVolume))) S.backing.volume = clamp01(d.backingVolume);
      S.alert = null;
    } catch {}
  }
  function resetSession(keepPlaylist = true) {
    stopBacking();
    S.session = { startedAt: now(), demo: S.session.demo };
    if (keepPlaylist) { for (const it of items()) { if (!it.order) { it.status = "locked"; it.doneAt = null; } } S.playlist.items = items().filter((i) => !i.order); S.playlist.nowId = null; ensureFirstUnlocked(); }
    else S.playlist = { items: [], nowId: null, name: "" };
    S.taps = { session: 0, progress: 0, unlockCount: 0, sinceUnlock: new Map() };
    S.unlock = { lastAt: 0, title: "", artist: "", by: "" };
    S.cannon = { charge: 0, shots: 0, fireAt: 0, lastBy: "", contrib: new Map(), items: [], plug: null, lastBlast: null };
    S.donations = []; S.alert = null;
    S.funds = { total: 0, byGoal: {}, donors: new Map() };
    S.ranking = new Map(); S.boosts = new Map(); S.top1 = null;
    S.giftFeed = []; S.events = []; S.hint = null;
    api.ttsStop().catch(() => {});
  }

  // ====== PUBLIKACJA STANU ======
  let _pubTimer = null, _lastPubAt = 0;
  function publishSoon(light) {
    if (_pubTimer) return;
    const delay = light ? Math.max(0, 500 - (now() - _lastPubAt)) : 120;
    _pubTimer = setTimeout(publishNow, delay);
  }
  function buildState() {
    const p = P();
    const nowIt = nowItem(); const nx = nextItem();
    const pend = pending();
    const ordered = items().filter((i) => i.order && i.status !== "done" && i.status !== "skipped" && i.id !== S.playlist.nowId);
    const cur = currentDonation();
    const topDonors = Array.from(S.funds.donors.values()).sort((a, b) => b.sum - a.sum).slice(0, 10);
    const cannonTop = Array.from(S.cannon.contrib.values()).sort((a, b) => b.coins - a.coins).slice(0, 5);
    return {
      profileSlug: p.slug || null, profileName: p.name || "", theme: p.theme || {}, eko: !!(p.widgets && p.widgets.eko),
      texts: { promo: (p.ranking && p.ranking.promoTexts) || [] },
      tiktok: S.tiktok, session: { startedAt: S.session.startedAt, demo: S.session.demo }, hint: S.hint,
      song: {
        // próg wysyłamy razem z piosenką — widget pokazuje go na kafelku playlisty
        now: nowIt ? { id: nowIt.id, title: nowIt.title, artist: nowIt.artist, file: nowIt.file, order: nowIt.order, threshold: nowIt.threshold || null } : null,
        next: nx ? { id: nx.id, title: nx.title, artist: nx.artist, status: nx.status, order: nx.order, threshold: nx.threshold || null } : null,
        queue: pend.slice(1, 9).map((i) => ({ id: i.id, title: i.title, artist: i.artist, status: i.status, order: i.order, threshold: i.threshold || null })),
        ordered: ordered.map((i) => ({ id: i.id, title: i.title, artist: i.artist, order: i.order, threshold: i.threshold || null })),
        done: items().filter((i) => i.status === "done").length, total: items().length, name: S.playlist.name,
      },
      taps: { session: S.taps.session, progress: Math.round(S.taps.progress), threshold: effectiveThreshold(), unlockCount: S.taps.unlockCount, carry: (p.taps || {}).carryOver !== false },
      unlock: S.unlock,
      cannon: { enabled: (p.cannon || {}).enabled !== false, charge: Math.round(S.cannon.charge), threshold: Math.max(1, Number((p.cannon || {}).threshold) || 1000), shots: S.cannon.shots, fireAt: S.cannon.fireAt, lastBy: S.cannon.lastBy, label: (p.cannon || {}).label || "Armata giftów", top: cannonTop, items: S.cannon.items.slice(-120), count: S.cannon.items.length,
        capacity: Math.max(5, Number((p.cannon || {}).capacity) || 100),
        plugCoins: Math.max(1, Number((p.cannon || {}).plugCoins) || 500),
        plug: S.cannon.plug, lastBlast: S.cannon.lastBlast },
      donations: { current: cur ? { id: cur.id, nick: cur.nick, amount: cur.amount, message: cur.message, goal: cur.goal, order: cur.order, ts: cur.ts, spoken: cur.spoken } : null, alert: S.alert, alertSeconds: Number((p.tipped || {}).alertSeconds) || 8, readQueue: S.donations.filter((d) => d.status === "unread").length, readThreshold: Number((p.tipped || {}).readThreshold) || 0 },
      funds: { total: S.funds.total, byGoal: S.funds.byGoal, topDonors },
      ranking: rankingTop(20), rankingCount: S.ranking.size, top1: S.top1,
      backing: { ...S.backing },
      tts: S.ttsState,
      // duże rzeczy — tylko dla okien (widgety dostają "slim" bez nich)
      playlistFull: items(), donationsAll: S.donations.slice(0, 200), giftFeed: S.giftFeed.slice(0, 40), events: S.events.slice(0, 40),
    };
  }
  async function publishNow() {
    _pubTimer = null; _lastPubAt = now();
    const st = buildState();
    try { await api.statePublish(st); } catch {}
    try { const el = document.getElementById("dump"); if (el && document.visibilityState === "visible") el.textContent = JSON.stringify({ song: st.song, taps: st.taps, cannon: st.cannon, donations: st.donations, ranking: st.ranking.slice(0, 5) }, null, 1); } catch {}
    scheduleSave();
  }
  function changed() { publishSoon(); }

  // ====== TOP 1 (nagroda 15 min przed końcem? — tu: ręcznie z panelu "OGŁOŚ TOP 1") ======
  function announceTop1() {
    const top = rankingTop(1)[0]; if (!top) { hint("Ranking pusty"); return; }
    const reward = (P().ranking || {}).top1Reward || "dedykacja";
    S.top1 = { nick: top.nick, points: top.points, at: now(), label: reward === "dedykacja" ? "DEDYKACJA PIOSENKI" : "TOP 1" };
    if (reward === "dedykacja") {
      const it = makeItem({ title: `Dedykacja dla ${top.nick}`, artist: "", status: "unlocked", manual: true, order: { by: top.nick, amount: 0, top1: true } });
      const arr = items(); const idx = S.playlist.nowId ? arr.findIndex((i) => i.id === S.playlist.nowId) : -1; arr.splice(idx + 1, 0, it);
    }
    pushEvent({ type: "top1", nick: top.nick });
  }

  // ====== TRYB DEMO ======
  let _demoTimer = null;
  // Prawdziwe obrazki giftów z TikToka — żeby demo wyglądało jak live.
  // W demo używamy emoji zamiast adresów — obrazki giftów przychodzą dopiero z prawdziwego live'a.
  const DEMO_GIFTY = [
    { name: "Rose", coins: 1, img: "🌹" },
    { name: "TikTok", coins: 1, img: "🎵" },
    { name: "Finger Heart", coins: 5, img: "🫰" },
    { name: "Perfume", coins: 20, img: "🧴" },
    { name: "Doughnut", coins: 30, img: "🍩" },
    { name: "Galaxy", coins: 1000, img: "🌌" },
  ];
  const DEMO_NICKS = ["Luna", "Kasia", "Marta", "Ola_S", "Njut", "Basia", "Wiktoria", "Zuza", "Tomek", "Ania_K"];
  function demoTick() {
    const pick = () => DEMO_NICKS[Math.floor(Math.random() * DEMO_NICKS.length)];
    const r = Math.random();
    if (r < 0.55) handleTiktok("like", { nickname: pick(), likeCount: 1 + Math.floor(Math.random() * 30) });
    else if (r < 0.75) handleTiktok("chat", { nickname: pick(), comment: "super śpiewasz!" });
    else if (r < 0.85) { const g = DEMO_GIFTY[Math.floor(Math.random() * DEMO_GIFTY.length)]; handleTiktok("gift", { nickname: pick(), diamondCount: g.coins, giftName: g.name, giftImage: g.img }); }
    else if (r < 0.92) handleTiktok("follow", { nickname: pick() });
    else if (r < 0.96) handleTiktok("share", { nickname: pick() });
    else onDonation({ id: uid("demo"), ts: now(), nick: pick(), amount: [5, 10, 20, 25, 50, 100][Math.floor(Math.random() * 6)], message: ["Pozdrowienia z Gdańska!", "Zaśpiewaj Sanah – Szampan", "Dla mamy ❤️", ""][Math.floor(Math.random() * 4)], goal: null, signed: true, source: "demo" });
    changed();
  }
  function setDemo(on) {
    S.session.demo = !!on;
    if (_demoTimer) { clearInterval(_demoTimer); _demoTimer = null; }
    if (on) {
      if (!items().length) loadPlaylistItems(parseLines("Sanah – Szampan\nDawid Podsiadło – Małomiasteczkowy\nKwiat Jabłoni – Mogło być nic\nDaria Zawiałow – Kaonashi\nMrozu – Nic do stracenia\nsanah – Bajka | 300"), "Demo");
      _demoTimer = setInterval(demoTick, 1100);
    }
    changed();
  }

  // ====== WEJŚCIE: TikTok ======
  function handleTiktok(event, data) {
    const nick = nickOf(data);
    if (event === "like") { const d = likeDelta(data); award(nick, d / TAPS_PER_POINT, "tap"); onTaps(nick, d); }
    else if (event === "chat") { award(nick, W_CHAT, "komentarz"); pushEvent({ type: "chat", nick, text: String(data.comment || "").slice(0, 120) }); }
    else if (event === "follow") { award(nick, W_FOLLOW, "follow"); pushEvent({ type: "follow", nick }); }
    else if (event === "share") { award(nick, W_SHARE, "share"); pushEvent({ type: "share", nick }); }
    else if (event === "gift") { const coins = Number(data.diamondCount || data.amount || data.totalDiamonds) || 0; onGift(nick, coins, data.giftName, data.giftImage); }
    else if (event === "member") { /* wejście widza — nic */ }
  }

  // ====== PLAYLISTA: operacje z paneli ======
  function loadPlaylistItems(list, name, mode) {
    const newItems = list.map((o) => makeItem({ ...o, status: "locked" }));
    if (mode === "append") S.playlist.items.push(...newItems);
    else { S.playlist = { items: newItems, nowId: null, name: name || "" }; S.taps.progress = 0; S.taps.unlockCount = 0; }
    ensureFirstUnlocked();
  }
  function handleCmd(name, payload = {}) {
    switch (name) {
      // Pilot w OBS działa tak samo jak przyciski w czytniku — DALEJ przechodzi dalej także wtedy,
      // gdy następna piosenka nie zebrała jeszcze tapów (inaczej przycisk wyglądałby na zepsuty).
      case "pilot": {
        const mapa = { next: "next", prev: "prev", skip: "skip", unlock: "unlock", read: "don-read" };
        const nazwa = mapa[payload.akcja];
        if (!nazwa) return;
        return handleCmd(nazwa, nazwa === "next" ? { force: true } : {});
      }
      case "next": cmdNext(!!payload.force); break;
      case "prev": cmdPrev(); break;
      case "skip": cmdSkip(); break;
      case "unlock": { const by = payload.by || ""; if (payload.id) { const it = items().find((i) => i.id === payload.id); if (it && it.status === "locked") { it.status = "unlocked"; pushEvent({ type: "unlock", title: it.title, reason: "ręcznie" }); } } else unlockNext(by, "ręcznie"); break; }
      case "lock": { const it = items().find((i) => i.id === payload.id); if (it && it.status === "unlocked") it.status = "locked"; break; }
      case "play-now": { const it = items().find((i) => i.id === payload.id); if (it) { if (it.status === "done" || it.status === "skipped") { it.doneAt = null; } setNow(it.id, { prevStatus: "unlocked" }); } break; }
      case "song-done": { const it = items().find((i) => i.id === payload.id); if (it) { it.status = "done"; it.doneAt = now(); if (S.playlist.nowId === it.id) { S.playlist.nowId = null; stopBacking(); } } break; }
      case "song-reset": { const it = items().find((i) => i.id === payload.id); if (it) { it.status = "locked"; it.doneAt = null; if (S.playlist.nowId === it.id) S.playlist.nowId = null; ensureFirstUnlocked(); } break; }
      case "song-remove": { S.playlist.items = items().filter((i) => i.id !== payload.id); if (S.playlist.nowId === payload.id) { S.playlist.nowId = null; stopBacking(); } ensureFirstUnlocked(); break; }
      case "song-move": { const arr = items(); const from = arr.findIndex((i) => i.id === payload.id); if (from < 0) break; const [it] = arr.splice(from, 1); let to = Number(payload.to); if (!Number.isFinite(to)) to = from + (payload.dir === "up" ? -1 : 1); to = Math.max(0, Math.min(arr.length, to)); arr.splice(to, 0, it); break; }
      case "song-edit": { const it = items().find((i) => i.id === payload.id); if (it) { if (payload.title !== undefined) it.title = String(payload.title).slice(0, 120); if (payload.artist !== undefined) it.artist = String(payload.artist).slice(0, 80); if (payload.threshold !== undefined) it.threshold = payload.threshold ? Number(payload.threshold) : null; if (payload.file !== undefined) it.file = payload.file || null; } break; }
      case "song-add": { const list = payload.items ? payload.items : parseLines(payload.text || ""); const made = list.map((o) => makeItem({ ...o, status: payload.unlocked ? "unlocked" : "locked", manual: true })); if (payload.position === "next") { const arr = items(); const idx = S.playlist.nowId ? arr.findIndex((i) => i.id === S.playlist.nowId) : -1; arr.splice(idx + 1, 0, ...made); } else items().push(...made); ensureFirstUnlocked(); break; }
      case "playlist-load": loadPlaylistItems(Array.isArray(payload.items) ? payload.items : parseLines(payload.text || ""), payload.name, payload.mode); break;
      case "playlist-clear": S.playlist = { items: [], nowId: null, name: "" }; stopBacking(); break;
      case "playlist-restart": for (const it of items()) { it.status = "locked"; it.doneAt = null; } S.playlist.nowId = null; S.taps.progress = 0; S.taps.unlockCount = 0; ensureFirstUnlocked(); stopBacking(); break;
      case "taps-add": onTaps(payload.nick || "", Number(payload.n) || 0); break;
      case "taps-set": S.taps.progress = Math.max(0, Number(payload.n) || 0); onTaps("", 0); break;
      case "cannon-fire": { const cp = P().cannon || {}; S.cannon.shots++; S.cannon.fireAt = now(); S.cannon.lastBy = payload.by || "prowadząca"; S.cannon.charge = 0; S.cannon.contrib = new Map(); playSfx("armata"); if (cp.unlockSong) unlockNext(S.cannon.lastBy, "armata"); break; }
      case "cannon-reset": S.cannon.charge = 0; S.cannon.contrib = new Map(); S.cannon.items = []; S.cannon.plug = null; break;
      case "backing-play": playBacking(payload.id); break;
      case "backing-pause": pauseBacking(); break;
      case "backing-stop": stopBacking(); break;
      case "backing-seek": seekBacking(payload.pos); break;
      case "backing-volume": setBackingVolume(payload.v); break;
      case "don-read": { const d = payload.id ? S.donations.find((x) => x.id === payload.id) : currentDonation(); if (d) markRead(d.id); break; }
      case "don-unread": { const d = S.donations.find((x) => x.id === payload.id); if (d) { d.status = "unread"; d.readAt = null; showAlert(d); } break; }
      case "don-show": { const d = S.donations.find((x) => x.id === payload.id) || currentDonation(); if (d) showAlert(d); break; }
      case "don-speak": { const d = payload.id ? S.donations.find((x) => x.id === payload.id) : currentDonation(); if (d) speakDonation(d); break; }
      case "don-remove": S.donations = S.donations.filter((x) => x.id !== payload.id); break;
      case "don-order": { const d = S.donations.find((x) => x.id === payload.id); if (d && !d.order) { d.order = true; const parsed = parseLines(cleanOrderText(payload.title || d.message || ""))[0] || { title: d.message || "Zamówienie" }; const it = makeItem({ ...parsed, status: "unlocked", order: { by: d.nick, amount: d.amount, donationId: d.id } }); const arr = items(); const idx = S.playlist.nowId ? arr.findIndex((i) => i.id === S.playlist.nowId) : -1; arr.splice(idx + 1, 0, it); } break; }
      case "don-manual": onDonation({ id: uid("man"), ts: now(), nick: String(payload.nick || "Anon"), amount: Number(payload.amount) || 0, amountKnown: true, message: String(payload.message || ""), goal: payload.goal || null, signed: true, source: "ręcznie" }); break;
      case "tts-stop": api.ttsStop().catch(() => {}); break;
      case "top1": announceTop1(); break;
      case "top1-clear": S.top1 = null; break;
      case "demo": setDemo(!!payload.on); break;
      case "reset-session": resetSession(payload.keepPlaylist !== false); break;
      case "hint-clear": S.hint = null; break;
      case "profile-switched": (async () => { await saveSession(S.profile && S.profile.slug); resetSession(false); S.profile = await api.profileGet(); await loadSession(S.profile.slug); ensureFirstUnlocked(); changed(); })(); return;
      case "sound-refresh": refreshSound(); break;
      default: return;
    }
    changed();
  }

  // ====== START ======
  async function boot() {
    S.profile = await api.profileGet();
    await loadSession(S.profile && S.profile.slug);
    ensureFirstUnlocked();
    try { S.tiktok = await api.tiktokState(); } catch {}
    await refreshSound();

    api.onTiktokEvent(({ event, data }) => { try { handleTiktok(event, data || {}); } catch (e) { console.error(e); } changed(); });
    api.onTiktokState((st) => { S.tiktok = { ...S.tiktok, ...(st || {}) }; changed(); });
    api.onTippedDonation((d) => { try { onDonation(d); } catch (e) { console.error(e); } changed(); });
    api.onEngineCmd(({ name, payload }) => { try { handleCmd(name, payload || {}); } catch (e) { console.error("cmd", name, e); } });
    api.onProfileChanged((p) => { if (p && (!S.profile || p.slug === S.profile.slug)) { S.profile = p; applyMusic(); changed(); } });
    api.onTtsState((st) => { S.ttsState = st || S.ttsState; publishSoon(true); });
    api.onSoundControl(({ action } = {}) => {
      if (action === "test-notify") { _lastSfxAt.powiadomienia = 0; playSfx("powiadomienia"); }
      else if (action === "test-unlock") { _lastSfxAt.odblokowanie = 0; playSfx("odblokowanie"); }
      else if (action === "test-cannon") { _lastSfxAt.armata = 0; playSfx("armata"); }
      else if (action === "music-next") { if (_musicList.length) playMusicAt(_musicIndex + 1); }
      else if (action === "rescan") refreshSound();
    });
    setInterval(refreshSound, 30000);
    setInterval(() => { S.hint && now() - S.hint.at > 6000 && (S.hint = null, changed()); }, 2000);
    setInterval(() => publishSoon(true), 4000); // heartbeat
    // auto-połączenie z TikTokiem, jeśli profil ma nick
    if (S.profile && S.profile.tiktok && S.profile.tiktok.username) { setTimeout(() => api.tiktokConnect({}).catch(() => {}), 800); }
    publishNow();
  }
  boot();
})();
