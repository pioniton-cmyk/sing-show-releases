// Konfiguracja programu + PROFILE TWÓRCÓW.
// config.json: { activeProfile, profiles: { <slug>: {...} }, global: {...} }
// Każdy profil ma własne: nick TikTok, Tipped, progi tapów, armatę, lektora, paletę, teksty.
// Dane sesyjne profilu (playlista, sesja) leżą w profile/<slug>/.
const path = require("path");
const { getOutputDir, sub, readJson, writeJson, slugify } = require("./paths");
const diag = require("./diag");

const CONFIG_FILE = () => path.join(getOutputDir(), "config.json");

const PROFILE_DEFAULTS = Object.freeze({
  name: "Profil 1",
  tiktok: { username: "", apiKey: "" },
  tipped: {
    enabled: true,            // serwer webhooka
    hash: "",                 // sekret — pusty = przyjmuj wszystko (jak w tarocie)
    readThreshold: 20,        // od jakiej kwoty czytamy donejt
    ordersEnabled: true,      // wiadomość ≥ orderThreshold = zamówienie piosenki
    orderThreshold: 50,
    alertSeconds: 8,          // ile sekund karta donejtu wisi na ekranie
    autoDismiss: false,       // donejt sam znika z kolejki "do przeczytania" po alertSeconds
  },
  taps: {
    perSong: 500,             // tapów na odblokowanie kolejnej piosenki
    carryOver: true,          // nadwyżka przechodzi
    growthPercent: 0,         // rosnący próg (%) po każdym odblokowaniu
    giftCoinsAsTaps: 0,       // 1 moneta = N tapów (0 = wyłączone)
  },
  cannon: {
    enabled: true,
    capacity: 100,            // ile giftów mieści rura — przy tylu jest wystrzał
    plugCoins: 500,           // gift od tylu monet zatyka rurę (korek); licznik leci dalej
    threshold: 1000,          // monety — zostawione do statystyk (kto ile wrzucił)
    carryOver: true,
    unlockSong: false,        // wystrzał odblokowuje piosenkę
    label: "ARMATA GIFTÓW",
  },
  tts: {
    enabled: true,            // lektor czyta donejty ≥ readThreshold
    auto: true,               // czytaj od razu po wpłynięciu (false = dopiero po kliknięciu CZYTAJ)
    voice: "",                // "" = domyślny głos systemu (macOS: Zosia jeśli jest)
    rate: 180,                // słów/min (macOS say)
    withMessage: true,
    maxChars: 220,
    template: "{nick} wpłaca {kwota} złotych. {wiadomosc}",
  },
  ranking: {
    promoTexts: ["TAPUJ — ODBLOKUJ NASTĘPNĄ PIOSENKĘ", "ZAMÓW PIOSENKĘ — LINK W BIO"],
    top1Reward: "dedykacja",   // "dedykacja" | "off"
  },
  backing: { autoplay: false, volume: 0.8 },   // podkłady: auto-start przy DALEJ
  theme: {
    accent: "#ff4d8d",          // główny akcent (róż)
    accent2: "#ffd166",         // serduszka / tapy (złoto)
    ink: "#f3f4fb",
    glass: "rgba(12,14,26,.78)",
  },
  sound: {
    notifyEnabled: true, notifyVolume: 0.7, notifyFile: null,        // nowy donejt
    unlockEnabled: true, unlockVolume: 0.8, unlockFile: null,        // odblokowanie piosenki
    cannonEnabled: true, cannonVolume: 0.9, cannonFile: null,        // wystrzał armaty
    musicEnabled: false, musicVolume: 0.15, musicShuffle: true,      // muzyka w tle (przerwy)
  },
  widgets: { eko: false },
  comboLayout: null,
});

const GLOBAL_DEFAULTS = Object.freeze({
  widgetPort: 8760,
  tippedPort: 8797,
  // quick = losowy adres *.trycloudflare.com (zero konfiguracji)
  // named = własna stała domena: potrzebny tunnelId, hostname i plik poświadczeń z Cloudflare
  // Tunel domyślnie NIE startuje sam — publiczny adres ma sens dopiero, gdy Tipped jest
  // skonfigurowany. Włącza się przyciskiem w panelu TIPPED albo zaznaczeniem w USTAWIENIACH.
  tunnel: { mode: "quick", autostart: false, named: { tunnelId: "", hostname: "", credsFile: "" } },
  shortcuts: {
    enabled: true,
    next: "CommandOrControl+Alt+Right",
    prev: "CommandOrControl+Alt+Left",
    skip: "CommandOrControl+Alt+Down",
    unlock: "CommandOrControl+Alt+U",
    read: "CommandOrControl+Alt+P",
  },
  updates: { checkOnStart: true },
});

let _cfg = null;

function deepMerge(base, patch) {
  if (!patch || typeof patch !== "object" || Array.isArray(patch)) return patch === undefined ? base : patch;
  const out = { ...(base && typeof base === "object" && !Array.isArray(base) ? base : {}) };
  for (const [k, v] of Object.entries(patch)) {
    if (v && typeof v === "object" && !Array.isArray(v)) out[k] = deepMerge(out[k], v);
    else out[k] = v;
  }
  return out;
}

function clone(o) { return JSON.parse(JSON.stringify(o)); }

function load() {
  const raw = readJson(CONFIG_FILE(), null);
  _cfg = raw && typeof raw === "object" ? raw : {};
  if (!_cfg.profiles || typeof _cfg.profiles !== "object" || !Object.keys(_cfg.profiles).length) {
    _cfg.profiles = { "profil-1": clone(PROFILE_DEFAULTS) };
  }
  if (!_cfg.activeProfile || !_cfg.profiles[_cfg.activeProfile]) {
    _cfg.activeProfile = Object.keys(_cfg.profiles)[0];
  }
  _cfg.global = deepMerge(clone(GLOBAL_DEFAULTS), _cfg.global || {});
  save();
  return _cfg;
}

function save() {
  if (!_cfg) return false;
  return writeJson(CONFIG_FILE(), _cfg);
}

function cfg() { if (!_cfg) load(); return _cfg; }

function getGlobal() { return cfg().global; }

function updateGlobal(patch) {
  const c = cfg();
  c.global = deepMerge(c.global || {}, patch || {});
  save();
  return c.global;
}

function activeSlug() { return cfg().activeProfile; }

// Pełny profil = domyślne + zapisane (żeby nowe pola miały wartości po aktualizacji).
function getProfile(slug) {
  const c = cfg();
  const s = slug || c.activeProfile;
  const p = c.profiles[s];
  if (!p) return null;
  return { slug: s, ...deepMerge(clone(PROFILE_DEFAULTS), p) };
}

function listProfiles() {
  const c = cfg();
  return Object.keys(c.profiles).map((slug) => ({ slug, name: c.profiles[slug].name || slug, active: slug === c.activeProfile }));
}

function updateProfile(patch, slug) {
  const c = cfg();
  const s = slug || c.activeProfile;
  if (!c.profiles[s]) return null;
  const clean = { ...(patch || {}) }; delete clean.slug;
  c.profiles[s] = deepMerge(c.profiles[s], clean);
  save();
  return getProfile(s);
}

function createProfile(name, copyFromSlug) {
  const c = cfg();
  let slug = slugify(name);
  let i = 2;
  while (c.profiles[slug]) slug = `${slugify(name)}-${i++}`;
  const base = copyFromSlug && c.profiles[copyFromSlug] ? clone(c.profiles[copyFromSlug]) : clone(PROFILE_DEFAULTS);
  base.name = String(name || slug).trim() || slug;
  c.profiles[slug] = base;
  save();
  return getProfile(slug);
}

function deleteProfile(slug) {
  const c = cfg();
  if (!c.profiles[slug] || Object.keys(c.profiles).length <= 1) return false;
  delete c.profiles[slug];
  if (c.activeProfile === slug) c.activeProfile = Object.keys(c.profiles)[0];
  save();
  return true;
}

function setActiveProfile(slug) {
  const c = cfg();
  if (!c.profiles[slug]) return false;
  c.activeProfile = slug;
  save();
  diag.info(`[PROFIL] Aktywny profil: ${c.profiles[slug].name || slug}`);
  return true;
}

// Folder danych sesyjnych aktywnego profilu (playlista, sesja, log wpłat).
function profileDir(slug) {
  return sub("profile", slug || activeSlug());
}

module.exports = {
  load, save, cfg, getGlobal, updateGlobal, activeSlug, getProfile, listProfiles, updateProfile,
  createProfile, deleteProfile, setActiveProfile, profileDir, PROFILE_DEFAULTS, deepMerge,
};
