# SING_SHOW — program do live'a śpiewanego na TikToku

Siostrzana aplikacja KVRINA_SHOW (ta sama architektura: ukryty silnik + czytnik + panele + lokalny serwer widgetów).

## Uruchamianie
- **Zwykłe użycie:** ikona **SING_SHOW** na Biurku (samodzielna aplikacja, sama się aktualizuje).
- **Praca nad kodem:** `DEV_SING_SHOW.command` na Biurku albo `npm start` w tym folderze.
  Uwaga: naraz działa tylko jedna kopia — druga pokaże okno pierwszej i się zamknie.

## Start (dev)
    npm install   # raz (kopiuje patch tiktok-live-connector przez patch-package)
    npm start     # albo ~/Desktop/DEV_SING_SHOW.command

## Co jest w bazie (v0.1)
- TikTok LIVE przez `tiktok-live-connector` (kod 1:1 z KVRINA_SHOW) — like/gift/chat/follow/share, auto-reconnect.
- **Playlista odblokowywana tapami**: import tekstu/pliku, biblioteka podkładów (`SING_SHOW TXT/dzwieki/podklady`), zapisane playlisty per profil, ręczne ▶/🔓, próg per piosenka (`| 800`), nadwyżka tapów, rosnący próg, gifty jako tapy (opcja).
- **Tipped**: webhook `:8797/webhook` (parser kwot/groszy, dedup order_id, HMAC), routing: ≥ próg → „do przeczytania” + alert na ekranie + dźwięk + **lektor** (macOS `say`), ≥ próg zamówienia → **zamówienie piosenki** wskakuje jako następna; poniżej → tylko kasa. Tunel cloudflared (tryb szybki) — własna domena do skonfigurowania później.
- **Ranking-hybryda** (bez zmian: share 50 / follow 30 / komentarz 1 / 5 tapów = 1 pkt / gift ≥100 monet = ×1,1 przez 3 min) + ticker OBS z pasem promo; OGŁOŚ TOP 1 → dedykacja.
- **Armata giftów**: monety ładują miernik, po progu „wystrzał” (animacja + dźwięk, opcjonalnie odblokowuje piosenkę).
- **Profile twórców**: każdy ma własny nick, progi, lektora, paletę, teksty, playlisty, sesję (USTAWIENIA → profile; przełączanie w czytniku).
- Widgety: `http://127.0.0.1:8760/widget-wszystko.html` (1080×1920) + osobne; `demo.html`, `pilot.html`; układ w panelu WIDGETY; tryb oszczędny.
- Dane: `~/Desktop/SING_SHOW TXT/` (config.json z profilami, profile/<slug>/{session.json,playlisty/,wplaty_log.jsonl}, widgety/, dzwieki/).

## Porty
widgety 8760, webhook 8797 (inne niż KVRINA_SHOW, oba programy mogą działać naraz).

## Tryb dev — trasy testowe (tylko `npm start`, 127.0.0.1)
    curl "http://127.0.0.1:8760/dev/open/playlista"          # otwórz panel
    curl "http://127.0.0.1:8760/dev/cmd/demo?json=%7B%22on%22%3Atrue%7D"   # tryb demo
    curl "http://127.0.0.1:8760/dev/tiktok/gift?json=%7B%22nickname%22%3A%22Ala%22%2C%22diamondCount%22%3A600%7D"  # udawany gift
    curl "http://127.0.0.1:8760/dev/layout/armata?json=%7B%22x%22%3A-140%7D"  # układ widgetu
    curl -X POST http://127.0.0.1:8797/webhook -H 'Content-Type: application/json' -d '{"payer_name":"Ania","message":"Zaśpiewaj Sanah – Szampan","amount":60,"order_id":"T-1"}'

## Skróty globalne (działają, gdy program jest w tle — przydatne przy śpiewaniu)
| Skrót | Działanie |
|---|---|
| ⌘⌥→ | DALEJ (następna piosenka) |
| ⌘⌥← | WSTECZ |
| ⌘⌥↓ | POMIŃ |
| ⌘⌥U | ODBLOKUJ następną |
| ⌘⌥P | PRZECZYTANE (donejt) |

Zmiana i wyłączenie: USTAWIENIA → Skróty klawiszowe. Jeśli kombinację zajmuje inny program, panel to pokaże.

## Układ na ekranie
MENU → UKŁAD NA EKRANIE: przeciągasz kafelki po makiecie 1080×1920, uchwytem skalujesz, ptaszkiem włączasz/wyłączasz element. Zmiany trafiają do widgetu WSZYSTKO od razu — bez przeładowywania źródła w TikTok Studio. Układ zapisuje się per profil.

## Klucz Euler Stream (podpisywanie połączeń z TikTok LIVE)
**Gdzie go wkleić:** MENU → USTAWIENIA → karta „Klucz Euler Stream" na samej górze. Program przed zapisaniem
sprawdza klucz w Euler Stream i pokazuje limity (ile zapytań zostało dziś / na godzinę / na minutę).
Zapisuje się do pliku `euler-key.json` obok programu — **przetrwa aktualizacje** i nie trafi do żadnej publicznej paczki.

Klucza **nie ma w kodzie** — pliki programu trafiają do publicznego repozytorium aktualizacji, więc każdy
klucz w źródłach byłby jawny dla wszystkich. Program szuka go w kolejności:
1. pole „Inny klucz tylko dla tego profilu" w USTAWIENIACH (gdy twórczyni ma własny klucz),
2. plik `euler-key.json` obok programu (zapisywany przyciskiem ZAPISZ KLUCZ, dostarczany też z instalką),
3. plik `euler-key.json` w folderze danych `SING_SHOW TXT` (gdy folder programu jest tylko do odczytu).

Wzór pliku: `euler-key.PRZYKLAD.json`. Plik jest w `.gitignore`, pomijany przy aktualizacjach
(nie zostanie nadpisany ani skasowany) i blokowany przez bezpiecznik w skrypcie wydawniczym.
Bez klucza program też się połączy, ale na darmowym limicie serwera — przy większym ruchu bywa odrzucany.

## Aktualizacje i wydawanie wersji
- Użytkowniczka: MENU → AKTUALIZACJE (sprawdź / zainstaluj / przywróć poprzednią). Każda aktualizacja robi kopię obecnej wersji w `SING_SHOW TXT/kopie_wersji/` (trzymamy 5 ostatnich); dane, playlisty i dźwięki nie są ruszane.
- Ty (wydawca): podbij `version` w package.json → uruchom `WYDAJ_NA_GITHUB.command`. Skrypt pakuje pliki,
  **sprawdza czy do paczki nie wpadł żaden klucz** (przerywa, jeśli tak) i wgrywa ZIP + latest.json do
  publicznego repo `pioniton-cmyk/sing-show-releases` (kanał aktualizacji — już działa, wersja 0.1.0 opublikowana).
- Instalka .app: `ZBUDUJ_INSTALKE.command` → buduje aplikację **i odświeża skrót `SING_SHOW.app` na Biurku**
  (dokłada też lokalny klucz Euler Stream i plik tunelu, których nie ma w repo).
- Testowanie mechanizmu bez publikacji: `SING_UPDATES_URL=http://127.0.0.1:8899/latest.json npm start`.
- Po publikacji GitHub trzyma pliki w cache **ok. 5 minut** — przez ten czas program może jeszcze widzieć
  poprzednią wersję. To normalne (parametry `?cb=` tego nie omijają).

## Bezpieczniki
- Tylko jedna kopia programu naraz (druga pokazuje okno pierwszej i się zamyka) — inaczej porty byłyby zajęte i program wyglądałby na zawieszony.
- Tunel cloudflared **nie startuje sam** — publiczny adres ma sens dopiero po konfiguracji Tipped (włączasz przyciskiem w panelu TIPPED albo w USTAWIENIACH).
- Plik poświadczeń tunelu (`cloudflared-sing-show.json`) nigdy nie trafia do paczek aktualizacji.

## Do zrobienia (kolejne fazy)
Docelowa konfiguracja Tipped (progi i stała domena), panel OBSERWUJĄCY, wersja na Windows.
