// Ścieżki i pomocnicze operacje na plikach.
// Wszystkie dane programu leżą w ~/Desktop/SING_SHOW TXT (jak "KVRINA_SHOW TXT" w tarocie),
// żeby użytkownik widział je i mógł zrobić kopię jednym przeciągnięciem.
const { app } = require("electron");
const path = require("path");
const fs = require("fs");

const OUTPUT_DIR_NAME = "SING_SHOW TXT";
let _outputDir = null;

function ensureDir(dir) {
  try { fs.mkdirSync(dir, { recursive: true }); } catch {}
  return dir;
}

function getOutputDir() {
  if (_outputDir) return _outputDir;
  _outputDir = ensureDir(path.join(app.getPath("desktop"), OUTPUT_DIR_NAME));
  return _outputDir;
}

function sub(...parts) {
  return ensureDir(path.join(getOutputDir(), ...parts));
}

function readJson(file, fallback) {
  try {
    if (!fs.existsSync(file)) return fallback;
    const raw = fs.readFileSync(file, "utf8");
    const obj = JSON.parse(raw || "null");
    return obj === null || obj === undefined ? fallback : obj;
  } catch {
    return fallback;
  }
}

function writeJson(file, data) {
  try {
    ensureDir(path.dirname(file));
    const tmp = file + ".tmp";
    fs.writeFileSync(tmp, JSON.stringify(data, null, 2), "utf8");
    fs.renameSync(tmp, file);
    return true;
  } catch (e) {
    console.warn("[PATHS] writeJson failed:", file, e.message);
    return false;
  }
}

function appendLine(file, line) {
  try {
    ensureDir(path.dirname(file));
    fs.appendFileSync(file, line.endsWith("\n") ? line : line + "\n", "utf8");
  } catch {}
}

// Zabezpieczenie przed wyjściem poza katalog bazowy (../../etc/passwd).
function safeJoin(base, rel) {
  const target = path.normalize(path.join(base, rel || ""));
  const normalizedBase = path.normalize(base + path.sep);
  if (!target.startsWith(normalizedBase) && target !== path.normalize(base)) return null;
  return target;
}

// Slug do nazw plików/profili: bez diakrytyków, małe litery, myślniki.
function slugify(s) {
  return String(s || "")
    .normalize("NFD").replace(/[̀-ͯ]/g, "")
    .replace(/ł/g, "l").replace(/Ł/g, "L")
    .toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "")
    .slice(0, 40) || "profil";
}

module.exports = { getOutputDir, ensureDir, sub, readJson, writeJson, appendLine, safeJoin, slugify, OUTPUT_DIR_NAME };
