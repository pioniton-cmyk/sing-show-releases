// =========================
// SERWER WIDGETÓW — http://127.0.0.1:PORT
// Stan trzymamy W PAMIĘCI (silnik wysyła go przez IPC), na dysk zapisujemy co ~2 s tylko
// do podglądu/diagnostyki. Widgety i panele odpytują /widget_state_slim.json.
// =========================
const http = require("http");
const path = require("path");
const fs = require("fs");
const diag = require("../diag");
const { sub, safeJoin, writeJson } = require("../paths");
const sound = require("../sound");
const T = require("./templates");

let _server = null;
let _port = 8760;
let _state = {};            // pełny stan od silnika
let _full = Buffer.from("{}");
let _slim = Buffer.from("{}");
let _dirty = false;
let _extra = () => ({});    // dodatki od main: theme, eko, comboLayout, texts
let _onPilot = () => {};
let _onDev = null;         // tylko dev: (kind, name, payload) → main
let _diskTimer = null;
const _usage = new Map();

function widgetsDir() { return sub("widgety"); }

function writeAssetFiles() {
  const dir = widgetsDir();
  const kinds = ["playlista", "tapy", "donejt", "odblokowanie", "armata", "ranking", "wszystko"];
  for (const k of kinds) {
    try { fs.writeFileSync(path.join(dir, `widget-${k}.html`), T.widgetHtml(k), "utf8"); } catch (e) { diag.warn(`[WIDGETY] zapis ${k}: ${e.message}`); }
  }
  try { fs.writeFileSync(path.join(dir, "demo.html"), T.demoHtml(_port), "utf8"); } catch {}
  try { fs.writeFileSync(path.join(dir, "pilot.html"), T.pilotHtml(), "utf8"); } catch {}
  try {
    fs.writeFileSync(path.join(dir, "adresy_widgetow.txt"), [
      "SING_SHOW — ADRESY WIDGETÓW (TikTok LIVE Studio / OBS → źródło: Przeglądarka)",
      "",
      `WSZYSTKO (jedna warstwa 1080x1920, zalecane):  http://127.0.0.1:${_port}/widget-wszystko.html`,
      `PLAYLISTA (teraz / następna / kolejka):          http://127.0.0.1:${_port}/widget-playlista.html`,
      `LICZNIK TAPÓW (pasek):                           http://127.0.0.1:${_port}/widget-tapy.html`,
      `ALERT DONEJTU:                                   http://127.0.0.1:${_port}/widget-donejt.html`,
      `ODBLOKOWANIE PIOSENKI (animacja):                http://127.0.0.1:${_port}/widget-odblokowanie.html`,
      `ARMATA GIFTÓW:                                   http://127.0.0.1:${_port}/widget-armata.html`,
      `RANKING WIDZÓW (ticker):                         http://127.0.0.1:${_port}/widget-ranking.html`,
      "",
      `PODGLĄD WSZYSTKICH:  http://127.0.0.1:${_port}/demo.html`,
      `PILOT (dock OBS, nie na scenę): http://127.0.0.1:${_port}/pilot.html`,
      "",
      "Program musi być uruchomiony, żeby linki działały.",
    ].join("\n"), "utf8");
  } catch {}
}

function _rebuild() {
  try {
    const extra = _extra() || {};
    const obj = { ..._state, ...extra, updatedAt: Date.now() };
    _full = Buffer.from(JSON.stringify(obj), "utf8");
    const slim = { ...obj };
    delete slim.donationsAll; delete slim.giftFeed; delete slim.events; delete slim.playlistFull; delete slim.library;
    _slim = Buffer.from(JSON.stringify(slim), "utf8");
    _dirty = true;
    if (!_diskTimer) _diskTimer = setTimeout(_flushDisk, 2000);
  } catch (e) { diag.warn("[WIDGETY] rebuild: " + e.message); }
}

function _flushDisk() {
  _diskTimer = null;
  if (!_dirty) return;
  _dirty = false;
  try { fs.writeFileSync(path.join(widgetsDir(), "widget_state.json"), _full); } catch {}
}

function setState(state) { _state = state && typeof state === "object" ? state : {}; _rebuild(); }
function getState() { return _state; }
function touch() { _rebuild(); }

function _json(res, buf, code = 200) {
  res.writeHead(code, { "Content-Type": "application/json; charset=utf-8", "Content-Length": buf.length, "Cache-Control": "no-store", "Access-Control-Allow-Origin": "*" });
  res.end(buf);
}

function sendStaticFile(res, filePath) {
  try {
    if (!filePath || !fs.existsSync(filePath) || !fs.statSync(filePath).isFile()) {
      res.writeHead(404, { "Content-Type": "text/plain; charset=utf-8", "Access-Control-Allow-Origin": "*" }); return res.end("Not found");
    }
    const ext = path.extname(filePath).toLowerCase();
    const types = { ".html": "text/html; charset=utf-8", ".css": "text/css; charset=utf-8", ".js": "application/javascript; charset=utf-8", ".json": "application/json; charset=utf-8", ".txt": "text/plain; charset=utf-8", ".png": "image/png", ".jpg": "image/jpeg", ".jpeg": "image/jpeg", ".webp": "image/webp", ".svg": "image/svg+xml", ".mp3": "audio/mpeg", ".wav": "audio/wav", ".m4a": "audio/mp4", ".aac": "audio/aac", ".ogg": "audio/ogg", ".oga": "audio/ogg", ".opus": "audio/ogg", ".flac": "audio/flac" };
    const stat = fs.statSync(filePath);
    const headers = { "Content-Type": types[ext] || "application/octet-stream", "Cache-Control": "no-store", "Access-Control-Allow-Origin": "*", "Accept-Ranges": "bytes" };
    // Range — żeby <audio> mogło przewijać podkłady.
    const range = res.req && res.req.headers && res.req.headers.range;
    if (range) {
      const m = /bytes=(\d*)-(\d*)/.exec(range);
      if (m) {
        const start = m[1] ? parseInt(m[1], 10) : 0;
        const end = m[2] ? parseInt(m[2], 10) : stat.size - 1;
        if (start <= end && end < stat.size) {
          res.writeHead(206, { ...headers, "Content-Range": `bytes ${start}-${end}/${stat.size}`, "Content-Length": end - start + 1 });
          return fs.createReadStream(filePath, { start, end }).pipe(res);
        }
      }
    }
    res.writeHead(200, { ...headers, "Content-Length": stat.size });
    fs.createReadStream(filePath).pipe(res);
  } catch {
    try { res.writeHead(500, { "Content-Type": "text/plain; charset=utf-8" }); res.end("Server error"); } catch {}
  }
}

function start({ port, extra, onPilot, onDev, onPortBusy }) {
  if (_server) return;
  _port = Number(port) || 8760;
  if (typeof extra === "function") _extra = extra;
  if (typeof onPilot === "function") _onPilot = onPilot;
  if (typeof onDev === "function") _onDev = onDev;
  writeAssetFiles();
  _rebuild();
  _server = http.createServer((req, res) => {
    try {
      res.req = req;
      const parsed = new URL(req.url || "/", `http://127.0.0.1:${_port}`);
      let pathname = decodeURIComponent(parsed.pathname || "/");
      if (pathname === "/" || pathname === "/index.html") pathname = "/demo.html";
      if (pathname.startsWith("/dzwieki/")) return sendStaticFile(res, safeJoin(sound.soundsDir(), pathname.replace(/^\/dzwieki\//, "")));
      if (pathname.startsWith("/pilot/")) {
        const akcja = pathname.slice(7);
        const ok = ["next", "prev", "skip", "unlock", "read"].includes(akcja);
        if (ok) _onPilot(akcja);
        return _json(res, Buffer.from(JSON.stringify({ ok, akcja })), ok ? 200 : 404);
      }
      // Trasy deweloperskie (tylko gdy main przekaże onDev, czyli w trybie dev): otwieranie paneli
      // i wysyłanie komend do silnika z curl — do testów automatycznych.
      if (_onDev && pathname.startsWith("/dev/")) {
        const [, , kind, name] = pathname.split("/");
        let payload = {};
        try { payload = JSON.parse(parsed.searchParams.get("json") || "{}"); } catch {}
        Promise.resolve(_onDev(kind, name, payload))
          .then((out) => _json(res, Buffer.from(JSON.stringify({ ok: true, out: out === undefined ? null : out }))))
          .catch((err) => _json(res, Buffer.from(JSON.stringify({ ok: false, error: String((err && err.message) || err) }))));
        return;
      }
      if (pathname === "/widget_state.json") return _json(res, _full);
      if (pathname === "/widget_state_slim.json" || pathname === "/widget_state_lite.json") return _json(res, _slim);
      if (/^\/widget-[a-z0-9-]+\.html$/i.test(pathname)) {
        const ref = String(req.headers.referer || "");
        if (!ref.includes("widget-wszystko")) _usage.set(pathname.replace(/^\/|\.html$/gi, ""), Date.now());
      }
      return sendStaticFile(res, safeJoin(widgetsDir(), pathname.replace(/^\/+/, "")));
    } catch (e) {
      try { res.writeHead(500, { "Content-Type": "text/plain; charset=utf-8" }); res.end("Server error"); } catch {}
    }
  });
  _server.on("error", (e) => {
    diag.warn(`[WIDGETY] Port ${_port}: ${e.message}`);
    _server = null;
    try { onPortBusy && onPortBusy(_port, e.message); } catch {}
  });
  _server.listen(_port, "127.0.0.1", () => diag.info(`[WIDGETY] http://127.0.0.1:${_port}/demo.html`));
}

function stop() { if (_server) { try { _server.close(); } catch {} _server = null; } _flushDisk(); }
function port() { return _port; }
function usage() { const out = {}; for (const [k, v] of _usage) out[k] = v; return out; }

module.exports = { start, stop, setState, getState, touch, port, usage, widgetsDir, writeAssetFiles, COMBO_PARTS: T.COMBO_PARTS, COMBO_DEFAULT_LAYOUT: T.COMBO_DEFAULT_LAYOUT };
