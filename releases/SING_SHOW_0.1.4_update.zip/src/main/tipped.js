// =========================
// TIPPED — webhook HTTP (parser kwot, podpis, dedup) przeniesiony z KVRINA_SHOW.
// Routing po kwocie (czytanie / zamówienie / poniżej progu) robi SILNIK — tutaj tylko
// zamieniamy payload na czysty obiekt wpłaty i przekazujemy dalej.
// =========================
const http = require("http");
const crypto = require("crypto");
const path = require("path");
const diag = require("./diag");
const { getOutputDir, readJson, writeJson } = require("./paths");

let _server = null;
let _port = 8797;
let _hash = "";
let _seen = new Set();
let _onDonation = () => {};
let _unsignedCount = 0;
let _lastAt = 0;

function _seenPath() { return path.join(getOutputDir(), "tipped_seen_orders.json"); }
function loadSeen() { const arr = readJson(_seenPath(), []); if (Array.isArray(arr)) _seen = new Set(arr.map(String)); }
function saveSeen() { writeJson(_seenPath(), Array.from(_seen).slice(-5000)); }

function safeTimingEqualString(a, b) {
  try {
    const aa = Buffer.from(String(a || "")); const bb = Buffer.from(String(b || ""));
    if (aa.length !== bb.length) return false;
    return crypto.timingSafeEqual(aa, bb);
  } catch { return false; }
}
function normalizeSignatureValue(v) {
  return String(v || "").trim().replace(/^sha256=/i, "").replace(/^Bearer\s+/i, "").trim();
}

// Zwraca { ok, signed } — signed=false gdy wpłata przyszła bez żadnego podpisu (przyjmujemy,
// ale panel pokaże licznik takich wpłat).
function verifySignature(req, rawBody) {
  const expected = String(_hash || "").trim();
  if (!expected) return { ok: true, signed: false };
  try {
    let queryHash = "";
    try {
      const u = new URL(req.url || "/webhook", `http://127.0.0.1:${_port}`);
      queryHash = u.searchParams.get("hash") || u.searchParams.get("webhook_hash") || u.searchParams.get("secret") || "";
    } catch {}
    let payloadHash = "";
    try {
      const parsed = JSON.parse(rawBody || "{}");
      payloadHash = parsed.hash || parsed.webhook_hash || parsed.webhookHash || parsed.secret || parsed.signature || "";
    } catch {}
    const direct = [queryHash, payloadHash, req.headers["x-tipped-hash"], req.headers["x-webhook-hash"], req.headers["x-hook-secret"], req.headers["x-tipped-secret"], req.headers["authorization"]]
      .map(normalizeSignatureValue).filter(Boolean);
    if (direct.some((v) => safeTimingEqualString(v, expected))) return { ok: true, signed: true };
    const sig = normalizeSignatureValue(req.headers["x-tipped-signature"] || req.headers["x-signature"] || "");
    if (sig) {
      if (safeTimingEqualString(sig, expected)) return { ok: true, signed: true };
      const h = crypto.createHmac("sha256", expected).update(rawBody).digest("hex");
      if (safeTimingEqualString(sig, h)) return { ok: true, signed: true };
      return { ok: false, signed: false };
    }
    return { ok: true, signed: false };
  } catch (e) {
    diag.warn("[TIPPED] Błąd weryfikacji podpisu: " + e.message);
    return { ok: true, signed: false };
  }
}

function _num(v) {
  const n = typeof v === "number" ? v : parseFloat(String(v || "").replace(",", "."));
  return Number.isFinite(n) ? n : null;
}

function getAmount(payload) {
  try {
    const keys = ["amount", "amount_value", "amountValue", "value", "price", "gross_amount", "grossAmount", "amount_gross", "amountGross", "amount_brutto", "amountBrutto", "amount_pln", "amountPLN"];
    const normalizePln = (n, rawVal) => {
      if (n === null || n === undefined || !Number.isFinite(n)) return null;
      const rawStr = typeof rawVal === "string" ? rawVal.trim() : "";
      const rawLooksDecimal = rawStr && /[.,]\d{1,2}\s*$/.test(rawStr);
      if (!rawLooksDecimal && Number.isInteger(n) && n >= 1000) return Math.round((n / 100) * 100) / 100; // grosze
      return Math.round(n * 100) / 100;
    };
    for (const k of keys) {
      if (payload && Object.prototype.hasOwnProperty.call(payload, k)) {
        const n = _num(payload[k]);
        if (n !== null) { const pln = normalizePln(n, payload[k]); if (pln !== null) return pln; }
      }
    }
  } catch {}
  return null;
}

function extractGoalLabel(payload) {
  try {
    const KEY_HINT = /(goal|cel|zbi[oó]rka|zbiorka|campaign|collection|target|fund|fundraiser|purpose|event)/i;
    const isEmpty = (s) => { const t = String(s || "").trim(); return !t || /^[-–—]+$/.test(t); };
    const fromValue = (v, depth) => {
      if (depth > 6 || v === null || v === undefined) return null;
      if (typeof v === "string") { const t = v.trim(); return isEmpty(t) ? null : t; }
      if (typeof v !== "object") return null;
      if (Array.isArray(v)) { for (const it of v) { const r = fromValue(it, depth + 1); if (r) return r; } return null; }
      for (const k of ["name", "title", "label", "goalName", "campaignName", "campaignTitle"]) {
        if (typeof v[k] === "string" && !isEmpty(v[k])) return String(v[k]).trim();
      }
      for (const [k, val] of Object.entries(v)) {
        if (typeof val === "string" && !isEmpty(val) && /name|title|label/i.test(String(k || ""))) return String(val).trim();
      }
      return null;
    };
    const seen = new Set();
    const scan = (obj, depth) => {
      if (depth > 6 || !obj || typeof obj !== "object") return null;
      if (seen.has(obj)) return null;
      seen.add(obj);
      if (Array.isArray(obj)) { for (const it of obj) { const r = scan(it, depth + 1); if (r) return r; } return null; }
      for (const [k, v] of Object.entries(obj)) {
        if (!k) continue;
        if (KEY_HINT.test(k)) { const label = fromValue(v, depth + 1); if (label) return label; }
        if (v && typeof v === "object") { const r = scan(v, depth + 1); if (r) return r; }
      }
      return null;
    };
    return scan(payload, 0);
  } catch { return null; }
}

function _respond(res, code, text) {
  res.writeHead(code, { "Content-Type": "text/plain; charset=utf-8" });
  res.end(text);
}

function start({ port, hash, onDonation }) {
  if (_server) return { ok: true, port: _port, already: true };
  _port = Number(port) || 8797;
  _hash = String(hash || "");
  if (typeof onDonation === "function") _onDonation = onDonation;
  loadSeen();
  _server = http.createServer((req, res) => {
    try {
      if (req.method === "GET" && req.url && req.url.startsWith("/webhook")) return _respond(res, 200, "SING OK");
      if (req.method !== "POST" || !req.url || !req.url.startsWith("/webhook")) return _respond(res, 404, "Not Found");
      let body = "";
      req.on("data", (chunk) => { body += chunk; if (body.length > 2_000_000) req.destroy(); });
      req.on("end", () => {
        const rawBody = body;
        const ver = verifySignature(req, rawBody);
        if (!ver.ok) return _respond(res, 401, "Invalid signature");
        let payload;
        try { payload = JSON.parse(rawBody || "{}"); } catch { return _respond(res, 400, "Bad JSON"); }
        const orderId = String(payload.order_id || payload.orderId || payload.id || "").trim();
        const nick = String(payload.payer_name || payload.payerName || payload.name || payload.nick || "Anon").trim().replace(/[\r\n]+/g, " ").slice(0, 80) || "Anon";
        const message = String(payload.message || payload.msg || "").trim().replace(/[\r\n]+/g, " ").slice(0, 400);
        if (orderId && _seen.has(orderId)) return _respond(res, 200, "OK (duplicate)");
        const amount = getAmount(payload);
        const goal = extractGoalLabel(payload);
        if (orderId) { _seen.add(orderId); saveSeen(); }
        if (!ver.signed) _unsignedCount++;
        _lastAt = Date.now();
        const donation = {
          id: orderId || ("d" + Date.now().toString(36) + Math.random().toString(36).slice(2, 6)),
          ts: Date.now(), nick, amount: amount === null ? 0 : amount, amountKnown: amount !== null, message, goal: goal || null,
          signed: !!ver.signed, source: "tipped",
        };
        diag.info(`[TIPPED] ${nick} ${donation.amount} zł${goal ? " (zbiórka: " + goal + ")" : ""}${message ? " — " + message.slice(0, 60) : ""}${ver.signed ? "" : " [bez podpisu]"}`);
        try { _onDonation(donation); } catch (e) { diag.warn("[TIPPED] onDonation: " + e.message); }
        return _respond(res, 200, "OK");
      });
    } catch (e) {
      diag.warn("[TIPPED] Błąd serwera: " + e.message);
      try { _respond(res, 500, "Server error"); } catch {}
    }
  });
  _server.on("error", (e) => { diag.warn(`[TIPPED] Port ${_port} zajęty lub błąd: ${e.message}`); _server = null; });
  _server.listen(_port, "127.0.0.1", () => diag.info(`[TIPPED] Webhook nasłuchuje na http://127.0.0.1:${_port}/webhook`));
  return { ok: true, port: _port };
}

function stop() {
  if (!_server) return;
  try { _server.close(); } catch {}
  _server = null;
  diag.info("[TIPPED] Webhook zatrzymany.");
}

function setHash(h) { _hash = String(h || ""); }
function status() { return { running: !!_server, port: _port, unsignedCount: _unsignedCount, lastAt: _lastAt, hashSet: !!_hash }; }

module.exports = { start, stop, status, setHash, getAmount, extractGoalLabel };
