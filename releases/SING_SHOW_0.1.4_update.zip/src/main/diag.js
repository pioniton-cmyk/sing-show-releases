// Diagnostyka: log w pamięci + plik obok danych programu + rozgłaszanie do okien.
// (Wzorowane na KVRINA_SHOW; bez wysyłania issue na GitHuba — żadnych tokenów w kodzie.)
const path = require("path");
const fs = require("fs");
const { BrowserWindow } = require("electron");
const { getOutputDir } = require("./paths");

const DIAG_LOG_FILE = "sing_diagnostics.log";
const DIAG_MAX_MEM = 400;
const _log = [];

function broadcast(channel, payload) {
  try {
    for (const win of BrowserWindow.getAllWindows()) {
      try { if (!win.isDestroyed()) win.webContents.send(channel, payload); } catch {}
    }
  } catch {}
}

function _entry(level, msg) {
  const entry = { ts: new Date().toISOString(), level, msg: String(msg).slice(0, 800) };
  _log.push(entry);
  if (_log.length > DIAG_MAX_MEM) _log.shift();
  try {
    const logPath = path.join(getOutputDir(), DIAG_LOG_FILE);
    fs.appendFileSync(logPath, `[${entry.ts}] [${level}] ${entry.msg}\n`);
    const stat = fs.statSync(logPath);
    if (stat.size > 300000) {
      const lines = fs.readFileSync(logPath, "utf8").split("\n");
      fs.writeFileSync(logPath, lines.slice(-600).join("\n"));
    }
  } catch {}
  try { console.log(`[${level}] ${entry.msg}`); } catch {}
  broadcast("diag-log-entry", entry);
}

const diag = {
  info: (m) => _entry("INFO", m),
  warn: (m) => _entry("WARN", m),
  error: (m) => _entry("ERROR", m),
  getLog: () => _log.slice(),
  clear: () => { _log.length = 0; try { fs.writeFileSync(path.join(getOutputDir(), DIAG_LOG_FILE), ""); } catch {} },
  broadcast,
};

process.on("uncaughtException", (err) => { try { _entry("CRASH", (err && err.stack) || String(err)); } catch {} });
process.on("unhandledRejection", (r) => { try { _entry("REJECT", (r && r.stack) || String(r)); } catch {} });

module.exports = diag;
