// =========================
// LEKTOR (TTS) — czyta donejty na głos. Kolejka: jeden komunikat naraz.
// macOS: wbudowane `say` (głosy polskie: Zosia, Ewa, Krzysztof — jeśli zainstalowane w systemie).
// Windows: PowerShell + System.Speech. Linux: espeak-ng / spd-say jeśli są.
// Głos idzie na wyjście systemowe — w TikTok Studio trzeba dodać "dźwięk pulpitu",
// żeby widzowie go słyszeli (instrukcja w panelu).
// =========================
const { spawn, execSync } = require("child_process");
const diag = require("./diag");

const _queue = [];
let _current = null;
let _onState = () => {};
let _voices = null;

function init({ onState } = {}) { if (typeof onState === "function") _onState = onState; }

function _emit() { _onState({ speaking: !!_current, queued: _queue.length, text: _current ? _current.text : null }); }

function listVoices() {
  if (_voices) return _voices;
  try {
    if (process.platform === "darwin") {
      const out = execSync("say -v ?", { encoding: "utf8" });
      _voices = out.split("\n").map((l) => l.trim()).filter(Boolean).map((l) => {
        const m = l.match(/^(.+?)\s{2,}([a-z]{2}_[A-Z]{2})\s+#\s*(.*)$/) || l.match(/^(\S+)\s+([a-z]{2}_[A-Z]{2})/);
        return m ? { name: m[1].trim(), lang: m[2] } : null;
      }).filter(Boolean);
      // polskie na górę
      _voices.sort((a, b) => (b.lang.startsWith("pl") - a.lang.startsWith("pl")) || a.name.localeCompare(b.name));
    } else if (process.platform === "win32") {
      const ps = "Add-Type -AssemblyName System.Speech; (New-Object System.Speech.Synthesis.SpeechSynthesizer).GetInstalledVoices() | % { $_.VoiceInfo.Name + '|' + $_.VoiceInfo.Culture }";
      const out = execSync(`powershell -NoProfile -Command "${ps}"`, { encoding: "utf8" });
      _voices = out.split("\n").map((l) => l.trim()).filter(Boolean).map((l) => { const [name, lang] = l.split("|"); return { name, lang: lang || "" }; });
    } else {
      _voices = [{ name: "default", lang: "pl" }];
    }
  } catch (e) {
    diag.warn("[LEKTOR] Nie mogę pobrać listy głosów: " + e.message);
    _voices = [];
  }
  return _voices;
}

function defaultVoice() {
  const v = listVoices();
  const pl = v.find((x) => /^pl/i.test(x.lang));
  return pl ? pl.name : (v[0] ? v[0].name : "");
}

function _spawnSpeak(text, opts) {
  const voice = (opts && opts.voice) || defaultVoice();
  const rate = Math.max(90, Math.min(400, Number(opts && opts.rate) || 180));
  if (process.platform === "darwin") {
    const args = [];
    if (voice) args.push("-v", voice);
    args.push("-r", String(rate), text);
    return spawn("say", args);
  }
  if (process.platform === "win32") {
    const safe = text.replace(/[`"$]/g, " ").replace(/'/g, "''");
    const rateWin = Math.max(-10, Math.min(10, Math.round((rate - 180) / 20)));
    const ps = `Add-Type -AssemblyName System.Speech; $s = New-Object System.Speech.Synthesis.SpeechSynthesizer; ${voice ? `try { $s.SelectVoice('${voice.replace(/'/g, "''")}') } catch {}; ` : ""}$s.Rate = ${rateWin}; $s.Speak('${safe}')`;
    return spawn("powershell", ["-NoProfile", "-Command", ps], { windowsHide: true });
  }
  try { return spawn("spd-say", ["-w", "-l", "pl", text]); } catch { return spawn("espeak-ng", ["-v", "pl", text]); }
}

function _next() {
  if (_current || !_queue.length) { _emit(); return; }
  const item = _queue.shift();
  _current = item;
  _emit();
  let proc;
  try { proc = _spawnSpeak(item.text, item.opts); } catch (e) { diag.warn("[LEKTOR] " + e.message); _current = null; return _next(); }
  const done = () => { _current = null; _emit(); setTimeout(_next, 250); };
  proc.on("exit", done);
  proc.on("error", (e) => { diag.warn("[LEKTOR] błąd: " + e.message); done(); });
  item.proc = proc;
}

function speak(text, opts) {
  const t = String(text || "").replace(/\s+/g, " ").trim();
  if (!t) return;
  _queue.push({ text: t.slice(0, 600), opts: opts || {} });
  _next();
}

function stopAll() {
  _queue.length = 0;
  if (_current && _current.proc) { try { _current.proc.kill(); } catch {} }
  _current = null;
  _emit();
}

function status() { return { speaking: !!_current, queued: _queue.length }; }

module.exports = { init, speak, stopAll, listVoices, defaultVoice, status };
