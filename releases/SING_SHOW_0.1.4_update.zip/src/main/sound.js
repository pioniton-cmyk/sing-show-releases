// =========================
// DŹWIĘKI: foldery + lista plików + biblioteka podkładów.
// Odtwarza ukryte okno-silnik (zawsze żywe), pliki serwowane po HTTP z serwera widgetów.
// =========================
const path = require("path");
const fs = require("fs");
const { dialog, shell } = require("electron");
const { sub, getOutputDir } = require("./paths");

const SOUNDS_DIR = "dzwieki";
const FOLDERS = {
  powiadomienia: "krótki dźwięk przy nowym donejcie",
  odblokowanie: "dźwięk gdy tapy odblokują kolejną piosenkę",
  armata: "wystrzał armaty giftów",
  muzyka: "muzyka w tle (np. w przerwach)",
  podklady: "BIBLIOTEKA PODKŁADÓW — z niej układasz playlistę (nazwa pliku: Wykonawca - Tytuł.mp3)",
};
const AUDIO_EXTS = [".mp3", ".wav", ".m4a", ".ogg", ".oga", ".aac", ".flac", ".opus"];

function soundsDir() { return sub(SOUNDS_DIR); }
function dirFor(kind) { return FOLDERS[kind] ? sub(SOUNDS_DIR, kind) : soundsDir(); }

function listAudioFiles(dir) {
  try {
    return fs.readdirSync(dir)
      .filter((f) => !f.startsWith(".") && AUDIO_EXTS.includes(path.extname(f).toLowerCase()))
      .sort((a, b) => a.localeCompare(b, "pl"));
  } catch { return []; }
}

function ensureFolders() {
  for (const k of Object.keys(FOLDERS)) dirFor(k);
  const readme = path.join(soundsDir(), "JAK-UZYWAC.txt");
  if (!fs.existsSync(readme)) {
    fs.writeFileSync(readme, [
      "DŹWIĘKI W SING_SHOW",
      "",
      ...Object.entries(FOLDERS).map(([k, d]) => `${k}/  — ${d}`),
      "",
      "Obsługiwane formaty: mp3, wav, m4a, ogg, aac, flac, opus.",
      "Głośności ustawiasz w programie: menu → DŹWIĘK. Podkłady: panel PLAYLISTA → BIBLIOTEKA.",
      "Nowe pliki wykrywają się same (co 30 s) — nie trzeba restartować programu.",
      "",
    ].join("\n"), "utf8");
  }
}

// Podkład: "Wykonawca - Tytuł.mp3" → { file, title, artist }
function parseTrackName(file) {
  const base = String(file || "").replace(/\.[^.]+$/, "").trim();
  const m = base.match(/^(.+?)\s+[-–—]\s+(.+)$/);
  if (m) return { file, artist: m[1].trim(), title: m[2].trim() };
  return { file, artist: "", title: base };
}

function libraryList() {
  return listAudioFiles(dirFor("podklady")).map((f) => {
    const st = (() => { try { return fs.statSync(path.join(dirFor("podklady"), f)); } catch { return null; } })();
    return { ...parseTrackName(f), size: st ? st.size : 0, mtime: st ? st.mtimeMs : 0 };
  });
}

// Import plików do biblioteki (kopiujemy, nie linkujemy — żeby playlista nie psuła się po
// przeniesieniu oryginałów).
async function importToLibrary(parentWin) {
  const r = await dialog.showOpenDialog(parentWin || null, {
    title: "Wybierz podkłady do biblioteki",
    properties: ["openFile", "multiSelections"],
    filters: [{ name: "Audio", extensions: AUDIO_EXTS.map((e) => e.slice(1)) }],
  });
  if (r.canceled || !r.filePaths.length) return { ok: true, imported: 0 };
  let n = 0;
  for (const src of r.filePaths) {
    try {
      const dest = path.join(dirFor("podklady"), path.basename(src));
      if (path.resolve(src) === path.resolve(dest)) { n++; continue; }
      fs.copyFileSync(src, dest); n++;
    } catch {}
  }
  return { ok: true, imported: n };
}

function state() {
  ensureFolders();
  const out = {};
  for (const k of Object.keys(FOLDERS)) out[k] = listAudioFiles(dirFor(k));
  return out;
}

function openFolder(kind) { ensureFolders(); shell.openPath(dirFor(kind)); }

function removeFromLibrary(file) {
  try {
    const p = path.join(dirFor("podklady"), path.basename(String(file || "")));
    if (fs.existsSync(p)) { shell.trashItem(p); return true; }
  } catch {}
  return false;
}

module.exports = { ensureFolders, state, listAudioFiles, dirFor, soundsDir, libraryList, importToLibrary, openFolder, removeFromLibrary, parseTrackName, AUDIO_EXTS, FOLDERS, getOutputDir };
