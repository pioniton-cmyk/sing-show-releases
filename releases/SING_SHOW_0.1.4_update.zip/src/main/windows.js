// =========================
// OKNA: ukryty silnik + czytnik + panele (fabryka z tabeli) + pamięć położenia.
// Przeniesione z KVRINA_SHOW (sanityzacja pod zniknięte monitory).
// =========================
const { BrowserWindow, screen, nativeImage, app } = require("electron");
const path = require("path");
const fs = require("fs");
const { getOutputDir, readJson, writeJson } = require("./paths");

const ROOT = path.join(__dirname, "..", "..");
const PRELOAD = path.join(ROOT, "preload.js");
const WINDOW_STATE_JSON = "window_state.json";
const MIN_W = 260, MIN_H = 200;
const BG = "#0f1220";

const PANEL_WINDOW_CONFIG = {
  playlista:   { file: "panels/panel_playlista.html",   title: "SING_SHOW — Playlista i biblioteka", width: 1100, height: 760 },
  tipped:      { file: "panels/panel_tipped.html",      title: "SING_SHOW — Tipped / donejty",        width: 900,  height: 700 },
  ustawienia:  { file: "panels/panel_ustawienia.html",  title: "SING_SHOW — Ustawienia i profile",    width: 760,  height: 820 },
  ranking:     { file: "panels/panel_ranking.html",     title: "SING_SHOW — Ranking widzów",          width: 400,  height: 600 },
  widgety:     { file: "panels/panel_widgety.html",     title: "SING_SHOW — Widgety",                  width: 1180, height: 800 },
  dzwiek:      { file: "panels/panel_dzwiek.html",      title: "SING_SHOW — Dźwięk",                   width: 460,  height: 640 },
  diagnostyka: { file: "panels/panel_diagnostyka.html", title: "SING_SHOW — Diagnostyka",              width: 820,  height: 600 },
  gifty:       { file: "panels/panel_gifty.html",       title: "SING_SHOW — Gifty / aktywność",        width: 420,  height: 600 },
  uklad:       { file: "panels/panel_uklad.html",       title: "SING_SHOW — Układ widgetu zbiorczego", width: 720,  height: 860 },
  aktualizacje:{ file: "panels/panel_aktualizacje.html",title: "SING_SHOW — Aktualizacje",             width: 560,  height: 560 },
};

let engineWindow = null;
let readerWindow = null;
const panelWindows = {};
let isQuitting = false;

function setQuitting(v) { isQuitting = !!v; }

// ---- pamięć położenia ----
function _statePath() { return path.join(getOutputDir(), WINDOW_STATE_JSON); }
function loadWindowState() { const o = readJson(_statePath(), {}); return o && typeof o === "object" ? o : {}; }
function saveWindowState(s) { return writeJson(_statePath(), s || {}); }
function _rectIntersects(a, b) { return a && b && a.x < b.x + b.width && a.x + a.width > b.x && a.y < b.y + b.height && a.y + a.height > b.y; }
function _clamp(n, min, max) { if (!Number.isFinite(n)) return min; if (max < min) return min; return Math.max(min, Math.min(max, n)); }
function getDisplayById(id) { try { return screen.getAllDisplays().find((d) => String(d.id) === String(id)) || null; } catch { return null; } }

function sanitizeWindowBounds(savedBounds, displayId, fallbackWidth, fallbackHeight) {
  const displays = screen.getAllDisplays();
  const primary = screen.getPrimaryDisplay();
  const saved = savedBounds && typeof savedBounds === "object" ? savedBounds : {};
  let width = _clamp(Math.round(Number(saved.width) || fallbackWidth || 900), MIN_W, 10000);
  let height = _clamp(Math.round(Number(saved.height) || fallbackHeight || 600), MIN_H, 10000);
  const requested = { x: Math.round(Number(saved.x)), y: Math.round(Number(saved.y)), width, height };
  const valid = Number.isFinite(requested.x) && Number.isFinite(requested.y);
  const target = getDisplayById(displayId) || (valid ? screen.getDisplayMatching(requested) : null) || primary;
  const wa = target.workArea || target.bounds;
  if (valid && displays.some((d) => _rectIntersects(requested, d.workArea || d.bounds))) {
    return { x: _clamp(requested.x, wa.x - Math.round(width * 0.85), wa.x + wa.width - Math.round(width * 0.15)), y: _clamp(requested.y, wa.y, wa.y + wa.height - 80), width, height };
  }
  return { x: Math.round(wa.x + Math.max(0, (wa.width - width) / 2)), y: Math.round(wa.y + Math.max(0, (wa.height - height) / 2)), width: Math.min(width, wa.width), height: Math.min(height, wa.height) };
}

function getSavedWindowOptions(name, defaults) {
  const st = loadWindowState();
  const item = st[name] || null;
  const bounds = sanitizeWindowBounds(item && item.bounds, item && item.displayId, defaults.width, defaults.height);
  return { ...bounds, isMaximized: !!(item && item.isMaximized), isFullScreen: !!(item && item.isFullScreen) };
}

function persistWindowPlacement(name, win) {
  try {
    if (!win || win.isDestroyed()) return;
    const st = loadWindowState();
    const bounds = (win.isMaximized() || win.isFullScreen()) ? win.getNormalBounds() : win.getBounds();
    const display = screen.getDisplayMatching(bounds);
    st[name] = { bounds, displayId: display ? display.id : null, isMaximized: win.isMaximized(), isFullScreen: win.isFullScreen(), savedAt: new Date().toISOString() };
    saveWindowState(st);
  } catch {}
}

function attachWindowPlacementMemory(name, win) {
  let t = null;
  const schedule = () => { if (t) clearTimeout(t); t = setTimeout(() => persistWindowPlacement(name, win), 350); };
  for (const ev of ["move", "resize", "maximize", "unmaximize", "enter-full-screen", "leave-full-screen"]) win.on(ev, schedule);
  win.on("close", () => persistWindowPlacement(name, win));
}

function appIcon() {
  try {
    const p = path.join(ROOT, "icon.icns");
    if (fs.existsSync(p)) { const img = nativeImage.createFromPath(p); if (!img.isEmpty()) return img; }
  } catch {}
  return undefined;
}

// ---- silnik (ukryty) ----
function createEngineWindow() {
  if (engineWindow && !engineWindow.isDestroyed()) return engineWindow;
  engineWindow = new BrowserWindow({
    width: 1100, height: 760, show: false, icon: appIcon(),
    title: "SING_SHOW — silnik",
    backgroundColor: BG,
    webPreferences: { preload: PRELOAD, nodeIntegration: false, contextIsolation: true, backgroundThrottling: false },
  });
  if (app.dock && appIcon()) { try { app.dock.setIcon(appIcon()); } catch {} }
  engineWindow.loadFile(path.join(ROOT, "engine.html"));
  engineWindow.on("close", (e) => { if (!isQuitting) { e.preventDefault(); try { engineWindow.hide(); } catch {} } });
  engineWindow.on("closed", () => { engineWindow = null; });
  return engineWindow;
}

// ---- czytnik (jedyne okno widoczne na starcie) ----
function createReaderWindow() {
  if (readerWindow && !readerWindow.isDestroyed()) { try { readerWindow.focus(); } catch {} return readerWindow; }
  const saved = getSavedWindowOptions("readerWindow", { width: 1200, height: 880 });
  readerWindow = new BrowserWindow({
    width: saved.width, height: saved.height, x: saved.x, y: saved.y, minWidth: 760, minHeight: 480,
    title: "SING_SHOW", backgroundColor: BG, icon: appIcon(),
    webPreferences: { preload: PRELOAD, contextIsolation: true, nodeIntegration: false },
  });
  attachWindowPlacementMemory("readerWindow", readerWindow);
  if (saved.isMaximized) { try { readerWindow.maximize(); } catch {} }
  readerWindow.setMenuBarVisibility(false);
  readerWindow.loadFile(path.join(ROOT, "reader.html"));
  readerWindow.on("closed", () => { readerWindow = null; });
  return readerWindow;
}

// ---- panele ----
function createPanelWindow(panel) {
  const cfg = PANEL_WINDOW_CONFIG[panel];
  if (!cfg) return null;
  if (panelWindows[panel] && !panelWindows[panel].isDestroyed()) { try { panelWindows[panel].focus(); } catch {} return panelWindows[panel]; }
  const key = `panel_${panel}`;
  const saved = getSavedWindowOptions(key, { width: cfg.width, height: cfg.height });
  const win = new BrowserWindow({
    width: saved.width, height: saved.height, x: saved.x, y: saved.y, minWidth: MIN_W, minHeight: MIN_H,
    title: cfg.title, backgroundColor: BG, icon: appIcon(),
    webPreferences: { preload: PRELOAD, contextIsolation: true, nodeIntegration: false },
  });
  attachWindowPlacementMemory(key, win);
  win.setMenuBarVisibility(false);
  win.loadFile(path.join(ROOT, cfg.file));
  win.once("ready-to-show", () => { try { win.focus(); } catch {} });
  win.on("closed", () => { panelWindows[panel] = null; });
  panelWindows[panel] = win;
  return win;
}

function getEngine() { return engineWindow && !engineWindow.isDestroyed() ? engineWindow : null; }
function getReader() { return readerWindow && !readerWindow.isDestroyed() ? readerWindow : null; }

function sendToEngine(channel, payload) {
  const w = getEngine();
  if (w) { try { w.webContents.send(channel, payload); } catch {} }
}
function broadcast(channel, payload) {
  for (const win of BrowserWindow.getAllWindows()) { try { if (!win.isDestroyed()) win.webContents.send(channel, payload); } catch {} }
}

module.exports = {
  PANEL_WINDOW_CONFIG, createEngineWindow, createReaderWindow, createPanelWindow,
  getEngine, getReader, sendToEngine, broadcast, setQuitting, getSavedWindowOptions, attachWindowPlacementMemory,
};
