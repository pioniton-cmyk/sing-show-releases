// =========================
// AUTO-AKTUALIZACJE — bez żadnych tokenów w kodzie (inaczej niż w KVRINA_SHOW).
// Schemat: publiczny plik latest.json na raw.githubusercontent → ZIP z plikami programu →
// kopia zapasowa obecnej wersji → podmiana plików → restart.
// Kopie zapasowe: SING_SHOW TXT/kopie_wersji/backup_<data>/ (przywracalne jednym przyciskiem).
// =========================
const { app } = require("electron");
const https = require("https");
const http = require("http");
const path = require("path");
const fs = require("fs");
const os = require("os");
const { execFileSync } = require("child_process");
const diag = require("./diag");
const { sub, ensureDir } = require("./paths");

const REPO = "pioniton-cmyk/sing-show-releases";
// SING_UPDATES_URL pozwala wskazać inne źródło (używane przy testowaniu mechanizmu aktualizacji).
const LATEST_URL = process.env.SING_UPDATES_URL || `https://raw.githubusercontent.com/${REPO}/main/latest.json`;

// Pliki lokalne, których aktualizacja NIGDY nie nadpisuje ani nie usuwa.
const SKIP_NAMES = new Set(["node_modules", "dist", "kopie_wersji", ".git", ".DS_Store", "cloudflared-sing-show.json", "euler-key.json"]);

function appDir() { return path.join(__dirname, "..", ".."); }
function backupsDir() { return sub("kopie_wersji"); }

function getRequest(url, redirects = 0) {
  return new Promise((resolve, reject) => {
    if (redirects > 3) return reject(new Error("Za dużo przekierowań"));
    const mod = String(url).startsWith("http://") ? http : https;
    const req = mod.get(url, { headers: { "User-Agent": "SING_SHOW", "Cache-Control": "no-cache" }, timeout: 12000 }, (res) => {
      if (res.statusCode >= 300 && res.statusCode < 400 && res.headers.location) {
        res.resume();
        return resolve(getRequest(res.headers.location, redirects + 1));
      }
      if (res.statusCode !== 200) {
        res.resume();
        // 404 zwykle nie znaczy "brak internetu", tylko że nie ma jeszcze paczki/repozytorium wydań.
        return reject(new Error(res.statusCode === 404 ? "nie ma jeszcze opublikowanej wersji (404)" : "HTTP " + res.statusCode));
      }
      const chunks = [];
      res.on("data", (c) => chunks.push(c));
      res.on("end", () => resolve(Buffer.concat(chunks)));
    });
    req.on("timeout", () => { req.destroy(new Error("Przekroczono czas oczekiwania")); });
    req.on("error", reject);
  });
}

function compareVersions(a, b) {
  const pa = String(a || "0").split(".").map((n) => parseInt(n, 10) || 0);
  const pb = String(b || "0").split(".").map((n) => parseInt(n, 10) || 0);
  for (let i = 0; i < Math.max(pa.length, pb.length); i++) {
    const d = (pa[i] || 0) - (pb[i] || 0);
    if (d) return d > 0 ? 1 : -1;
  }
  return 0;
}

async function check() {
  try {
    const buf = await getRequest(LATEST_URL);
    const info = JSON.parse(buf.toString("utf8"));
    const current = app.getVersion();
    const newer = compareVersions(info.version, current) > 0;
    diag.info(`[AKTUALIZACJE] Zdalna wersja ${info.version}, lokalna ${current}${newer ? " — jest nowsza!" : ""}`);
    return { ok: true, current, latest: info.version, newer, notes: info.notes || "", zipUrl: info.zipUrl || "", publishedAt: info.publishedAt || null };
  } catch (e) {
    diag.warn("[AKTUALIZACJE] Sprawdzanie nieudane: " + e.message);
    return { ok: false, error: e.message, current: app.getVersion() };
  }
}

function unzipTo(zipPath, destDir) {
  ensureDir(destDir);
  if (process.platform === "win32") {
    execFileSync("powershell", ["-NoProfile", "-Command", `Expand-Archive -LiteralPath '${zipPath.replace(/'/g, "''")}' -DestinationPath '${destDir.replace(/'/g, "''")}' -Force`], { stdio: "ignore" });
  } else {
    execFileSync("unzip", ["-o", "-q", zipPath, "-d", destDir], { stdio: "ignore" });
  }
}

function copyDir(src, dest, skip) {
  ensureDir(dest);
  for (const entry of fs.readdirSync(src, { withFileTypes: true })) {
    if (skip && skip.has(entry.name)) continue;
    const s = path.join(src, entry.name);
    const d = path.join(dest, entry.name);
    if (entry.isDirectory()) copyDir(s, d, skip);
    else if (entry.isFile()) fs.copyFileSync(s, d);
  }
}

function stamp() {
  const d = new Date();
  const p = (n) => String(n).padStart(2, "0");
  return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}_${p(d.getHours())}-${p(d.getMinutes())}-${p(d.getSeconds())}`;
}

// Wersję do nazwy kopii czytamy z pliku na dysku, nie z app.getVersion() — to drugie jest
// zapamiętane przy starcie i po aktualizacji bez restartu pokazywałoby starą wartość.
function versionOnDisk() {
  try { return JSON.parse(fs.readFileSync(path.join(appDir(), "package.json"), "utf8")).version || app.getVersion(); }
  catch { return app.getVersion(); }
}

function makeBackup() {
  const dir = path.join(backupsDir(), `backup_${stamp()}_v${versionOnDisk()}`);
  copyDir(appDir(), dir, SKIP_NAMES);
  // Zostawiamy najwyżej 5 ostatnich kopii, żeby nie zjadały dysku.
  try {
    const all = fs.readdirSync(backupsDir()).filter((f) => f.startsWith("backup_")).sort();
    for (const old of all.slice(0, Math.max(0, all.length - 5))) fs.rmSync(path.join(backupsDir(), old), { recursive: true, force: true });
  } catch {}
  return dir;
}

async function install(zipUrl, onProgress) {
  const progress = (stage, extra) => { try { onProgress && onProgress({ stage, ...(extra || {}) }); } catch {} };
  try {
    if (!zipUrl) throw new Error("Brak adresu paczki");
    progress("pobieranie");
    const zip = await getRequest(zipUrl);
    if (!zip || zip.length < 1000) throw new Error("Paczka wygląda na uszkodzoną");
    const tmp = fs.mkdtempSync(path.join(os.tmpdir(), "sing-update-"));
    const zipPath = path.join(tmp, "update.zip");
    fs.writeFileSync(zipPath, zip);
    progress("rozpakowywanie");
    const outDir = path.join(tmp, "out");
    unzipTo(zipPath, outDir);
    // Paczka bywa spakowana z jednym folderem w środku — wchodzimy do niego.
    let src = outDir;
    const entries = fs.readdirSync(src, { withFileTypes: true }).filter((e) => e.name !== "__MACOSX" && !e.name.startsWith("."));
    if (entries.length === 1 && entries[0].isDirectory()) src = path.join(src, entries[0].name);
    // Kontrola zdrowego rozsądku — bez tego pusta/zła paczka zabiłaby program.
    for (const must of ["main.js", "package.json", "reader.html", "engine.js"]) {
      if (!fs.existsSync(path.join(src, must))) throw new Error(`Paczka niekompletna (brak ${must}) — nic nie zmieniam`);
    }
    progress("kopia-zapasowa");
    const backup = makeBackup();
    progress("instalowanie");
    copyDir(src, appDir(), new Set(["node_modules", ".git", ".DS_Store", "__MACOSX", "euler-key.json", "cloudflared-sing-show.json"]));
    try { fs.rmSync(tmp, { recursive: true, force: true }); } catch {}
    diag.info(`[AKTUALIZACJE] Zainstalowano. Kopia poprzedniej wersji: ${backup}`);
    progress("gotowe", { backup });
    return { ok: true, backup };
  } catch (e) {
    diag.warn("[AKTUALIZACJE] Instalacja nieudana: " + e.message);
    progress("blad", { error: e.message });
    return { ok: false, error: e.message };
  }
}

function listBackups() {
  try {
    return fs.readdirSync(backupsDir()).filter((f) => f.startsWith("backup_")).sort().reverse().map((name) => {
      let version = "";
      try { version = JSON.parse(fs.readFileSync(path.join(backupsDir(), name, "package.json"), "utf8")).version || ""; } catch {}
      return { name, version, path: path.join(backupsDir(), name) };
    });
  } catch { return []; }
}

function restore(name) {
  try {
    const list = listBackups();
    const target = name ? list.find((b) => b.name === name) : list[0];
    if (!target) return { ok: false, error: "Brak kopii zapasowej" };
    if (!fs.existsSync(path.join(target.path, "main.js"))) return { ok: false, error: "Kopia niekompletna" };
    makeBackup(); // najpierw kopia obecnego stanu — cofnięcie cofnięcia też ma być możliwe
    copyDir(target.path, appDir(), new Set(["node_modules", ".git", ".DS_Store", "euler-key.json", "cloudflared-sing-show.json"]));
    diag.info(`[AKTUALIZACJE] Przywrócono wersję z ${target.name}`);
    return { ok: true, restored: target.name, version: target.version };
  } catch (e) {
    return { ok: false, error: e.message };
  }
}

function restart() {
  try { app.relaunch(); app.exit(0); } catch (e) { diag.warn("[AKTUALIZACJE] Restart nieudany: " + e.message); }
}

module.exports = { check, install, listBackups, restore, restart, compareVersions, backupsDir, REPO, LATEST_URL };
