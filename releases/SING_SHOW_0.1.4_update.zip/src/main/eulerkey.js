// =========================
// KLUCZ EULER STREAM — zapis, odczyt i sprawdzenie.
// Klucz trzymamy w pliku euler-key.json obok programu (a jeśli tam się nie da — w folderze danych).
// Nigdy nie ląduje w kodzie ani w publicznych paczkach aktualizacji.
// =========================
const path = require("path");
const fs = require("fs");
const https = require("https");
const diag = require("./diag");
const { getOutputDir } = require("./paths");

const FILE_NAME = "euler-key.json";
const RATE_URL = "https://api.eulerstream.com/webcast/rate_limits";

function appDirFile() { return path.join(__dirname, "..", "..", FILE_NAME); }
function dataDirFile() { return path.join(getOutputDir(), FILE_NAME); }

function readFrom(file) {
  try {
    if (!fs.existsSync(file)) return "";
    const raw = JSON.parse(fs.readFileSync(file, "utf8"));
    return String((raw && (raw.apiKey || raw.key || raw.signApiKey)) || "").trim();
  } catch (e) {
    diag.warn(`[KLUCZ] Nie mogę odczytać ${file}: ${e.message}`);
    return "";
  }
}

// Zwraca { key, source, file } — source: "obok programu" | "folder danych" | "brak"
function read() {
  const a = readFrom(appDirFile());
  if (a) return { key: a, source: "obok programu", file: appDirFile() };
  const b = readFrom(dataDirFile());
  if (b) return { key: b, source: "folder danych", file: dataDirFile() };
  return { key: "", source: "brak", file: null };
}

function write(key) {
  const value = String(key || "").trim();
  const body = {
    _opis: "Klucz Euler Stream do podpisywania połączeń z TikTok LIVE. Plik lokalny — nie trafia do repozytorium ani do paczek aktualizacji.",
    apiKey: value,
  };
  // Najpierw próbujemy obok programu (przeżywa przenoszenie folderu danych), a gdy katalog jest
  // tylko do odczytu (np. aplikacja w /Applications) — do folderu danych użytkowniczki.
  for (const file of [appDirFile(), dataDirFile()]) {
    try {
      fs.writeFileSync(file, JSON.stringify(body, null, 2), "utf8");
      diag.info(`[KLUCZ] Zapisano klucz (…${value.slice(-4)}) w ${file}`);
      return { ok: true, file };
    } catch (e) {
      diag.warn(`[KLUCZ] Nie mogę zapisać w ${file}: ${e.message}`);
    }
  }
  return { ok: false, error: "Nie mogę zapisać pliku z kluczem — sprawdź uprawnienia folderu." };
}

function clear() {
  let removed = 0;
  for (const file of [appDirFile(), dataDirFile()]) {
    try { if (fs.existsSync(file)) { fs.unlinkSync(file); removed++; } } catch {}
  }
  if (removed) diag.info("[KLUCZ] Klucz usunięty.");
  return { ok: true, removed };
}

// Sprawdza klucz w Euler Stream i zwraca limity — to jedyny sposób, żeby PRZED live'em
// wiedzieć, czy klucz w ogóle działa (i ile zapytań zostało na dziś).
function test(key) {
  const value = String(key || "").trim();
  return new Promise((resolve) => {
    const req = https.get(RATE_URL, {
      headers: { "x-api-key": value, "User-Agent": "SING_SHOW" },
      timeout: 12000,
    }, (res) => {
      const chunks = [];
      res.on("data", (c) => chunks.push(c));
      res.on("end", () => {
        const text = Buffer.concat(chunks).toString("utf8");
        let data = null;
        try { data = JSON.parse(text); } catch {}
        if (res.statusCode === 401 || (data && data.code === 401)) {
          return resolve({ ok: false, error: (data && data.message) || "Klucz odrzucony przez Euler Stream." });
        }
        if (res.statusCode !== 200 || !data) {
          return resolve({ ok: false, error: `Serwer odpowiedział ${res.statusCode}.` });
        }
        const day = data.day || {}, hour = data.hour || {}, minute = data.minute || {};
        // Limity bez klucza to 100/dobę — jeśli tyle wyszło mimo podanego klucza, klucz nie zadziałał.
        const looksAnonymous = Number(day.max) <= 100;
        resolve({
          ok: !looksAnonymous,
          anonymous: looksAnonymous,
          error: looksAnonymous ? "Euler nie rozpoznał tego klucza — pokazuje limity jak dla braku klucza." : null,
          day: { max: day.max, remaining: day.remaining, resetAt: day.reset_at || null },
          hour: { max: hour.max, remaining: hour.remaining },
          minute: { max: minute.max, remaining: minute.remaining },
        });
      });
    });
    req.on("timeout", () => { req.destroy(); resolve({ ok: false, error: "Euler Stream nie odpowiedział w 12 s." }); });
    req.on("error", (e) => resolve({ ok: false, error: "Brak połączenia: " + e.message }));
  });
}

function status() {
  const r = read();
  return {
    source: r.source,
    file: r.file,
    masked: r.key ? `…${r.key.slice(-4)}` : "",
    hasKey: !!r.key,
    appDirWritable: (() => { try { fs.accessSync(path.dirname(appDirFile()), fs.constants.W_OK); return true; } catch { return false; } })(),
  };
}

module.exports = { read, write, clear, test, status, FILE_NAME };
