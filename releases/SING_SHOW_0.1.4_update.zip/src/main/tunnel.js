// =========================
// CLOUDFLARED — publiczny adres dla webhooka Tipped.
// Tryb "quick": `cloudflared tunnel --url http://127.0.0.1:PORT` → losowy *.trycloudflare.com
// (zero konfiguracji, adres zmienia się po restarcie — do testów i na start).
// Tryb "named": własna domena (jak kvrina.wiedzmabasia.com) — config YAML + plik poświadczeń;
// skonfigurujemy później, kod jest gotowy.
// Sprzątanie procesów przeniesione z KVRINA_SHOW (SIGKILL po 2 s + zabijanie sierot).
// =========================
const { app } = require("electron");
const { spawn, execSync } = require("child_process");
const path = require("path");
const fs = require("fs");
const diag = require("./diag");

let _proc = null;
let _url = null;
let _onChange = () => {};
const MARK = "sing-show-tunnel"; // znacznik w argumentach, po którym rozpoznajemy własne procesy

function getCommand() {
  if (process.platform === "darwin") {
    for (const p of ["/opt/homebrew/bin/cloudflared", "/usr/local/bin/cloudflared"]) if (fs.existsSync(p)) return p;
  }
  return "cloudflared";
}

function isInstalled() {
  try {
    const cmd = getCommand();
    if (cmd.startsWith("/")) return fs.existsSync(cmd);
    execSync(process.platform === "win32" ? "where cloudflared" : "which cloudflared", { stdio: "ignore" });
    return true;
  } catch { return false; }
}

function killOrphans() {
  if (process.platform === "win32") return;
  try {
    const out = execSync(`pgrep -f ${JSON.stringify(MARK)} || true`, { encoding: "utf8" });
    for (const line of out.split("\n")) {
      const pid = parseInt(line.trim(), 10);
      if (pid && pid !== process.pid) { try { process.kill(pid, "SIGKILL"); diag.warn(`[TUNEL] Zabito osierocony cloudflared pid=${pid}`); } catch {} }
    }
  } catch {}
}

function _namedConfigPath() { return path.join(app.getPath("userData"), "sing-tunnel-config.yml"); }

function start({ port, mode, named, onChange } = {}) {
  if (typeof onChange === "function") _onChange = onChange;
  if (_proc) return { ok: true, url: _url, already: true };
  if (!isInstalled()) {
    const hint = process.platform === "darwin" ? "brew install cloudflared" : "winget install Cloudflare.cloudflared";
    diag.warn(`[TUNEL] Brak cloudflared. Zainstaluj: ${hint}`);
    return { ok: false, error: `Brak cloudflared (${hint})` };
  }
  killOrphans();
  let args;
  if (mode === "named" && named && named.tunnelId && named.hostname && named.credsFile) {
    const yml = [
      `tunnel: ${named.tunnelId}`,
      `credentials-file: ${named.credsFile}`,
      "ingress:",
      `  - hostname: ${named.hostname}`,
      `    service: http://127.0.0.1:${port}`,
      "  - service: http_status:404",
      `# ${MARK}`,
      "",
    ].join("\n");
    fs.writeFileSync(_namedConfigPath(), yml, "utf8");
    args = ["tunnel", "--config", _namedConfigPath(), "run", "--label", MARK];
    _url = `https://${named.hostname}`;
  } else {
    args = ["tunnel", "--url", `http://127.0.0.1:${port}`, "--no-autoupdate", "--label", MARK];
    _url = null;
  }
  try {
    _proc = spawn(getCommand(), args, { windowsHide: true });
  } catch (e) {
    diag.warn("[TUNEL] Nie mogę uruchomić cloudflared: " + e.message);
    _proc = null;
    return { ok: false, error: e.message };
  }
  const onLine = (line) => {
    const m = line.match(/https:\/\/[a-z0-9-]+\.trycloudflare\.com/i);
    if (m && !_url) { _url = m[0]; diag.info(`[TUNEL] Adres publiczny: ${_url}`); _onChange({ running: true, url: _url }); }
    if (/error|failed|ERR/i.test(line) && !/context canceled/i.test(line)) diag.warn("[TUNEL] " + line.trim().slice(0, 200));
  };
  const pipe = (stream) => { let buf = ""; stream.on("data", (d) => { buf += d.toString(); let i; while ((i = buf.indexOf("\n")) >= 0) { onLine(buf.slice(0, i)); buf = buf.slice(i + 1); } }); };
  pipe(_proc.stdout); pipe(_proc.stderr);
  _proc.on("exit", (code) => { diag.info(`[TUNEL] cloudflared zakończył (kod ${code}).`); _proc = null; _url = null; _onChange({ running: false, url: null }); });
  _onChange({ running: true, url: _url });
  return { ok: true, url: _url };
}

function stop() {
  if (_proc) {
    const p = _proc;
    try { p.kill(); } catch {}
    setTimeout(() => { try { if (!p.killed) p.kill("SIGKILL"); } catch {} }, 2000);
  }
  _proc = null; _url = null;
  _onChange({ running: false, url: null });
}

function status() { return { running: !!_proc, url: _url, installed: isInstalled() }; }

module.exports = { start, stop, status, killOrphans, isInstalled };
