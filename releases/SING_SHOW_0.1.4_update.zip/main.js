// SING_SHOW — proces główny. Spina moduły z src/main i rejestruje IPC.
// Architektura (jak KVRINA_SHOW): ukryte okno-silnik (engine.html) trzyma cały stan sesji;
// czytnik i panele to "głupie" widoki, które dostają stan przez IPC i wysyłają komendy.
const { app, BrowserWindow, ipcMain, dialog, clipboard, shell, globalShortcut } = require("electron");
const path = require("path");
const fs = require("fs");

const paths = require("./src/main/paths");
const diag = require("./src/main/diag");
const config = require("./src/main/config");
const tiktok = require("./src/main/tiktok");
const tipped = require("./src/main/tipped");
const tunnel = require("./src/main/tunnel");
const sound = require("./src/main/sound");
const tts = require("./src/main/tts");
const windows = require("./src/main/windows");
const widgets = require("./src/main/widgets/server");
const updates = require("./src/main/updates");
const eulerkey = require("./src/main/eulerkey");

const IS_DEV = !app.isPackaged;
let _lastState = {};
let _stateTimer = null;
let _soundNowPlaying = { track: null, playing: false };
let _ttsState = { speaking: false, queued: 0 };

// ---------- pomocnicze ----------
function toEngine(channel, payload) { windows.sendToEngine(channel, payload); }
function broadcast(channel, payload) { windows.broadcast(channel, payload); }
function activeProfile() { return config.getProfile(); }

function effectiveComboLayout(p) {
  const prof = p || activeProfile();
  const saved = (prof && prof.comboLayout) || {};
  const out = {};
  for (const k of widgets.COMBO_PARTS) {
    const d = widgets.COMBO_DEFAULT_LAYOUT[k];
    const s = saved[k] || {};
    out[k] = {
      x: Number.isFinite(Number(s.x)) ? Number(s.x) : d.x,
      y: Number.isFinite(Number(s.y)) ? Number(s.y) : d.y,
      scale: Number.isFinite(Number(s.scale)) && Number(s.scale) > 0 ? Number(s.scale) : d.scale,
      enabled: s.enabled === undefined ? d.enabled : !!s.enabled,
    };
  }
  return out;
}

function broadcastStateSoon() {
  if (_stateTimer) return;
  _stateTimer = setTimeout(() => { _stateTimer = null; broadcast("state", _lastState); }, 120);
}

// Skróty globalne — działają, gdy okno programu nie jest na wierzchu (śpiewa, nie klika).
// Rejestracja bywa nieudana, jeśli inny program zajął kombinację — mówimy o tym w logu,
// zamiast po cichu udawać, że działa.
const SHORTCUT_CMDS = { next: { name: "next", payload: { force: true } }, prev: { name: "prev" }, skip: { name: "skip" }, unlock: { name: "unlock" }, read: { name: "don-read" } };
let _shortcutState = { registered: [], failed: [] };

function applyShortcuts() {
  try { globalShortcut.unregisterAll(); } catch {}
  _shortcutState = { registered: [], failed: [] };
  const sc = config.getGlobal().shortcuts || {};
  if (!sc.enabled) { broadcast("shortcuts-state", _shortcutState); return _shortcutState; }
  for (const [key, cmd] of Object.entries(SHORTCUT_CMDS)) {
    const accel = String(sc[key] || "").trim();
    if (!accel) continue;
    try {
      const ok = globalShortcut.register(accel, () => toEngine("engine-cmd", { name: cmd.name, payload: cmd.payload || {} }));
      if (ok) _shortcutState.registered.push({ key, accel });
      else _shortcutState.failed.push({ key, accel, reason: "zajęty przez inny program" });
    } catch (e) {
      _shortcutState.failed.push({ key, accel, reason: e.message });
    }
  }
  if (_shortcutState.failed.length) diag.warn("[SKRÓTY] Nie udało się przypisać: " + _shortcutState.failed.map((f) => f.accel).join(", "));
  else if (_shortcutState.registered.length) diag.info(`[SKRÓTY] Aktywne: ${_shortcutState.registered.map((r) => r.accel).join(", ")}`);
  broadcast("shortcuts-state", _shortcutState);
  return _shortcutState;
}

function startTunnel() {
  const g = config.getGlobal();
  return tunnel.start({ port: g.tippedPort, mode: g.tunnel.mode, named: g.tunnel.named, onChange: (s) => broadcast("tunnel-state", s) });
}

function applyProfileToServices(prof) {
  const p = prof || activeProfile();
  const g = config.getGlobal();
  tipped.setHash(p.tipped.hash);
  if (p.tipped.enabled) tipped.start({ port: g.tippedPort, hash: p.tipped.hash, onDonation: (d) => toEngine("tipped-donation", d) });
  else tipped.stop();
  broadcast("profile-changed", p);
  widgets.touch();
}

// ---------- cykl życia ----------
// Druga uruchomiona kopia programu nie miałaby jak zająć portów (webhook, widgety) i wyglądałaby
// na "zawieszoną". Zamiast tego pokazujemy okno tej już działającej i zamykamy nową.
const _gotLock = app.requestSingleInstanceLock();
if (!_gotLock) {
  app.quit();
} else {
  app.on("second-instance", () => {
    const w = windows.getReader() || windows.createReaderWindow();
    try { if (w.isMinimized()) w.restore(); w.show(); w.focus(); } catch {}
  });
}

app.whenReady().then(() => {
  if (!_gotLock) return;
  diag.info(`SING_SHOW ${app.getVersion()} start (${IS_DEV ? "dev" : "packaged"}), dane: ${paths.getOutputDir()}`);
  config.load();
  sound.ensureFolders();
  const g = config.getGlobal();

  tiktok.init({
    onEvent: (event, data) => toEngine("tiktok-event", { event, data: data || {} }),
    onState: (st) => broadcast("tiktok-state", st),
  });
  tts.init({ onState: (st) => { _ttsState = st; broadcast("tts-state", st); } });

  widgets.start({
    onPortBusy: (port, err) => {
      diag.warn(`[WIDGETY] Port ${port} zajęty: ${err}`);
      dialog.showErrorBox("SING_SHOW — port zajęty",
        `Nie mogę uruchomić serwera widgetów na porcie ${port} — używa go inny program (najczęściej druga kopia SING_SHOW).\n\nZamknij drugą kopię i uruchom program ponownie. Port możesz też zmienić w pliku config.json w folderze SING_SHOW TXT.`);
    },
    port: g.widgetPort,
    extra: () => ({ comboLayout: effectiveComboLayout() }),
    onPilot: (akcja) => toEngine("engine-cmd", { name: "pilot", payload: { akcja } }),
    onDev: IS_DEV ? (kind, name, payload) => {
      if (kind === "open") { if (name === "silnik") { const w = windows.getEngine(); if (w) w.show(); } else if (name === "czytnik") windows.createReaderWindow(); else windows.createPanelWindow(name); return "open:" + name; }
      if (kind === "cmd") { toEngine("engine-cmd", { name, payload }); return "cmd:" + name; }
      if (kind === "layout") { const cur = effectiveComboLayout(); cur[name] = { ...cur[name], ...payload }; config.updateProfile({ comboLayout: cur }); widgets.touch(); return cur[name]; }
      if (kind === "tiktok") { toEngine("tiktok-event", { event: name, data: payload || {} }); return "tiktok:" + name; }
      if (kind === "update") {
        if (name === "check") return updates.check();
        if (name === "install") return updates.install(payload.zipUrl, (pr) => broadcast("update-progress", pr));
        if (name === "backups") return updates.listBackups();
        if (name === "restore") return updates.restore(payload.name);
        return null;
      }
      if (kind === "global") { const g = config.updateGlobal(payload); if (payload.shortcuts) applyShortcuts(); return g; }
      return null;
    } : null,
  });

  windows.createEngineWindow();
  windows.createReaderWindow();
  applyProfileToServices();

  applyShortcuts();

  // Tunel — tylko w zapakowanej wersji startuje sam (w dev nie gryzie się z działającą instalką).
  if (!IS_DEV && g.tunnel.autostart !== false) { try { startTunnel(); } catch {} }

  // Ciche sprawdzenie aktualizacji po starcie — samo nic nie instaluje, tylko melduje oknom.
  if (!IS_DEV && (g.updates || {}).checkOnStart !== false) {
    setTimeout(async () => { const r = await updates.check(); if (r.ok && r.newer) broadcast("update-available", r); }, 6000);
  }

  app.on("activate", () => { if (!windows.getReader()) windows.createReaderWindow(); });
});

app.on("before-quit", () => { windows.setQuitting(true); });
app.on("will-quit", () => { try { tunnel.stop(); } catch {} try { tipped.stop(); } catch {} try { widgets.stop(); } catch {} try { tts.stopAll(); } catch {} try { globalShortcut.unregisterAll(); } catch {} });
app.on("window-all-closed", () => { /* silnik jest ukryty — zamykamy dopiero z menu / Cmd+Q */ if (process.platform !== "darwin") app.quit(); });

// Gdy użytkownik zamknie czytnik, a silnik wisi ukryty — na macOS program zostaje w docku,
// na Windows zamykamy wszystko, żeby nie został proces-duch.
app.on("browser-window-closed", () => {
  setTimeout(() => {
    const visible = BrowserWindow.getAllWindows().filter((w) => !w.isDestroyed() && w.isVisible());
    if (!visible.length && process.platform !== "darwin") app.quit();
  }, 200);
});

// ---------- IPC: aplikacja ----------
ipcMain.handle("app:info", async () => ({
  version: app.getVersion(), isDev: IS_DEV, platform: process.platform,
  outputDir: paths.getOutputDir(), widgetPort: widgets.port(), tippedPort: config.getGlobal().tippedPort,
}));
ipcMain.handle("app:openFolder", async (e, which) => {
  const map = { dane: paths.getOutputDir(), widgety: widgets.widgetsDir(), profil: config.profileDir() };
  shell.openPath(map[which] || paths.getOutputDir());
  return { ok: true };
});
ipcMain.handle("clipboard:copy", async (e, text) => { clipboard.writeText(String(text || "")); return { ok: true }; });
ipcMain.handle("dialog:confirm", async (e, { title, message, okLabel } = {}) => {
  const win = BrowserWindow.fromWebContents(e.sender);
  const r = await dialog.showMessageBox(win, { type: "warning", buttons: [okLabel || "TAK", "Anuluj"], defaultId: 1, cancelId: 1, title: title || "Potwierdź", message: message || "" });
  return { ok: r.response === 0 };
});
ipcMain.handle("panel:open", async (e, name) => {
  if (name === "silnik") { const w = windows.getEngine(); if (w) { w.show(); w.focus(); } return { ok: true }; }
  if (name === "czytnik") { windows.createReaderWindow(); return { ok: true }; }
  return { ok: !!windows.createPanelWindow(name) };
});
ipcMain.handle("diag:log", async () => diag.getLog());
ipcMain.handle("diag:clear", async () => { diag.clear(); return { ok: true }; });

// ---------- IPC: profile ----------
ipcMain.handle("profile:list", async () => config.listProfiles());
ipcMain.handle("profile:get", async (e, slug) => config.getProfile(slug));
ipcMain.handle("profile:update", async (e, patch, slug) => {
  const p = config.updateProfile(patch, slug);
  if (!slug || slug === config.activeSlug()) applyProfileToServices(p);
  return p;
});
ipcMain.handle("profile:create", async (e, { name, copyFrom } = {}) => config.createProfile(name, copyFrom));
ipcMain.handle("profile:delete", async (e, slug) => ({ ok: config.deleteProfile(slug) }));
ipcMain.handle("profile:activate", async (e, slug) => {
  const ok = config.setActiveProfile(slug);
  if (ok) { applyProfileToServices(); toEngine("engine-cmd", { name: "profile-switched", payload: { slug } }); }
  return { ok };
});

// ---------- IPC: TikTok ----------
ipcMain.handle("tiktok:connect", async (e, { username, apiKey } = {}) => {
  const p = activeProfile();
  const u = username || p.tiktok.username;
  const k = apiKey !== undefined ? apiKey : p.tiktok.apiKey;
  if (username && username !== p.tiktok.username) config.updateProfile({ tiktok: { username } });
  return tiktok.connect(u, k);
});
ipcMain.handle("tiktok:disconnect", async () => tiktok.disconnect(true));
ipcMain.handle("tiktok:state", async () => tiktok.getState());

// ---------- IPC: Tipped / tunel ----------
ipcMain.handle("tipped:status", async () => ({ ...tipped.status(), tunnel: tunnel.status(), localUrl: `http://127.0.0.1:${config.getGlobal().tippedPort}/webhook` }));
ipcMain.handle("tipped:setEnabled", async (e, on) => { config.updateProfile({ tipped: { enabled: !!on } }); applyProfileToServices(); return tipped.status(); });
ipcMain.handle("tipped:test", async (e, d = {}) => {
  const donation = {
    id: "test-" + Date.now().toString(36), ts: Date.now(), nick: String(d.nick || "Testowa_Ania").slice(0, 80),
    amount: Math.round((Number(d.amount) || 25) * 100) / 100, amountKnown: true, message: String(d.message || "").slice(0, 400),
    goal: d.goal ? String(d.goal) : null, signed: true, source: "test",
  };
  toEngine("tipped-donation", donation);
  return { ok: true };
});
ipcMain.handle("tunnel:start", async () => startTunnel());
ipcMain.handle("tunnel:stop", async () => { tunnel.stop(); return { ok: true }; });
ipcMain.handle("tunnel:status", async () => tunnel.status());

// ---------- IPC: dźwięk / biblioteka ----------
ipcMain.handle("sound:state", async () => ({
  ok: true, folders: sound.state(), library: sound.libraryList(), nowPlaying: _soundNowPlaying,
  baseUrl: `http://127.0.0.1:${widgets.port()}/dzwieki`, settings: activeProfile().sound,
}));
ipcMain.handle("sound:openFolder", async (e, kind) => { sound.openFolder(kind); return { ok: true }; });
ipcMain.handle("sound:importLibrary", async (e) => sound.importToLibrary(BrowserWindow.fromWebContents(e.sender)));
ipcMain.handle("sound:removeLibrary", async (e, file) => ({ ok: sound.removeFromLibrary(file) }));
ipcMain.handle("sound:control", async (e, payload) => { toEngine("sound-control", payload || {}); return { ok: true }; });
ipcMain.handle("sound:reportPlaying", async (e, payload) => { _soundNowPlaying = payload || { track: null, playing: false }; return { ok: true }; });

// ---------- IPC: lektor ----------
ipcMain.handle("tts:speak", async (e, { text, voice, rate } = {}) => {
  const p = activeProfile();
  tts.speak(text, { voice: voice || p.tts.voice, rate: rate || p.tts.rate });
  return { ok: true };
});
ipcMain.handle("tts:stop", async () => { tts.stopAll(); return { ok: true }; });
ipcMain.handle("tts:voices", async () => ({ voices: tts.listVoices(), defaultVoice: tts.defaultVoice() }));
ipcMain.handle("tts:status", async () => _ttsState);

// ---------- IPC: stan i komendy ----------
ipcMain.handle("state:publish", async (e, state) => {
  _lastState = state && typeof state === "object" ? state : {};
  widgets.setState(_lastState);
  broadcastStateSoon();
  return { ok: true };
});
ipcMain.handle("state:get", async () => _lastState);
ipcMain.handle("cmd", async (e, { name, payload } = {}) => { toEngine("engine-cmd", { name, payload }); return { ok: true }; });

// ---------- IPC: playlisty i sesja (pliki w profile/<slug>/) ----------
function playlistsDir() { return paths.sub("profile", config.activeSlug(), "playlisty"); }
ipcMain.handle("playlist:list", async () => {
  try {
    return fs.readdirSync(playlistsDir()).filter((f) => f.endsWith(".json")).map((f) => {
      const full = path.join(playlistsDir(), f);
      const data = paths.readJson(full, {});
      return { name: f.replace(/\.json$/, ""), count: Array.isArray(data.items) ? data.items.length : 0, savedAt: data.savedAt || null };
    }).sort((a, b) => a.name.localeCompare(b.name, "pl"));
  } catch { return []; }
});
ipcMain.handle("playlist:save", async (e, { name, items } = {}) => {
  const n = paths.slugify(name) || "playlista";
  const ok = paths.writeJson(path.join(playlistsDir(), n + ".json"), { name: String(name || n), items: Array.isArray(items) ? items : [], savedAt: new Date().toISOString() });
  return { ok, name: n };
});
ipcMain.handle("playlist:read", async (e, name) => paths.readJson(path.join(playlistsDir(), paths.slugify(name) + ".json"), null));
ipcMain.handle("playlist:delete", async (e, name) => { try { fs.unlinkSync(path.join(playlistsDir(), paths.slugify(name) + ".json")); return { ok: true }; } catch { return { ok: false }; } });
ipcMain.handle("playlist:importFile", async (e) => {
  const win = BrowserWindow.fromWebContents(e.sender);
  const r = await dialog.showOpenDialog(win, { title: "Wczytaj listę piosenek", properties: ["openFile"], filters: [{ name: "Lista", extensions: ["txt", "m3u", "m3u8", "csv"] }] });
  if (r.canceled || !r.filePaths.length) return { ok: false };
  try { return { ok: true, text: fs.readFileSync(r.filePaths[0], "utf8"), file: path.basename(r.filePaths[0]) }; } catch (err) { return { ok: false, error: err.message }; }
});
ipcMain.handle("session:save", async (e, data, slug) => ({ ok: paths.writeJson(path.join(config.profileDir(slug || undefined), "session.json"), data || {}) }));
ipcMain.handle("session:load", async (e, slug) => paths.readJson(path.join(config.profileDir(slug || undefined), "session.json"), null));
ipcMain.handle("log:append", async (e, { file, line } = {}) => { paths.appendLine(path.join(config.profileDir(), String(file || "log.jsonl").replace(/[^a-z0-9_.-]/gi, "_")), String(line || "")); return { ok: true }; });

// ---------- IPC: układ widgetu zbiorczego / eko ----------
ipcMain.handle("widgets:layout:get", async () => ({ layout: effectiveComboLayout(), parts: widgets.COMBO_PARTS }));
ipcMain.handle("widgets:layout:set", async (e, patch) => {
  const cur = effectiveComboLayout();
  for (const k of Object.keys(patch || {})) if (widgets.COMBO_PARTS.includes(k)) cur[k] = { ...cur[k], ...patch[k] };
  config.updateProfile({ comboLayout: cur });
  widgets.touch();
  return { layout: cur };
});
ipcMain.handle("widgets:layout:reset", async () => { config.updateProfile({ comboLayout: null }); widgets.touch(); return { layout: effectiveComboLayout() }; });
ipcMain.handle("widgets:usage", async () => widgets.usage());

// ---------- IPC: ustawienia globalne (porty, tunel, skróty) ----------
ipcMain.handle("global:get", async () => ({ ...config.getGlobal(), shortcutState: _shortcutState, platform: process.platform }));
ipcMain.handle("global:set", async (e, patch) => {
  const g = config.updateGlobal(patch || {});
  if (patch && patch.shortcuts) applyShortcuts();
  if (patch && patch.tunnel && tunnel.status().running) { tunnel.stop(); setTimeout(() => startTunnel(), 1200); }
  broadcast("global-changed", g);
  return g;
});
ipcMain.handle("global:pickCredsFile", async (e) => {
  const r = await dialog.showOpenDialog(BrowserWindow.fromWebContents(e.sender), {
    title: "Wybierz plik poświadczeń tunelu z Cloudflare (.json)",
    properties: ["openFile"], filters: [{ name: "Poświadczenia tunelu", extensions: ["json"] }],
  });
  if (r.canceled || !r.filePaths.length) return { ok: false };
  const src = r.filePaths[0];
  // Kopiujemy obok programu — plik NIE trafia do paczek aktualizacji (jest na liście pominięć).
  const dest = path.join(__dirname, "cloudflared-sing-show.json");
  try { fs.copyFileSync(src, dest); } catch (err) { return { ok: false, error: err.message }; }
  let tunnelId = "";
  try { tunnelId = JSON.parse(fs.readFileSync(dest, "utf8")).TunnelID || ""; } catch {}
  const g = config.updateGlobal({ tunnel: { named: { credsFile: dest, tunnelId: tunnelId || undefined } } });
  return { ok: true, credsFile: dest, tunnelId, global: g };
});

// ---------- IPC: aktualizacje ----------
ipcMain.handle("updates:check", async () => updates.check());
ipcMain.handle("updates:install", async (e, zipUrl) => updates.install(zipUrl, (p) => broadcast("update-progress", p)));
ipcMain.handle("updates:backups", async () => updates.listBackups());
ipcMain.handle("updates:restore", async (e, name) => updates.restore(name));
ipcMain.handle("updates:restart", async () => { updates.restart(); return { ok: true }; });

// ---------- IPC: klucz Euler Stream ----------
ipcMain.handle("key:status", async () => eulerkey.status());
ipcMain.handle("key:set", async (e, key) => {
  const r = eulerkey.write(key);
  if (r.ok) broadcast("key-changed", eulerkey.status());
  return r;
});
ipcMain.handle("key:clear", async () => { const r = eulerkey.clear(); broadcast("key-changed", eulerkey.status()); return r; });
// Pusty klucz = sprawdzamy ten zapisany; inaczej testujemy wpisany, jeszcze przed zapisem.
ipcMain.handle("key:test", async (e, key) => eulerkey.test(String(key || "").trim() || eulerkey.read().key));
