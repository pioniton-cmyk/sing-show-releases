// Most między oknami a procesem głównym. Każdy subskrybent `on*` zwraca funkcję
// odsubskrybowania (w KVRINA_SHOW removeAllListeners kasowało cudze nasłuchy — tu nie).
const { contextBridge, ipcRenderer } = require("electron");

function on(channel) {
  return (cb) => {
    if (typeof cb !== "function") return () => {};
    const handler = (evt, payload) => { try { cb(payload); } catch (e) { console.error(`[preload:${channel}]`, e); } };
    ipcRenderer.on(channel, handler);
    return () => ipcRenderer.removeListener(channel, handler);
  };
}
const inv = (channel) => (...args) => ipcRenderer.invoke(channel, ...args);

contextBridge.exposeInMainWorld("api", {
  // aplikacja
  info: inv("app:info"),
  openFolder: inv("app:openFolder"),
  clipboardCopy: inv("clipboard:copy"),
  confirm: inv("dialog:confirm"),
  openPanel: inv("panel:open"),
  diagLog: inv("diag:log"),
  diagClear: inv("diag:clear"),
  onDiagEntry: on("diag-log-entry"),

  // profile
  profileList: inv("profile:list"),
  profileGet: inv("profile:get"),
  profileUpdate: inv("profile:update"),
  profileCreate: inv("profile:create"),
  profileDelete: inv("profile:delete"),
  profileActivate: inv("profile:activate"),
  onProfileChanged: on("profile-changed"),

  // TikTok
  tiktokConnect: inv("tiktok:connect"),
  tiktokDisconnect: inv("tiktok:disconnect"),
  tiktokState: inv("tiktok:state"),
  onTiktokEvent: on("tiktok-event"),
  onTiktokState: on("tiktok-state"),

  // Tipped / tunel
  tippedStatus: inv("tipped:status"),
  tippedSetEnabled: inv("tipped:setEnabled"),
  tippedTest: inv("tipped:test"),
  onTippedDonation: on("tipped-donation"),
  tunnelStart: inv("tunnel:start"),
  tunnelStop: inv("tunnel:stop"),
  tunnelStatus: inv("tunnel:status"),
  onTunnelState: on("tunnel-state"),

  // dźwięk / biblioteka podkładów
  soundState: inv("sound:state"),
  soundOpenFolder: inv("sound:openFolder"),
  soundImportLibrary: inv("sound:importLibrary"),
  soundRemoveLibrary: inv("sound:removeLibrary"),
  soundControl: inv("sound:control"),
  soundReportPlaying: inv("sound:reportPlaying"),
  onSoundControl: on("sound-control"),

  // lektor
  ttsSpeak: inv("tts:speak"),
  ttsStop: inv("tts:stop"),
  ttsVoices: inv("tts:voices"),
  ttsStatus: inv("tts:status"),
  onTtsState: on("tts-state"),

  // stan i komendy
  statePublish: inv("state:publish"),
  stateGet: inv("state:get"),
  onState: on("state"),
  cmd: (name, payload) => ipcRenderer.invoke("cmd", { name, payload }),
  onEngineCmd: on("engine-cmd"),

  // playlisty / sesja
  playlistList: inv("playlist:list"),
  playlistSave: inv("playlist:save"),
  playlistRead: inv("playlist:read"),
  playlistDelete: inv("playlist:delete"),
  playlistImportFile: inv("playlist:importFile"),
  sessionSave: inv("session:save"),
  sessionLoad: inv("session:load"),
  logAppend: inv("log:append"),

  // ustawienia globalne (porty, tunel, skróty)
  globalGet: inv("global:get"),
  globalSet: inv("global:set"),
  pickCredsFile: inv("global:pickCredsFile"),
  onGlobalChanged: on("global-changed"),
  onShortcutsState: on("shortcuts-state"),

  // klucz Euler Stream
  keyStatus: inv("key:status"),
  keySet: inv("key:set"),
  keyClear: inv("key:clear"),
  keyTest: inv("key:test"),
  onKeyChanged: on("key-changed"),

  // aktualizacje
  updatesCheck: inv("updates:check"),
  updatesInstall: inv("updates:install"),
  updatesBackups: inv("updates:backups"),
  updatesRestore: inv("updates:restore"),
  updatesRestart: inv("updates:restart"),
  onUpdateAvailable: on("update-available"),
  onUpdateProgress: on("update-progress"),

  // widgety
  layoutGet: inv("widgets:layout:get"),
  layoutSet: inv("widgets:layout:set"),
  layoutReset: inv("widgets:layout:reset"),
  widgetsUsage: inv("widgets:usage"),
});
