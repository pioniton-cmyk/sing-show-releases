(() => {
  const { $, esc, label, toast, debounce } = window.PC;
  const api = window.api;
  const cmd = (n, p) => api.cmd(n, p || {});
  $("head").innerHTML = PC.head("Playlista i biblioteka podkładów");
  let S = null, lib = [], baseUrl = "", dragId = null, editing = null, pendingRender = false;

  // zakładki
  document.querySelectorAll(".tabs button").forEach((b) => b.onclick = () => {
    document.querySelectorAll(".tabs button").forEach((x) => x.classList.toggle("active", x === b));
    ["pl", "lib", "saved"].forEach((t) => $("tab-" + t).classList.toggle("hidden", b.dataset.tab !== t));
    if (b.dataset.tab === "lib") loadLib(); if (b.dataset.tab === "saved") loadSaved();
  });

  // ---- playlista ----
  // force = true: rysujemy zawsze (wejście w edycję, zapis, ręczne odświeżenie).
  // force pominięte: to odświeżenie ze stanu silnika — a ten przychodzi co kilka sekund
  // (w trakcie live'a przy każdym tapie). Gdy trwa edycja wiersza, pomijamy je, bo inaczej
  // pole, w które ktoś właśnie wpisuje próg tapów, znikałoby w trakcie pisania.
  function renderList(force) {
    if (!S) return;
    if (editing && !force) { pendingRender = true; return; }
    pendingRender = false;
    const items = S.playlistFull || [];
    const nowId = S.song && S.song.now ? S.song.now.id : null;
    $("plInfo").textContent = `${items.length} piosenek` + (S.song && S.song.name ? " · " + S.song.name : "");
    if (editing && !items.some((i) => i.id === editing)) editing = null;
    $("list").innerHTML = items.length ? items.map((it, i) => {
      const st = it.id === nowId ? "now" : it.status;
      const badge = st === "now" ? '<span class="tag acc">teraz</span>' : st === "unlocked" ? '<span class="tag ok">odblokowana</span>' : st === "locked" ? '<span class="tag">🔒 zablokowana</span>' : st === "done" ? '<span class="tag">zaśpiewana</span>' : '<span class="tag warn">pominięta</span>';
      const ord = it.order ? `<span class="tag gold">★ ${esc(it.order.by)}</span>` : "";
      const fileOpts = `<option value="">— bez podkładu —</option>` + lib.map((f) => `<option value="${esc(f.file)}" ${f.file === it.file ? "selected" : ""}>${esc(f.file)}</option>`).join("");
      const edit = editing === it.id ? `<div class="row wrap" style="margin-top:6px">
          <input class="inl" data-f="artist" value="${esc(it.artist)}" placeholder="wykonawca"> <input class="inl" data-f="title" value="${esc(it.title)}" placeholder="tytuł" style="min-width:160px">
          próg tapów <input class="inl th" data-f="threshold" type="number" min="1" step="10" value="${it.threshold || ""}" placeholder="dom." title="Ile tapów odblokuje TĘ piosenkę. Puste = wartość z USTAWIEŃ."> ♥
          <select class="inl" data-f="file">${fileOpts}</select>
          <button class="btn tiny ok" data-act="edit-done">OK</button></div>` : "";
      return `<div class="item ${st}" data-id="${it.id}" draggable="true"><span class="drag">⋮⋮</span><span class="muted tnum small">${i + 1}.</span>
        <div class="grow"><div class="t">${label(it)} ${ord} ${it.file ? '<span class="tag info">♪ podkład</span>' : ""}</div><div class="s" title="Kliknij, żeby ustawić próg tapów">${it.threshold ? `<b>próg ${it.threshold} ♥</b> · ` : ""}${badge}</div>${edit}</div>
        <div class="acts">
          ${st !== "now" ? '<button class="btn tiny" data-act="play-now" title="Śpiewaj teraz">▶</button>' : ""}
          ${st === "locked" ? '<button class="btn tiny info" data-act="unlock" title="Odblokuj">🔓</button>' : ""}
          ${st === "unlocked" ? '<button class="btn tiny" data-act="lock" title="Zablokuj">🔒</button>' : ""}
          ${st === "done" || st === "skipped" ? '<button class="btn tiny" data-act="song-reset" title="Przywróć do kolejki">↺</button>' : ""}
          <button class="btn tiny" data-act="edit" title="Edytuj">✎</button>
          <button class="btn tiny" data-act="up">↑</button><button class="btn tiny" data-act="down">↓</button>
          <button class="btn tiny bad" data-act="song-remove" title="Usuń">✕</button>
        </div></div>`;
    }).join("") : '<div class="empty">Pusta playlista. Wklej listę obok albo dodaj podkłady z biblioteki.</div>';
  }
  $("list").addEventListener("click", (e) => {
    const b = e.target.closest("[data-act]");
    if (!b) {
      // Klik w tytuł otwiera edycję — próg tapów ma być pod ręką, bez celowania w ikonkę ✎.
      const wiersz = e.target.closest(".item");
      if (wiersz && !e.target.closest("input, select, button") && editing !== wiersz.dataset.id) {
        editing = wiersz.dataset.id; renderList(true);
        const pole = $("list").querySelector(`.item[data-id="${wiersz.dataset.id}"] [data-f="threshold"]`);
        if (pole) pole.focus();
      }
      return;
    }
    const row = e.target.closest(".item"); const id = row.dataset.id; const act = b.dataset.act;
    if (act === "edit") {
      editing = id; renderList(true);
      const box = $("list").querySelector(`.item[data-id="${id}"] [data-f="title"]`);
      if (box) { box.focus(); box.select && box.select(); }
      return;
    }
    if (act === "edit-done") { zapiszEdycje(row, id); return; }
    if (act === "up" || act === "down") cmd("song-move", { id, dir: act }); else cmd(act, { id });
  });
  // Zapis edytowanego wiersza (przycisk OK, Enter albo kliknięcie poza wierszem).
  function zapiszEdycje(row, id) {
    if (!row || !id) return;
    const g = (f) => row.querySelector(`[data-f="${f}"]`);
    if (!g("title")) return;
    cmd("song-edit", {
      id,
      artist: g("artist").value,
      title: g("title").value,
      threshold: g("threshold").value ? Number(g("threshold").value) : null,
      file: g("file").value || null,
    });
    editing = null;
    renderList(true);
    toast("Zapisano");
  }

  // Enter zapisuje, Escape anuluje — żeby nie trzeba było celować w mały przycisk OK.
  $("list").addEventListener("keydown", (e) => {
    if (!editing) return;
    const row = e.target.closest(".item"); if (!row) return;
    if (e.key === "Enter") { e.preventDefault(); zapiszEdycje(row, row.dataset.id); }
    else if (e.key === "Escape") { e.preventDefault(); editing = null; renderList(true); }
  });

  // Kliknięcie poza edytowanym wierszem też zapisuje — inaczej wpisany próg przepadałby po cichu.
  document.addEventListener("mousedown", (e) => {
    if (!editing) return;
    const row = $("list").querySelector(`.item[data-id="${editing}"]`);
    if (!row || row.contains(e.target)) return;
    zapiszEdycje(row, editing);
  });

  // drag & drop
  $("list").addEventListener("dragstart", (e) => { const row = e.target.closest(".item"); if (!row) return; dragId = row.dataset.id; row.classList.add("dragging"); e.dataTransfer.effectAllowed = "move"; });
  $("list").addEventListener("dragend", () => { dragId = null; document.querySelectorAll(".item").forEach((x) => x.classList.remove("dragging", "over")); });
  $("list").addEventListener("dragover", (e) => { e.preventDefault(); const row = e.target.closest(".item"); document.querySelectorAll(".item.over").forEach((x) => x.classList.remove("over")); if (row) row.classList.add("over"); });
  $("list").addEventListener("drop", (e) => { e.preventDefault(); const row = e.target.closest(".item"); if (!row || !dragId || row.dataset.id === dragId) return; const ids = [...document.querySelectorAll("#list .item")].map((x) => x.dataset.id); let to = ids.indexOf(row.dataset.id); const from = ids.indexOf(dragId); if (from < to) to = to; cmd("song-move", { id: dragId, to }); });

  $("btnReplace").onclick = () => { const t = $("txt").value.trim(); if (!t) return; cmd("playlist-load", { text: t, name: "Wklejona", mode: "replace" }); $("txt").value = ""; toast("Playlista zastąpiona"); };
  $("btnAppend").onclick = () => { const t = $("txt").value.trim(); if (!t) return; cmd("playlist-load", { text: t, mode: "append" }); $("txt").value = ""; toast("Dołączono"); };
  $("btnFile").onclick = async () => { const r = await api.playlistImportFile(); if (r && r.ok) { $("txt").value = r.text; toast("Wczytano " + r.file + " — wybierz ZASTĄP albo DOŁĄCZ"); } };
  $("btnRestart").onclick = async () => { const r = await api.confirm({ title: "Restart playlisty", message: "Wszystkie piosenki wrócą do zablokowanych (pierwsza odblokowana), tapy od zera. Kontynuować?", okLabel: "RESTART" }); if (r.ok) cmd("playlist-restart"); };
  $("btnClear").onclick = async () => { const r = await api.confirm({ title: "Wyczyść playlistę", message: "Usunąć wszystkie piosenki z kolejki?", okLabel: "WYCZYŚĆ" }); if (r.ok) cmd("playlist-clear"); };
  $("btnSaveAs").onclick = async () => {
    const name = prompt("Nazwa playlisty:", (S && S.song && S.song.name) || "Moja playlista"); if (!name) return;
    const items = (S.playlistFull || []).map((i) => ({ title: i.title, artist: i.artist, threshold: i.threshold, file: i.file }));
    const r = await api.playlistSave({ name, items }); toast(r.ok ? "Zapisano: " + name : "Błąd zapisu");
  };

  // ---- biblioteka ----
  async function loadLib() {
    const r = await api.soundState(); if (!r || !r.ok) return;
    lib = r.library || []; baseUrl = r.baseUrl || ""; renderLib(); renderList();
  }
  function renderLib() {
    const q = ($("libSearch").value || "").toLowerCase();
    const rows = lib.filter((f) => !q || (f.title + " " + f.artist + " " + f.file).toLowerCase().includes(q));
    $("libInfo").textContent = `${lib.length} plików`;
    $("lib").innerHTML = rows.length ? rows.map((f) => `<div class="item" data-file="${esc(f.file)}"><span>♪</span><div class="grow"><div class="t">${label(f)}</div><div class="s">${esc(f.file)} · ${(f.size / 1048576).toFixed(1)} MB</div></div>
      <div class="acts"><button class="btn tiny" data-act="listen">▶ odsłuch</button><button class="btn tiny acc" data-act="add">+ do playlisty</button><button class="btn tiny acc" data-act="add-next">+ jako następna</button><button class="btn tiny bad" data-act="del" title="Do kosza">✕</button></div></div>`).join("")
      : `<div class="empty">${lib.length ? "Brak wyników" : "Brak podkładów. IMPORTUJ PLIKI albo wrzuć mp3 do folderu."}</div>`;
  }
  $("libSearch").oninput = renderLib;
  $("lib").addEventListener("click", async (e) => {
    const b = e.target.closest("[data-act]"); if (!b) return;
    const file = e.target.closest(".item").dataset.file; const f = lib.find((x) => x.file === file); if (!f) return;
    if (b.dataset.act === "listen") { $("prev").src = `${baseUrl}/podklady/${encodeURIComponent(file)}`; $("prevName").textContent = file; $("prev").play().catch(() => {}); }
    else if (b.dataset.act === "add" || b.dataset.act === "add-next") { cmd("song-add", { items: [{ title: f.title, artist: f.artist, file: f.file }], unlocked: b.dataset.act === "add-next", position: b.dataset.act === "add-next" ? "next" : "end" }); toast("Dodano: " + f.title); }
    else if (b.dataset.act === "del") { const r = await api.confirm({ title: "Usuń podkład", message: `Przenieść „${file}” do kosza?`, okLabel: "USUŃ" }); if (r.ok) { await api.soundRemoveLibrary(file); loadLib(); } }
  });
  $("btnImport").onclick = async () => { const r = await api.soundImportLibrary(); toast(`Zaimportowano: ${r.imported || 0}`); loadLib(); };
  $("btnFolder").onclick = () => api.soundOpenFolder("podklady");
  $("btnRescan").onclick = loadLib;
  $("btnAddAll").onclick = () => { if (!lib.length) return; cmd("song-add", { items: lib.map((f) => ({ title: f.title, artist: f.artist, file: f.file })) }); toast(`Dodano ${lib.length} piosenek`); };

  // ---- zapisane ----
  async function loadSaved() {
    const list = await api.playlistList();
    $("saved").innerHTML = list.length ? list.map((p) => `<div class="item" data-name="${esc(p.name)}"><span>💾</span><div class="grow"><div class="t">${esc(p.name)}</div><div class="s">${p.count} piosenek${p.savedAt ? " · " + new Date(p.savedAt).toLocaleString("pl-PL") : ""}</div></div>
      <div class="acts"><button class="btn tiny acc" data-act="load">WCZYTAJ (zastąp)</button><button class="btn tiny" data-act="append">DOŁĄCZ</button><button class="btn tiny bad" data-act="del">✕</button></div></div>`).join("") : '<div class="empty">Brak zapisanych playlist.</div>';
  }
  $("saved").addEventListener("click", async (e) => {
    const b = e.target.closest("[data-act]"); if (!b) return;
    const name = e.target.closest(".item").dataset.name;
    if (b.dataset.act === "del") { const r = await api.confirm({ title: "Usuń playlistę", message: `Usunąć „${name}”?`, okLabel: "USUŃ" }); if (r.ok) { await api.playlistDelete(name); loadSaved(); } return; }
    const data = await api.playlistRead(name); if (!data) return toast("Nie mogę wczytać");
    cmd("playlist-load", { items: data.items || [], name: data.name || name, mode: b.dataset.act === "append" ? "append" : "replace" }); toast("Wczytano: " + name);
  });

  api.onState((st) => { S = st; renderList(); });
  (async () => { S = await api.stateGet(); await loadLib(); renderList(); })();
})();
