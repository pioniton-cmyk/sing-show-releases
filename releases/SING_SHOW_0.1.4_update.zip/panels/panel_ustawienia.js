(() => {
  const { $, esc, toast } = window.PC;
  const api = window.api;
  $("head").innerHTML = PC.head("Ustawienia i profile");
  let profile = null;
  const PRESETS = {
    roz: { accent: "#ff4d8d", accent2: "#ffd166", ink: "#f3f4fb", glass: "rgba(12,14,26,.78)" },
    nieb: { accent: "#3da5ff", accent2: "#f6e96b", ink: "#f3f7ff", glass: "rgba(8,14,30,.78)" },
    fiolet: { accent: "#9b6bff", accent2: "#5ef2c0", ink: "#f6f2ff", glass: "rgba(16,10,30,.78)" },
    czerw: { accent: "#e8333f", accent2: "#ffcb55", ink: "#fff6f0", glass: "rgba(24,8,8,.8)" },
    ziel: { accent: "#2fcf7a", accent2: "#ffffff", ink: "#f2fff7", glass: "rgba(6,20,14,.8)" },
  };

  async function loadVoices() {
    try {
      const r = await api.ttsVoices(); const sel = $("ttsVoice");
      sel.innerHTML = `<option value="">domyślny systemu${r.defaultVoice ? " (" + esc(r.defaultVoice) + ")" : ""}</option>` + (r.voices || []).map((v) => `<option value="${esc(v.name)}">${esc(v.name)} · ${esc(v.lang)}</option>`).join("");
    } catch {}
  }
  async function loadProfiles() {
    const list = await api.profileList();
    profile = await api.profileGet();
    $("profiles").innerHTML = list.map((p) => `<div class="p ${p.active ? "active" : ""}" data-slug="${esc(p.slug)}">${p.active ? "● " : ""}${esc(p.name)}</div>`).join("");
    $("activeName").textContent = profile.name;
    PC.fillProfileFields(document, profile);
  }
  $("profiles").addEventListener("click", async (e) => { const el = e.target.closest("[data-slug]"); if (!el) return; await api.profileActivate(el.dataset.slug); loadProfiles(); toast("Aktywny profil zmieniony"); });
  $("pNew").onclick = async () => { const name = prompt("Nazwa nowego profilu (np. nick twórczyni):"); if (!name) return; const p = await api.profileCreate({ name }); await api.profileActivate(p.slug); loadProfiles(); };
  $("pDup").onclick = async () => { const name = prompt("Nazwa kopii:", profile.name + " (kopia)"); if (!name) return; const p = await api.profileCreate({ name, copyFrom: profile.slug }); await api.profileActivate(p.slug); loadProfiles(); };
  $("pRename").onclick = async () => { const name = prompt("Nowa nazwa:", profile.name); if (!name) return; await api.profileUpdate({ name }); loadProfiles(); };
  $("pDel").onclick = async () => { const r = await api.confirm({ title: "Usuń profil", message: `Usunąć profil „${profile.name}”? (Ustawienia znikną, pliki playlist zostaną w folderze profilu.)`, okLabel: "USUŃ" }); if (!r.ok) return; const d = await api.profileDelete(profile.slug); if (!d.ok) toast("Nie można usunąć ostatniego profilu"); loadProfiles(); };
  PC.bindProfileFields(document, () => profile, (p) => { profile = p; $("activeName").textContent = p.name; });
  // ---- klucz Euler Stream ----
  async function refreshKeyPill() {
    const st = await api.keyStatus();
    const el = $("keyPill");
    el.className = "pill " + (st.hasKey ? "ok" : "warn");
    el.textContent = st.hasKey ? `zapisany ${st.masked}` : "brak klucza";
    $("keyInfo").innerHTML = st.hasKey
      ? `Plik: <span class="mono">${esc(st.file || "")}</span> · źródło: ${esc(st.source)}. Kliknij SPRAWDŹ, żeby zobaczyć limity.`
      : "Nie ma zapisanego klucza — program połączy się na darmowym limicie (100 połączeń na dobę), przy większym ruchu TikTok będzie odrzucał.";
    $("keyInput").value = "";
    $("keyInput").placeholder = st.hasKey ? `zapisany klucz ${st.masked} — wklej nowy, żeby podmienić` : "wklej klucz (euler_…)";
  }
  $("keyShow").onclick = () => { const i = $("keyInput"); i.type = i.type === "password" ? "text" : "password"; };
  $("keySave").onclick = async () => {
    const v = $("keyInput").value.trim();
    if (!v) return toast("Najpierw wklej klucz");
    $("keyInfo").textContent = "Sprawdzam klucz przed zapisaniem…";
    const t = await api.keyTest(v);
    if (!t.ok) {
      $("keyInfo").innerHTML = `<b style="color:var(--bad)">Nie zapisuję — ${esc(t.error || "klucz nie działa")}</b>`;
      return;
    }
    const r = await api.keySet(v);
    if (!r.ok) { $("keyInfo").innerHTML = `<b style="color:var(--bad)">${esc(r.error || "Nie udało się zapisać")}</b>`; return; }
    showLimits(t);
    await refreshKeyPill();
    $("keyInfo").innerHTML = `<b style="color:var(--ok)">Klucz sprawdzony i zapisany.</b> ` + $("keyInfo").innerHTML;
    toast("Klucz zapisany");
  };
  $("keyTest").onclick = async () => {
    const v = $("keyInput").value.trim();
    $("keyInfo").textContent = "Pytam Euler Stream…";
    const t = await api.keyTest(v);
    if (!t.ok) { $("keyLimits").classList.add("hidden"); $("keyInfo").innerHTML = `<b style="color:var(--bad)">${esc(t.error || "Klucz nie działa")}</b>`; return; }
    showLimits(t);
    $("keyInfo").innerHTML = `<b style="color:var(--ok)">Klucz działa.</b>` + (v ? " (sprawdzony wpisany, jeszcze niezapisany — kliknij ZAPISZ KLUCZ)" : "");
  };
  $("keyClear").onclick = async () => {
    const c = await api.confirm({ title: "Usuń klucz", message: "Program będzie się łączył na darmowym limicie (100 połączeń na dobę). Na pewno?", okLabel: "USUŃ" });
    if (!c.ok) return;
    await api.keyClear(); $("keyLimits").classList.add("hidden"); refreshKeyPill(); toast("Klucz usunięty");
  };
  function showLimits(t) {
    $("keyLimits").classList.remove("hidden");
    const fmt = (o) => o && o.max ? `${(o.remaining ?? o.max).toLocaleString("pl-PL")} / ${o.max.toLocaleString("pl-PL")}` : "—";
    $("klDay").textContent = fmt(t.day); $("klHour").textContent = fmt(t.hour); $("klMin").textContent = fmt(t.minute);
  }
  api.onKeyChanged(() => refreshKeyPill());
  $("ttsTest").onclick = () => api.ttsSpeak({ text: "Cześć! Tak będzie brzmiał lektor. Ania wpłaca dwadzieścia pięć złotych. Pozdrowienia z Gdańska!" });
  $("ttsStop").onclick = () => api.ttsStop();
  document.querySelectorAll("[data-preset]").forEach((b) => b.onclick = async () => { const p = await api.profileUpdate({ theme: PRESETS[b.dataset.preset] }); profile = p; PC.fillProfileFields(document, p); toast("Paleta ustawiona"); });
  // ---- skróty i tunel (ustawienia globalne, nie profilowe) ----
  const SC_KEYS = ["next", "prev", "skip", "unlock", "read"];
  let G = null;
  function fillGlobal(g) {
    G = g;
    $("scEnabled").checked = (g.shortcuts || {}).enabled !== false;
    SC_KEYS.forEach((k) => { $("sc-" + k).value = (g.shortcuts || {})[k] || ""; });
    const mode = (g.tunnel || {}).mode || "quick";
    document.querySelectorAll('input[name=tmode]').forEach((r) => r.checked = r.value === mode);
    $("tAuto").checked = (g.tunnel || {}).autostart !== false;
    const n = (g.tunnel || {}).named || {};
    $("tHost").value = n.hostname || ""; $("tId").value = n.tunnelId || ""; $("tCreds").value = n.credsFile || "";
    $("namedBox").style.display = mode === "named" ? "" : "none";
    renderScState(g.shortcutState);
  }
  function renderScState(st) {
    if (!st) return;
    const el = $("scState");
    if (!(G.shortcuts || {}).enabled) { el.innerHTML = "Skróty wyłączone."; return; }
    const okTxt = (st.registered || []).map((r) => r.accel).join(", ");
    const bad = (st.failed || []).map((f) => `${f.accel} (${f.reason})`).join(", ");
    el.innerHTML = (okTxt ? `<span style="color:var(--ok)">Działają: ${okTxt}</span>` : "") + (bad ? `<br><span style="color:var(--bad)">Nie udało się: ${bad}</span>` : "");
  }
  $("scSave").onclick = async () => {
    const patch = { enabled: $("scEnabled").checked };
    SC_KEYS.forEach((k) => patch[k] = $("sc-" + k).value.trim());
    fillGlobal(await api.globalSet({ shortcuts: patch }));
    toast("Skróty zastosowane");
  };
  $("scEnabled").onchange = () => $("scSave").click();
  document.querySelectorAll('input[name=tmode]').forEach((r) => r.onchange = () => { $("namedBox").style.display = r.value === "named" ? "" : "none"; });
  $("tPick").onclick = async () => {
    const r = await api.pickCredsFile();
    if (!r.ok) return toast(r.error || "Anulowano");
    $("tCreds").value = r.credsFile; if (r.tunnelId) $("tId").value = r.tunnelId;
    toast("Plik poświadczeń wgrany");
  };
  $("tSave").onclick = async () => {
    const mode = document.querySelector('input[name=tmode]:checked').value;
    if (mode === "named" && (!$("tHost").value.trim() || !$("tId").value.trim() || !$("tCreds").value.trim())) return toast("Uzupełnij domenę, ID tunelu i plik poświadczeń");
    fillGlobal(await api.globalSet({ tunnel: { mode, autostart: $("tAuto").checked, named: { hostname: $("tHost").value.trim(), tunnelId: $("tId").value.trim(), credsFile: $("tCreds").value.trim() } } }));
    toast("Zapisano ustawienia tunelu");
  };
  async function refreshTunnelPill() {
    const st = await api.tunnelStatus();
    const el = $("tState");
    el.className = "pill " + (st.running ? (st.url ? "ok" : "warn") : (st.installed ? "" : "bad"));
    el.textContent = st.running ? (st.url ? st.url.replace("https://", "") : "startuje…") : (st.installed ? "tunel wyłączony" : "brak cloudflared — brew install cloudflared");
  }
  api.onShortcutsState((st) => { if (G) { G.shortcutState = st; renderScState(st); } });
  api.onProfileChanged((p) => { if (profile && p.slug === profile.slug) { profile = p; } });
  (async () => { await loadVoices(); await loadProfiles(); fillGlobal(await api.globalGet()); refreshTunnelPill(); refreshKeyPill(); setInterval(refreshTunnelPill, 8000); })();
})();
