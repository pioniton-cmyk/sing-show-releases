(() => {
  const { $, esc, pln, fmtTime, toast } = window.PC;
  const api = window.api;
  const cmd = (n, p) => api.cmd(n, p || {});
  $("head").innerHTML = PC.head("Tipped / donejty");
  let S = null, profile = null, status = null;

  async function loadProfile() { profile = await api.profileGet(); PC.fillProfileFields(document, profile); }
  PC.bindProfileFields(document, () => profile, (p) => { profile = p; });

  async function loadStatus() {
    status = await api.tippedStatus();
    $("whEnabled").checked = !!(profile && profile.tipped.enabled);
    $("whPort").textContent = status.port;
    const w = $("stWebhook"); w.className = "pill " + (status.running ? "ok" : "bad"); w.textContent = status.running ? "webhook działa" : "webhook wyłączony";
    const t = $("stTunnel"); const tu = status.tunnel || {};
    t.className = "pill " + (tu.running ? (tu.url ? "ok" : "warn") : (tu.installed ? "" : "warn"));
    t.textContent = tu.running ? (tu.url ? "tunel: " + tu.url.replace("https://", "") : "tunel: startuje…") : (tu.installed ? "tunel: wyłączony" : "brak cloudflared (brew install cloudflared)");
    $("btnTunnel").textContent = tu.running ? "ZATRZYMAJ TUNEL" : "URUCHOM TUNEL";
    $("btnTunnel").disabled = !tu.installed;
    $("urlBox").textContent = (tu.url ? tu.url + "/webhook   (publiczny)   |   " : "") + status.localUrl + "   (lokalny)";
    const u = $("stUnsigned"); u.classList.toggle("hidden", !status.unsignedCount); u.textContent = `bez podpisu: ${status.unsignedCount}`;
  }
  $("whEnabled").onchange = async () => { await api.tippedSetEnabled($("whEnabled").checked); loadStatus(); };
  $("btnTunnel").onclick = async () => { if (status && status.tunnel && status.tunnel.running) await api.tunnelStop(); else { const r = await api.tunnelStart(); if (r && !r.ok) toast(r.error || "Błąd tunelu"); } setTimeout(loadStatus, 800); setTimeout(loadStatus, 4000); };
  $("btnCopyUrl").onclick = async () => { const tu = status && status.tunnel; const url = (tu && tu.url ? tu.url : "http://127.0.0.1:" + (status ? status.port : 8797)) + "/webhook"; await api.clipboardCopy(url); toast("Skopiowano: " + url); };
  $("btnTest").onclick = async () => { await api.tippedTest({ nick: $("tNick").value, amount: Number($("tAmt").value), message: $("tMsg").value }); toast("Wysłano testowy donejt"); };
  $("btnManual").onclick = () => { cmd("don-manual", { nick: $("tNick").value, amount: Number($("tAmt").value), message: $("tMsg").value }); toast("Dodano wpłatę"); };

  function render() {
    if (!S) return;
    const all = S.donationsAll || [];
    const unread = all.filter((d) => d.status === "unread").sort((a, b) => a.ts - b.ts);
    $("readCount").textContent = unread.length;
    $("unread").innerHTML = unread.length ? unread.map((d, i) => `<div class="item ${i === 0 ? "now" : ""}" data-id="${esc(d.id)}"><div class="grow"><div class="t">${esc(d.nick)} <span class="tag gold">${pln(d.amount)}</span> ${d.order ? '<span class="tag acc">★ zamówienie</span>' : ""} ${d.spoken ? '<span class="tag info">🔊</span>' : ""}</div><div class="msg">${esc(d.message || "(bez wiadomości)")}${d.goal ? ' <span class="muted">· na: ' + esc(d.goal) + "</span>" : ""}</div><div class="s">${fmtTime(d.ts)}${d.signed ? "" : " · bez podpisu"}</div></div>
      <div class="acts"><button class="btn tiny ok" data-act="don-read">✓</button><button class="btn tiny" data-act="don-speak" title="Lektor">🔊</button><button class="btn tiny" data-act="don-show" title="Pokaż na ekranie">🖥</button>${!d.order ? '<button class="btn tiny" data-act="don-order" title="Zrób z tego zamówienie piosenki">★</button>' : ""}<button class="btn tiny bad" data-act="don-remove">✕</button></div></div>`).join("") : '<div class="empty">Nic nie czeka.</div>';
    $("allInfo").textContent = `${all.length} wpłat`;
    $("all").innerHTML = `<tr><th>Czas</th><th>Nick</th><th class="num">Kwota</th><th>Wiadomość</th><th>Status</th><th></th></tr>` + all.map((d) => {
      const st = d.status === "unread" ? '<span class="tag gold">do przeczytania</span>' : d.status === "read" ? '<span class="tag ok">przeczytana</span>' : d.status === "fund" ? '<span class="tag info">zbiórka</span>' : '<span class="tag">poniżej progu</span>';
      return `<tr class="${d.status === "below" ? "dim" : ""}" data-id="${esc(d.id)}"><td class="mono">${fmtTime(d.ts)}</td><td><b>${esc(d.nick)}</b>${d.source && d.source !== "tipped" ? ' <span class="muted small">(' + esc(d.source) + ")</span>" : ""}</td><td class="num">${pln(d.amount)}</td><td>${esc(d.message || "")}${d.goal ? ' <span class="muted">· ' + esc(d.goal) + "</span>" : ""}${d.order ? ' <span class="tag acc">★</span>' : ""}</td><td>${st}</td>
        <td>${d.status !== "unread" ? '<button class="btn tiny" data-act="don-unread" title="Wyślij do czytania">→ czytaj</button>' : ""}<button class="btn tiny" data-act="don-speak" title="Lektor">🔊</button></td></tr>`;
    }).join("");
    const f = S.funds || {};
    $("kTotal").textContent = pln(f.total); $("kCount").textContent = all.length;
    $("kGoals").innerHTML = Object.entries(f.byGoal || {}).map(([g, v]) => `<div class="row"><span>${esc(g)}</span><span class="sp grow"></span><b>${pln(v)}</b></div>`).join("") || '<span class="muted">brak wpłat</span>';
    $("kTop").innerHTML = (f.topDonors || []).slice(0, 5).map((d, i) => `<div class="rank-item"><span class="pl">#${i + 1}</span><span>${esc(d.nick)}</span><span class="pts">${pln(d.sum)}</span></div>`).join("");
  }
  document.addEventListener("click", (e) => {
    const b = e.target.closest("[data-act]"); if (!b) return;
    const row = e.target.closest("[data-id]"); if (!row) return;
    cmd(b.dataset.act, { id: row.dataset.id });
  });

  api.onState((st) => { S = st; render(); });
  api.onProfileChanged((p) => { profile = p; PC.fillProfileFields(document, p); loadStatus(); });
  api.onTunnelState(() => loadStatus());
  (async () => { await loadProfile(); await loadStatus(); S = await api.stateGet(); render(); setInterval(loadStatus, 8000); })();
})();
