/* SING_SHOW — CZYTNIK (główne widoczne okno). Nie trzyma logiki: pokazuje stan z silnika
   i wysyła komendy przez api.cmd(). */
(() => {
  const api = window.api;
  const $ = (id) => document.getElementById(id);
  const esc = (s) => String(s == null ? "" : s).replace(/[&<>"']/g, (m) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[m]));
  const pln = (n) => { n = Number(n) || 0; return n.toLocaleString("pl-PL", { minimumFractionDigits: n % 1 ? 2 : 0, maximumFractionDigits: 2 }) + " zł"; };
  const fmtT = (s) => { s = Math.max(0, Math.floor(Number(s) || 0)); return Math.floor(s / 60) + ":" + String(s % 60).padStart(2, "0"); };
  const label = (it) => (it.artist ? esc(it.artist) + " – " : "") + esc(it.title);
  let S = null, tiktok = {}, profile = null, seeking = false;
  let toastT = null;
  function toast(t) { const el = $("toast"); el.textContent = t; el.classList.add("show"); clearTimeout(toastT); toastT = setTimeout(() => el.classList.remove("show"), 1800); }
  const cmd = (name, payload) => api.cmd(name, payload || {});

  // ---- menu / panele ----
  $("btnMenu").onclick = (e) => { e.stopPropagation(); $("menu").classList.toggle("open"); };
  document.addEventListener("click", (e) => { if (!e.target.closest("#menu") && !e.target.closest("#btnMenu")) $("menu").classList.remove("open"); });
  document.querySelectorAll("#menu [data-panel]").forEach((b) => b.onclick = () => { $("menu").classList.remove("open"); api.openPanel(b.dataset.panel); });

  // ---- sterowanie ----
  $("btnNext").onclick = () => cmd("next", { force: true });
  $("btnPrev").onclick = () => cmd("prev");
  $("btnSkip").onclick = () => cmd("skip");
  $("btnUnlock").onclick = () => cmd("unlock", { by: "" });
  $("btnAdd").onclick = () => { $("addModal").classList.add("open"); $("addText").focus(); };
  $("addClose").onclick = () => $("addModal").classList.remove("open");
  $("addOk").onclick = () => { const t = $("addText").value.trim(); if (!t) return; cmd("song-add", { text: t, unlocked: $("addUnlocked").checked, position: $("addNext").checked ? "next" : "end" }); $("addText").value = ""; $("addModal").classList.remove("open"); toast("Dodano"); };
  $("btnDemo").onclick = () => cmd("demo", { on: !(S && S.session && S.session.demo) });
  $("btnReset").onclick = async () => { const r = await api.confirm({ title: "Zeruj sesję", message: "Wyzerować tapy, armatę, donejty, kasę i ranking? Playlista zostaje (statusy wracają do zablokowanych).", okLabel: "ZERUJ" }); if (r && r.ok) { cmd("reset-session", { keepPlaylist: true }); toast("Sesja wyzerowana"); } };

  // donejty
  $("donRead").onclick = () => cmd("don-read");
  $("donSpeak").onclick = () => cmd("don-speak");
  $("donShow").onclick = () => cmd("don-show");
  $("ttsStop").onclick = () => api.ttsStop();

  // podkład
  $("bkPlay").onclick = () => cmd("backing-play", { id: S && S.song && S.song.now ? S.song.now.id : null });
  $("bkPause").onclick = () => cmd("backing-pause");
  $("bkStop").onclick = () => cmd("backing-stop");
  $("bkSeek").oninput = () => { seeking = true; };
  $("bkSeek").onchange = () => { const dur = (S && S.backing && S.backing.dur) || 0; cmd("backing-seek", { pos: dur * (Number($("bkSeek").value) / 1000) }); seeking = false; };
  $("bkVol").oninput = () => cmd("backing-volume", { v: Number($("bkVol").value) / 100 });

  // TikTok
  $("pillLive").onclick = () => { $("ttModal").classList.toggle("open"); if (profile) $("ttUser").value = profile.tiktok.username || ""; };
  $("ttClose").onclick = () => $("ttModal").classList.remove("open");
  $("ttConnect").onclick = async () => { const u = $("ttUser").value.trim(); if (!u) return; $("ttInfo").textContent = "Łączę…"; const r = await api.tiktokConnect({ username: u }); $("ttInfo").textContent = r && r.ok ? "Połączono." : ("Błąd: " + (r && r.error || "?")); if (r && r.ok) setTimeout(() => $("ttModal").classList.remove("open"), 600); };
  $("ttDisconnect").onclick = async () => { await api.tiktokDisconnect(); $("ttInfo").textContent = "Rozłączono."; };

  // profil
  async function loadProfiles() {
    const list = await api.profileList();
    $("profileSel").innerHTML = list.map((p) => `<option value="${esc(p.slug)}" ${p.active ? "selected" : ""}>${esc(p.name)}</option>`).join("");
    profile = await api.profileGet();
    applyTheme();
  }
  $("profileSel").onchange = async () => { await api.profileActivate($("profileSel").value); toast("Przełączono profil"); loadProfiles(); };
  function applyTheme() { if (profile && profile.theme && profile.theme.accent) document.documentElement.style.setProperty("--accent", profile.theme.accent); }

  // ---- render ----
  function renderTiktok() {
    const p = $("pillLive");
    if (tiktok.connected) { p.className = "pill ok"; p.textContent = "Live: @" + (tiktok.username || ""); }
    else if (tiktok.connecting) { p.className = "pill warn"; p.textContent = "Live: łączę…"; }
    else { p.className = "pill bad"; p.textContent = "Live: offline" + (tiktok.reason ? " · " + String(tiktok.reason).slice(0, 40) : ""); }
    $("pillViewers").textContent = "👁 " + (tiktok.viewerCount || 0);
  }
  async function renderWebhook() {
    try { const st = await api.tippedStatus(); const p = $("pillWebhook"); p.className = "pill " + (st.running ? "ok" : "bad"); p.textContent = st.running ? ("Webhook: ✓" + (st.tunnel && st.tunnel.url ? " · tunel" : "")) : "Webhook: wyłączony"; } catch {}
  }

  function render() {
    if (!S) return;
    const song = S.song || {}, taps = S.taps || {}, don = S.donations || {}, bk = S.backing || {};
    // teraz
    $("nowTitle").textContent = song.now ? song.now.title : (song.total ? "Wciśnij DALEJ, żeby zacząć" : "Wczytaj playlistę (MENU → PLAYLISTA) i wciśnij DALEJ");
    $("nowArtist").textContent = song.now ? (song.now.artist || "") : "";
    $("nowOrder").innerHTML = song.now && song.now.order ? `<span class="tag gold">★ ${song.now.order.top1 ? "dedykacja TOP 1" : "zamówienie"} · ${esc(song.now.order.by)}${song.now.order.amount ? " · " + pln(song.now.order.amount) : ""}</span>` : "";
    $("nowPos").textContent = `${song.done || 0} / ${song.total || 0}` + (song.name ? " · " + song.name : "");
    const hasFile = !!(song.now && song.now.file);
    $("bkPlay").disabled = !hasFile; $("bkPause").disabled = !hasFile; $("bkStop").disabled = !hasFile; $("bkSeek").disabled = !hasFile;
    $("bkPlay").className = "btn sm " + (bk.playing ? "ok" : "");
    if (!seeking) $("bkSeek").value = bk.dur ? Math.round((bk.pos / bk.dur) * 1000) : 0;
    $("bkTime").textContent = hasFile ? `${fmtT(bk.pos)} / ${fmtT(bk.dur)}` : "brak podkładu";
    if (document.activeElement !== $("bkVol")) $("bkVol").value = Math.round((bk.volume ?? 0.8) * 100);
    // następna
    const nx = song.next;
    $("nextTitle").innerHTML = nx ? label(nx) : "<span class='muted'>— koniec playlisty —</span>";
    const tag = $("nextTag");
    if (!nx) { tag.className = "tag"; tag.textContent = "—"; }
    else if (nx.status === "unlocked") { tag.className = "tag ok"; tag.textContent = "✓ odblokowana"; }
    else { tag.className = "tag warn"; tag.textContent = "🔒 zablokowana"; }
    const p = Number(taps.progress) || 0, t = Math.max(1, Number(taps.threshold) || 1);
    $("nextBar").style.width = Math.min(100, Math.round((p / t) * 100)) + "%";
    $("tapsP").textContent = p.toLocaleString("pl-PL"); $("tapsT").textContent = t.toLocaleString("pl-PL");
    $("tapsLeft").textContent = nx && nx.status === "locked" ? (p >= t ? "odblokowana!" : `brakuje ${(t - p).toLocaleString("pl-PL")} ♥`) : "";
    $("btnNext").classList.toggle("warn", !!(nx && nx.status === "locked"));
    $("btnNext").title = nx && nx.status === "locked" ? "Następna jest zablokowana — DALEJ odblokuje ją ręcznie" : "";
    // hint
    const h = S.hint; $("hint").classList.toggle("hidden", !h); if (h) $("hint").textContent = h.text;
    // donejt
    const cur = don.current;
    $("donQueue").textContent = (don.readQueue || 0) + " czeka";
    $("donQueue").className = "pill nodot " + (don.readQueue ? "gold" : "");
    $("donNick").textContent = cur ? cur.nick : "—";
    $("donAmt").textContent = cur ? pln(cur.amount) : "";
    $("donMsg").textContent = cur ? (cur.message || "(bez wiadomości)") : (don.readThreshold ? `Czekam na donejt od ${pln(don.readThreshold)}` : "Czekam na donejt");
    $("donGoal").textContent = cur && cur.goal ? "na cel: " + cur.goal : "";
    $("donOrder").classList.toggle("hidden", !(cur && cur.order));
    $("donRead").disabled = !cur; $("donSpeak").disabled = !cur; $("donShow").disabled = !cur;
    $("ttsPill").classList.toggle("hidden", !(S.tts && S.tts.speaking));
    // staty
    $("stTaps").textContent = (taps.session || 0).toLocaleString("pl-PL");
    const c = S.cannon || {}; $("stCannon").textContent = `${(c.charge || 0).toLocaleString("pl-PL")} / ${(c.threshold || 0).toLocaleString("pl-PL")}`;
    $("stDone").textContent = `${song.done || 0} / ${song.total || 0}`;
    $("stUnl").textContent = taps.unlockCount || 0;
    $("pillKasa").textContent = pln((S.funds || {}).total);
    $("btnDemo").className = "btn sm " + (S.session && S.session.demo ? "acc" : "");
    $("btnDemo").textContent = S.session && S.session.demo ? "DEMO: WŁĄCZONE" : "DEMO LIVE";
    // kolejka
    const items = S.playlistFull || [];
    $("plName").textContent = song.name || "";
    $("queue").innerHTML = items.length ? items.map((it, i) => {
      const st = it.id === (song.now && song.now.id) ? "now" : it.status;
      const badge = st === "now" ? '<span class="tag acc">teraz</span>' : st === "unlocked" ? '<span class="tag ok">✓</span>' : st === "locked" ? '<span class="tag">🔒</span>' : st === "done" ? '<span class="tag">✓ zaśp.</span>' : '<span class="tag warn">pominięta</span>';
      const ord = it.order ? `<span class="tag gold">★ ${esc(it.order.by)}</span>` : "";
      const file = it.file ? '<span class="tag info" title="ma podkład">♪</span>' : "";
      return `<div class="item ${st}" data-id="${it.id}"><span class="muted tnum small">${i + 1}.</span><div class="grow"><div class="t">${label(it)} ${ord} ${file}</div><div class="s">${it.threshold ? "próg " + it.threshold + " ♥ · " : ""}${badge}</div></div>
        <div class="acts">${st !== "now" ? `<button class="btn tiny" data-act="play-now" title="Śpiewaj teraz">▶</button>` : ""}${st === "locked" ? `<button class="btn tiny info" data-act="unlock" title="Odblokuj">🔓</button>` : ""}${st === "unlocked" ? `<button class="btn tiny" data-act="lock" title="Zablokuj">🔒</button>` : ""}<button class="btn tiny" data-act="up">↑</button><button class="btn tiny" data-act="down">↓</button></div></div>`;
    }).join("") : '<div class="empty">Pusta playlista — MENU → PLAYLISTA I BIBLIOTEKA</div>';
    // ranking
    const r = S.ranking || [];
    $("rankCount").textContent = S.rankingCount ? `(${S.rankingCount} widzów)` : "";
    $("rank").innerHTML = r.length ? r.slice(0, 10).map((x, i) => `<div class="rank-item"><span class="pl">#${i + 1}</span><span>${esc(x.nick)}</span><span class="pts">${x.points} pkt</span></div>`).join("") : '<div class="empty">Czekam na komentarze, tapy, followy i share…</div>';
  }
  $("queue").addEventListener("click", (e) => {
    const b = e.target.closest("[data-act]"); if (!b) return;
    const id = e.target.closest(".item").dataset.id; const act = b.dataset.act;
    if (act === "up" || act === "down") cmd("song-move", { id, dir: act }); else cmd(act, { id });
  });

  // ---- start ----
  api.onUpdateAvailable((r) => { $("updDot").classList.remove("hidden"); toast(`Jest nowsza wersja ${r.latest} — MENU → AKTUALIZACJE`); });
  api.onState((st) => { S = st; render(); });
  api.onTiktokState((st) => { tiktok = { ...tiktok, ...(st || {}) }; renderTiktok(); });
  api.onProfileChanged((p) => { profile = p; applyTheme(); renderWebhook(); });
  api.onTunnelState(() => renderWebhook());
  (async () => {
    await loadProfiles();
    try { tiktok = await api.tiktokState(); } catch {}
    renderTiktok(); renderWebhook();
    S = await api.stateGet(); render();
    setInterval(renderWebhook, 10000);
  })();
  document.addEventListener("keydown", (e) => {
    if (e.target.matches("input,textarea,select")) return;
    if (e.key === "ArrowRight" && (e.metaKey || e.ctrlKey)) cmd("next", { force: true });
    if (e.key === "Escape") { $("menu").classList.remove("open"); $("ttModal").classList.remove("open"); $("addModal").classList.remove("open"); }
  });
})();
