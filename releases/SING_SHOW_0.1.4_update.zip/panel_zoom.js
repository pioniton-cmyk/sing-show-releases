// =========================
// KVRINA_SHOW — panel_zoom.js
// Wspólne, pełne skalowanie osobnych okienek paneli (obserwujący / ranking / kasa).
// CSS `zoom` na #panel-app — skaluje WSZYSTKO (tekst, przyciski, listy) razem,
// tak samo jak zoom w oknie czytnika. Zapamiętywane per-panel w localStorage.
// Wymaga w HTML: <body data-panel-key="..."> oraz przycisków
// #panel-zoom-minus / #panel-zoom-plus w nagłówku.
// =========================
(function () {
  const MIN = 0.6;
  const MAX = 1.8;
  const key = "kvrina_panel_zoom_" + (document.body && document.body.dataset.panelKey ? document.body.dataset.panelKey : "generic");
  let zoom = 1;

  const root = () => document.getElementById("panel-app") || document.body;

  function apply() {
    const el = root();
    if (!el) return;
    // CSS `zoom` skaluje cały element, więc przy zoomie < 1 element z height:100vh
    // zajmowałby tylko część okna (zostawała pusta przestrzeń). Kompensujemy wymiary:
    // ustawiamy je na 100/zoom, żeby po przeskalowaniu wypełniły dokładnie całe okno.
    el.style.zoom = String(zoom);
    el.style.width = (100 / zoom) + "vw";
    el.style.height = (100 / zoom) + "vh";
  }
  function save() {
    try { localStorage.setItem(key, String(zoom)); } catch {}
  }
  function load() {
    try {
      const s = parseFloat(localStorage.getItem(key));
      if (Number.isFinite(s) && s >= MIN && s <= MAX) zoom = s;
    } catch {}
  }

  load();

  window.addEventListener("DOMContentLoaded", () => {
    apply();
    const minus = document.getElementById("panel-zoom-minus");
    const plus = document.getElementById("panel-zoom-plus");
    if (plus) plus.addEventListener("click", () => {
      zoom = Math.min(MAX, Math.round((zoom + 0.1) * 100) / 100);
      apply(); save();
    });
    if (minus) minus.addEventListener("click", () => {
      zoom = Math.max(MIN, Math.round((zoom - 0.1) * 100) / 100);
      apply(); save();
    });
  });
})();
