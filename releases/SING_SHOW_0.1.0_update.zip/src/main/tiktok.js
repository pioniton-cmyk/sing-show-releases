// =========================
// TIKTOK LIVE — połączenie bezpośrednie przez tiktok-live-connector (legacy = format TikFinity)
// Przeniesione 1:1 z KVRINA_SHOW (działa wzorowo): reconnect z back-offem, własny katalog
// giftów, rozpoznawanie follow/share po social.action, streak giftów liczony na repeatEnd.
// =========================
const diag = require("./diag");

// KLUCZ EULER STREAM (podpisywanie połączeń z TikTok LIVE).
// ŚWIADOMIE NIE MA GO W KODZIE — pliki programu trafiają do publicznych paczek aktualizacji,
// więc każdy klucz wpisany tutaj byłby jawny dla wszystkich (tak właśnie wyciekł klucz z KVRINA_SHOW:
// rozbicie na kawałki niczego nie chroni, wystarczy skleić).
// Kolejność szukania klucza:
//   1) klucz wpisany przez użytkowniczkę w USTAWIENIACH (profil),
//   2) plik euler-key.json obok programu — dostarczany z instalką, pomijany przy aktualizacjach,
//   3) plik euler-key.json w folderze danych (SING_SHOW TXT) — wygodne przy przenoszeniu.
function readKeyFile() {
  const path = require("path");
  const fs = require("fs");
  const candidates = [path.join(__dirname, "..", "..", "euler-key.json")];
  try { candidates.push(path.join(require("./paths").getOutputDir(), "euler-key.json")); } catch {}
  for (const file of candidates) {
    try {
      if (!fs.existsSync(file)) continue;
      const raw = JSON.parse(fs.readFileSync(file, "utf8"));
      const key = String((raw && (raw.apiKey || raw.key || raw.signApiKey)) || "").trim();
      if (key) return key;
    } catch (e) { diag.warn(`[TIKTOK] Nie mogę odczytać ${file}: ${e.message}`); }
  }
  return "";
}

function resolveApiKey(userKey) {
  const own = String(userKey || "").trim();
  if (own) return { key: own, source: "ustawienia" };
  const fromFile = readKeyFile();
  if (fromFile) return { key: fromFile, source: "euler-key.json" };
  return { key: "", source: "brak" };
}

let _conn = null;
let _giftCatalog = new Map();
let _username = null;
let _apiKey = null;
let _wantConnected = false;
let _reconnectTimer = null;
let _reconnectDelay = 8000;
let _emit = () => {};      // (event, data) → silnik
let _state = () => {};     // (stateObj) → silnik/okna
let _last = { connected: false, connecting: false, username: null, viewerCount: 0, reason: "" };

function init({ onEvent, onState }) {
  if (typeof onEvent === "function") _emit = onEvent;
  if (typeof onState === "function") _state = onState;
}

function _setState(patch) {
  _last = { ..._last, ...patch };
  _state(_last);
}
function getState() { return _last; }

async function refreshGiftCatalog(conn, attempt = 0) {
  if (!conn || _conn !== conn) return;
  try {
    const gifts = await conn.fetchAvailableGifts();
    if (Array.isArray(gifts) && gifts.length) {
      const m = new Map();
      for (const g of gifts) {
        const id = String((g && (g.id ?? g.giftId ?? g.gift_id)) ?? "").trim();
        if (!id) continue;
        const diamond = Number(g.diamond_count ?? g.diamondCount ?? g.coins ?? 0) || 0;
        const name = (g.name || g.giftName || "") + "";
        m.set(id, { diamond, name });
      }
      if (m.size) { _giftCatalog = m; diag.info(`[TIKTOK] Katalog giftów: ${m.size} pozycji.`); return; }
    }
    diag.warn(`[TIKTOK] Katalog giftów pusty (próba ${attempt + 1}).`);
  } catch (e) {
    diag.warn(`[TIKTOK] Błąd katalogu giftów: ${(e && e.message) ? e.message : e}`);
  }
  if (attempt < 3) setTimeout(() => refreshGiftCatalog(conn, attempt + 1), 4000 * (attempt + 1));
}

function resolveGiftValue(data) {
  const gid = String((data && (data.giftId ?? (data.gift && data.gift.gift_id))) ?? "").trim();
  const cat = gid ? _giftCatalog.get(gid) : null;
  const ext = data && data.extendedGiftInfo;
  let unit = Number(data && data.diamondCount) || 0;
  if (!unit && ext) unit = Number(ext.diamond_count ?? ext.diamondCount) || 0;
  if (!unit && cat) unit = Number(cat.diamond) || 0;
  const repeat = Number(data && data.repeatCount) || 1;
  const total = unit * (repeat > 0 ? repeat : 1);
  const name = (data && data.giftName) || (ext && ext.name) || (cat && cat.name) || "prezent";
  return { total, name, unit };
}

function _friendlyError(rawMsg) {
  const m = String(rawMsg || "").toLowerCase();
  if (m.includes("room id") || m.includes("roomid") || m.includes("user_not_found") || m.includes("isn't online") || m.includes("not online") || m.includes("offline")) {
    return { type: "offline", text: "Streamer nie jest teraz na żywo (albo zły nick). Wejdź gdy trwa live." };
  }
  if (m.includes("business plan") || m.includes("sign a request") || m.includes("rate limit") || m.includes("too many") || m.includes("429")) {
    return { type: "ratelimit", text: "Limit serwera TikTok. Poczekaj ~1 min i spróbuj ponownie (albo wklej własny klucz API w ustawieniach)." };
  }
  if (m.includes("captcha")) return { type: "captcha", text: "TikTok poprosił o captcha. Poczekaj chwilę i spróbuj ponownie." };
  return { type: "other", text: rawMsg };
}

async function connect(username, apiKey) {
  const uname = String(username || "").trim().replace(/^@/, "");
  if (!uname) return { ok: false, error: "Pusty nick" };
  await disconnect(false);
  _username = uname;
  if (apiKey !== undefined) _apiKey = String(apiKey || "").trim() || null;
  _wantConnected = true;
  _setState({ connecting: true, connected: false, username: uname, reason: "" });
  try {
    const { WebcastPushConnection } = await import("tiktok-live-connector/legacy");
    const opts = {
      processInitialData: false,
      enableExtendedGiftInfo: true,
      fetchRoomInfoOnConnect: true,
    };
    const { key, source } = resolveApiKey(_apiKey);
    if (key) { opts.signApiKey = key; diag.info(`[TIKTOK] Klucz podpisu: ${source} (…${key.slice(-4)})`); }
    else diag.warn("[TIKTOK] Brak klucza Euler Stream — łączę na darmowym limicie serwera (może odrzucać przy większym ruchu).");
    const conn = new WebcastPushConnection(uname, opts);
    _conn = conn;

    conn.on("gift", (data) => {
      const giftType = data && (data.giftType ?? (data.gift && data.gift.gift_type));
      if (giftType === 1 && !data.repeatEnd) return;
      const { total, name } = resolveGiftValue(data);
      try {
        const who = (data && (data.uniqueId || data.nickname)) || "?";
        diag.info(`[GIFT] "${name}" ${total} monet — od ${who}`);
      } catch {}
      _emit("gift", Object.assign({}, data, { diamondCount: total, giftName: name }));
    });
    conn.on("like", (data) => _emit("like", data));
    conn.on("follow", (data) => _emit("follow", data));
    conn.on("share", (data) => _emit("share", data));
    conn.on("social", (data) => {
      const action = Number(data && data.action);
      if (action === 1) _emit("follow", data);
      else if (action === 3) _emit("share", data);
    });
    conn.on("member", (data) => _emit("member", data));
    conn.on("roomUser", (data) => {
      const vc = Number(data && (data.viewerCount ?? data.viewer_count)) || 0;
      if (vc) _setState({ viewerCount: vc });
      _emit("roomUser", data);
    });
    conn.on("chat", (data) => _emit("chat", data));
    conn.on("subscribe", (data) => _emit("subscribe", data));
    conn.on("streamEnd", () => {
      diag.info("[TIKTOK] streamEnd — koniec transmisji.");
      _setState({ connected: false, connecting: false, reason: "koniec transmisji" });
    });
    conn.on("disconnected", () => {
      _setState({ connected: false, connecting: false, reason: "rozłączono" });
      _scheduleReconnect();
    });

    const state = await conn.connect();
    const viewerCount = (state && (state.viewerCount ?? (state.roomInfo && state.roomInfo.viewerCount))) || 0;
    _reconnectDelay = 8000;
    diag.info(`[TIKTOK] Połączono z @${uname} (roomId=${state && state.roomId ? state.roomId : "?"}).`);
    _setState({ connected: true, connecting: false, username: uname, viewerCount, reason: "" });
    refreshGiftCatalog(conn);
    return { ok: true, username: uname };
  } catch (err) {
    const msg = (err && err.message) ? err.message : String(err);
    const friendly = _friendlyError(msg);
    diag.warn(`[TIKTOK] Błąd połączenia @${uname}: ${msg}`);
    _conn = null;
    _setState({ connected: false, connecting: false, reason: friendly.text, errorType: friendly.type });
    _scheduleReconnect(friendly.type);
    return { ok: false, error: friendly.text, errorType: friendly.type };
  }
}

function _scheduleReconnect(errorType) {
  if (!_wantConnected || !_username) return;
  if (_reconnectTimer) return;
  if (errorType === "ratelimit" || errorType === "captcha") _reconnectDelay = Math.min(_reconnectDelay * 2, 120000);
  else if (errorType === "offline") _reconnectDelay = 15000;
  const delay = _reconnectDelay;
  _reconnectTimer = setTimeout(async () => {
    _reconnectTimer = null;
    if (_wantConnected && _username) {
      diag.info(`[TIKTOK] Ponowna próba @${_username} (po ${Math.round(delay / 1000)}s)…`);
      await connect(_username);
    }
  }, delay);
}

async function disconnect(userInitiated = true) {
  if (userInitiated) _wantConnected = false;
  if (_reconnectTimer) { clearTimeout(_reconnectTimer); _reconnectTimer = null; }
  if (_conn) {
    try { await _conn.disconnect(); } catch {}
    try { _conn.removeAllListeners && _conn.removeAllListeners(); } catch {}
    _conn = null;
  }
  if (userInitiated) _setState({ connected: false, connecting: false, reason: "rozłączono ręcznie" });
  return { ok: true };
}

module.exports = { init, connect, disconnect, getState, resolveGiftValue };
