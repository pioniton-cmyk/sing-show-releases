// =========================
// SZABLONY WIDGETÓW (OBS / TikTok LIVE Studio) — generowane na dysk przy każdym starcie.
// Każdy widget to pełna warstwa 1080x1920 (albo dowolny rozmiar źródła) z treścią
// zakotwiczoną tam, gdzie ma być na ekranie — dzięki temu widget zbiorczy to po prostu
// nałożone na siebie warstwy, a osobne źródła też działają.
// Dane: polling /widget_state_slim.json (jak w KVRINA_SHOW). Motyw z profilu przez CSS vars.
// =========================

const SHARED_SCRIPT = `
var __lastThemeSig='';
function applyTheme(s){
  try{
    var t=(s&&s.theme)||{}; var sig=JSON.stringify(t)+'|'+(s&&s.eko?1:0);
    if(sig===__lastThemeSig) return; __lastThemeSig=sig;
    var r=document.documentElement.style;
    if(t.accent) r.setProperty('--accent',t.accent);
    if(t.accent2) r.setProperty('--accent2',t.accent2);
    if(t.ink) r.setProperty('--ink',t.ink);
    if(t.glass) r.setProperty('--glass',t.glass);
    document.body.classList.toggle('eko', !!(s&&s.eko));
  }catch(e){}
}
async function getState(){
  try{
    var r=await fetch('/widget_state_slim.json?ts='+Date.now(),{cache:'no-store'});
    if(!r.ok) throw new Error('state');
    var s=await r.json(); applyTheme(s); return s;
  }catch(e){ return {song:{now:null,next:null,queue:[],ordered:[]},taps:{progress:0,threshold:500},ranking:[],donations:{},cannon:{},unlock:{},texts:{promo:[]}}; }
}
function esc(s){return String(s==null?'':s).replace(/[&<>"']/g,function(m){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m];});}
function fmtPln(n){ n=Number(n)||0; return n.toLocaleString('pl-PL',{minimumFractionDigits:(n%1?2:0),maximumFractionDigits:2})+' zł'; }
function songLabel(it){ if(!it) return ''; return (it.artist?esc(it.artist)+' – ':'')+esc(it.title||''); }
`;

const CSS = `
:root{--accent:#ff4d8d;--accent2:#ffd166;--ink:#f3f4fb;--muted:rgba(243,244,251,.66);--glass:rgba(12,14,26,.78);--line:rgba(255,255,255,.14);--ok:#4cd391}
*{box-sizing:border-box}
html,body{margin:0;width:100%;height:100%;overflow:hidden;background:transparent;color:var(--ink);font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,Inter,system-ui,sans-serif;-webkit-font-smoothing:antialiased}
.layer{position:relative;width:100vw;height:100vh;overflow:hidden}
.glass{background:var(--glass);border:1px solid var(--line);border-radius:clamp(16px,1.8vw,26px);box-shadow:0 10px 40px rgba(0,0,0,.35);backdrop-filter:blur(14px);-webkit-backdrop-filter:blur(14px)}
body.eko .glass{backdrop-filter:none;-webkit-backdrop-filter:none;box-shadow:none}
body.eko *{animation:none!important;transition:none!important}
.lbl{font-size:clamp(11px,1.15vw,16px);letter-spacing:.16em;text-transform:uppercase;font-weight:800;color:var(--muted)}
.lbl.acc{color:var(--accent)}
/* ---- PLAYLISTA ---- */
.pl{position:absolute;left:clamp(16px,3vw,40px);top:clamp(16px,8vh,150px);width:min(92vw,760px);padding:clamp(14px,1.8vw,26px) clamp(16px,2.1vw,30px)}
.pl .now-title{font-size:clamp(24px,4.4vw,56px);font-weight:900;line-height:1.06;letter-spacing:-.01em;margin:.18em 0 .1em;text-wrap:balance}
.pl .now-artist{font-size:clamp(14px,1.9vw,24px);color:var(--muted);font-weight:600}
.pl .sep{height:1px;background:var(--line);margin:clamp(10px,1.4vw,18px) 0}
.pl .next-title{font-size:clamp(17px,2.4vw,30px);font-weight:800;line-height:1.15;margin:.2em 0 .25em}
.pl .next-title.unlocked{color:var(--ok)}
.bar{height:clamp(10px,1.1vw,16px);border-radius:999px;background:rgba(255,255,255,.12);overflow:hidden;position:relative}
.bar i{position:absolute;left:0;top:0;bottom:0;width:0%;border-radius:999px;background:linear-gradient(90deg,var(--accent2),var(--accent));transition:width .5s ease}
.bar i:after{content:'';position:absolute;inset:0;background:linear-gradient(90deg,transparent,rgba(255,255,255,.35),transparent);animation:shine 2.2s linear infinite}
@keyframes shine{from{transform:translateX(-100%)}to{transform:translateX(100%)}}
.meta{display:flex;justify-content:space-between;align-items:baseline;margin-top:.45em;font-size:clamp(13px,1.6vw,20px);font-weight:700}
.meta .heart{color:var(--accent)}
.meta .big{color:var(--accent2);font-size:1.15em;font-variant-numeric:tabular-nums}
.queue{margin-top:clamp(8px,1.1vw,14px);display:flex;flex-direction:column;gap:.28em}
.queue .q{display:flex;align-items:center;gap:.55em;font-size:clamp(13px,1.65vw,21px);font-weight:600;color:var(--muted)}
.queue .q .lock{font-size:.9em;opacity:.8}
.queue .q.unlocked{color:var(--ink)}.queue .q.unlocked .lock{color:var(--ok)}
.orders{margin-top:clamp(8px,1.1vw,14px);display:flex;flex-direction:column;gap:.3em}
.orders .o{display:flex;align-items:center;gap:.5em;font-size:clamp(13px,1.65vw,21px);font-weight:700}
.orders .o .star{color:var(--accent2)}
.orders .o .amt{color:var(--accent);font-variant-numeric:tabular-nums}
.orders .o .by{color:var(--muted);font-weight:600}
.pl .empty{font-size:clamp(15px,2vw,24px);color:var(--muted);font-weight:600;padding:.4em 0}
/* ---- TAPY (sam pasek na dole) ---- */
.tapbar{position:absolute;left:50%;bottom:clamp(120px,13vh,250px);transform:translateX(-50%);width:min(92vw,900px);padding:clamp(10px,1.3vw,18px) clamp(14px,1.8vw,26px)}
.tapbar .row{display:flex;align-items:center;gap:clamp(10px,1.4vw,20px)}
.tapbar .heart{font-size:clamp(22px,3vw,40px);color:var(--accent);filter:drop-shadow(0 0 10px rgba(255,77,141,.5));animation:beat 1.1s ease-in-out infinite}
@keyframes beat{0%,100%{transform:scale(1)}50%{transform:scale(1.14)}}
.tapbar .bar{flex:1}
.tapbar .num{font-size:clamp(16px,2.2vw,30px);font-weight:900;font-variant-numeric:tabular-nums;white-space:nowrap}
.tapbar .num b{color:var(--accent2)}
.tapbar .sub{font-size:clamp(11px,1.2vw,16px);color:var(--muted);font-weight:700;letter-spacing:.08em;text-transform:uppercase;margin-top:.3em;text-align:center}
.tapbar .sub strong{color:var(--ink)}
/* ---- DONEJT (alert) ---- */
.don{position:absolute;left:50%;top:38%;transform:translate(-50%,-50%) scale(.92);width:min(88vw,820px);padding:clamp(18px,2.2vw,32px) clamp(20px,2.6vw,38px);opacity:0;transition:opacity .35s ease,transform .45s cubic-bezier(.2,.9,.3,1.3);pointer-events:none;border-color:rgba(255,255,255,.22)}
.don.show{opacity:1;transform:translate(-50%,-50%) scale(1)}
.don .top{display:flex;align-items:center;gap:.6em}
.don .coin{font-size:clamp(26px,3.4vw,46px)}
.don .nick{font-size:clamp(22px,3.2vw,44px);font-weight:900;line-height:1.05}
.don .amt{margin-left:auto;font-size:clamp(24px,3.6vw,50px);font-weight:900;color:var(--accent2);font-variant-numeric:tabular-nums;white-space:nowrap}
.don .msg{margin-top:.5em;font-size:clamp(18px,2.5vw,34px);font-weight:600;line-height:1.25;text-wrap:pretty}
.don .goal{margin-top:.35em;font-size:clamp(13px,1.5vw,20px);color:var(--muted);font-weight:700;letter-spacing:.08em;text-transform:uppercase}
.don .tag{display:inline-block;margin-top:.6em;padding:.25em .7em;border-radius:999px;background:var(--accent);color:#fff;font-size:clamp(11px,1.2vw,15px);font-weight:800;letter-spacing:.12em;text-transform:uppercase}
/* ---- ODBLOKOWANIE ---- */
.unl{position:absolute;left:50%;top:22%;transform:translate(-50%,-50%) scale(.6);width:min(88vw,800px);padding:clamp(18px,2.4vw,34px);text-align:center;opacity:0;transition:opacity .3s,transform .5s cubic-bezier(.2,.9,.3,1.35);pointer-events:none;border-color:rgba(255,255,255,.25)}
.unl.show{opacity:1;transform:translate(-50%,-50%) scale(1)}
.unl .k{font-size:clamp(14px,1.6vw,22px);letter-spacing:.22em;font-weight:900;color:var(--accent2);text-transform:uppercase}
.unl .t{font-size:clamp(24px,3.8vw,52px);font-weight:900;line-height:1.08;margin-top:.2em;text-wrap:balance}
.unl .s{margin-top:.4em;font-size:clamp(13px,1.5vw,20px);color:var(--muted);font-weight:700}
.unl .burst{position:absolute;inset:0;pointer-events:none;overflow:visible}
.unl .burst i{position:absolute;left:50%;top:50%;width:10px;height:10px;border-radius:50%;background:var(--accent2);opacity:0}
.unl.show .burst i{animation:burst 1.1s ease-out forwards}
@keyframes burst{0%{transform:translate(-50%,-50%);opacity:1}100%{transform:translate(calc(-50% + var(--dx)),calc(-50% + var(--dy))) scale(.2);opacity:0}}
/* ---- ARMATA ---- */
.can{position:absolute;right:clamp(14px,2.4vw,36px);top:50%;transform:translateY(-50%);width:clamp(110px,12vw,170px);padding:clamp(12px,1.4vw,20px) clamp(10px,1.2vw,16px);display:flex;flex-direction:column;align-items:center;gap:.6em}
.can .k{font-size:clamp(10px,1.05vw,14px);letter-spacing:.14em;text-transform:uppercase;font-weight:900;color:var(--muted);text-align:center}
.can .tube{position:relative;width:clamp(44px,4.6vw,64px);height:clamp(220px,30vh,420px);border-radius:999px;background:rgba(255,255,255,.1);border:2px solid var(--line);overflow:hidden}
.can .tube i{position:absolute;left:0;right:0;bottom:0;height:0%;background:linear-gradient(180deg,var(--accent),var(--accent2));transition:height .5s ease;box-shadow:0 0 24px rgba(255,77,141,.5)}
.can .tube:after{content:'🎁';position:absolute;left:50%;bottom:.5em;transform:translateX(-50%);font-size:clamp(18px,2vw,28px)}
.can .n{font-size:clamp(14px,1.6vw,22px);font-weight:900;font-variant-numeric:tabular-nums;text-align:center;line-height:1.1}
.can .n small{display:block;font-size:.6em;color:var(--muted);font-weight:700}
.can .shots{font-size:clamp(11px,1.1vw,15px);color:var(--accent2);font-weight:800}
.can .boom{position:absolute;left:50%;top:-10%;transform:translate(-50%,-50%);font-size:clamp(70px,10vw,150px);opacity:0;pointer-events:none}
.can.fire{animation:shake .5s ease-in-out 3}
.can.fire .boom{animation:boom 2.2s ease-out forwards}
.can.fire .tube i{box-shadow:0 0 60px var(--accent2)}
@keyframes shake{0%,100%{transform:translateY(-50%) rotate(0)}25%{transform:translateY(-50%) rotate(-3deg)}75%{transform:translateY(-50%) rotate(3deg)}}
@keyframes boom{0%{opacity:0;transform:translate(-50%,-50%) scale(.2)}15%{opacity:1;transform:translate(-50%,-80%) scale(1.2)}100%{opacity:0;transform:translate(-50%,-160%) scale(1.6)}}
.can .conf{position:absolute;inset:0;pointer-events:none;overflow:visible}
.can .conf i{position:absolute;left:50%;top:0;width:8px;height:14px;background:var(--accent2);opacity:0;border-radius:2px}
.can.fire .conf i{animation:conf 1.8s ease-out forwards}
.can .conf i:nth-child(odd){background:var(--accent)}
@keyframes conf{0%{transform:translate(-50%,0) rotate(0);opacity:1}100%{transform:translate(calc(-50% + var(--dx)),var(--dy)) rotate(720deg);opacity:0}}
.can .fired{position:absolute;left:50%;top:-2.4em;transform:translateX(-50%);white-space:nowrap;font-size:clamp(12px,1.3vw,18px);font-weight:900;color:var(--accent2);opacity:0}
.can.fire .fired{animation:firedTxt 2.4s ease-out forwards}
@keyframes firedTxt{0%{opacity:0;transform:translate(-50%,0)}20%{opacity:1;transform:translate(-50%,-.4em)}100%{opacity:0;transform:translate(-50%,-1.2em)}}
/* ---- RANKING (ticker, z KVRINA_SHOW) ---- */
:root{--promo-h:clamp(40px,4.2vh,64px)}
.ticker-wrap{width:100vw;height:100vh;display:flex;align-items:flex-end;overflow:hidden;position:relative;padding:0 0 calc(max(26px,2.6vh) + var(--promo-h));background:transparent}
.ticker{position:relative;z-index:2;display:flex;align-items:center;gap:clamp(14px,1.6vw,26px);white-space:nowrap;width:max-content;min-width:max-content;will-change:transform;transform:translateX(0)}
.ticker.is-scrolling{animation-name:ticker;animation-duration:var(--ticker-duration,78s);animation-timing-function:linear;animation-fill-mode:forwards}
.tick{display:inline-flex;align-items:center;gap:clamp(8px,1vw,16px);padding:clamp(10px,1.25vw,20px) clamp(18px,2.2vw,34px);border-radius:999px;border:1px solid var(--line);background:var(--glass);box-shadow:0 6px 22px rgba(0,0,0,.3);font-size:clamp(22px,3.4vw,46px);line-height:1;font-weight:900}
.tick .heart{color:var(--accent);font-size:1.08em}
.tick .place{color:#111;background:linear-gradient(135deg,var(--accent2),var(--accent));border-radius:999px;padding:.16em .46em;font-size:.58em;font-weight:950}
.tick .points{color:var(--accent2);font-weight:950;font-variant-numeric:tabular-nums}
.tick .unit{color:var(--muted);font-size:.52em;font-weight:900;letter-spacing:.1em;text-transform:uppercase}
.ticker-empty{opacity:.82}
.ticker-note{position:absolute;left:22px;bottom:calc(max(26px,2.6vh) + var(--promo-h) + clamp(94px,8.2vw,138px) + 10px);z-index:3;padding:7px 13px;border-radius:999px;background:var(--glass);border:1px solid var(--line);color:var(--accent2);font-size:clamp(11px,1.4vw,18px);letter-spacing:.12em;text-transform:uppercase;font-weight:950}
.ticker-note-top1{color:#fff;background:linear-gradient(135deg,var(--accent),var(--accent2));border-color:rgba(255,255,255,.5)}
@keyframes ticker{from{transform:translateX(var(--from-x,100vw))}to{transform:translateX(var(--to-x,calc(-100% - 48px)))}}
.promo-lane{position:absolute;left:0;right:0;bottom:max(26px,2.6vh);height:var(--promo-h);overflow:hidden;z-index:4;pointer-events:none}
.promo-tile{position:absolute;top:50%;left:0;white-space:nowrap;display:inline-flex;align-items:center;gap:clamp(8px,1vw,16px);padding:clamp(5px,.8vh,11px) clamp(16px,2vw,30px);border-radius:999px;border:1px solid rgba(255,255,255,.6);background:linear-gradient(135deg,var(--accent),var(--accent2));box-shadow:0 0 30px rgba(0,0,0,.35),inset 0 1px 0 rgba(255,255,255,.3);font-size:clamp(15px,2.2vw,30px);font-weight:900;line-height:1;color:#fff;text-shadow:0 2px 6px rgba(0,0,0,.35);transform:translate(100vw,-50%)}
.promo-tile:nth-child(even){background:linear-gradient(135deg,#4b2ea8,#7e5ae6 62%,#a98bff)}
.promo-tile.is-running{animation:promoPass var(--promo-dur,16s) linear}
@keyframes promoPass{from{transform:translate(100vw,-50%)}to{transform:translate(calc(-100% - 40px),-50%)}}
/* ---- DEMO GRID ---- */
.demo{display:grid;grid-template-columns:repeat(auto-fit,minmax(300px,1fr));gap:12px;padding:12px;background:#1a1d2e;min-height:100vh}
.demo .cell{background:#0f1220;border:1px solid #2a2f45;border-radius:12px;overflow:hidden;aspect-ratio:9/16;position:relative}
.demo .cell h4{margin:0;padding:6px 10px;font:800 12px/1 system-ui;color:#cfd3e6;letter-spacing:.1em;text-transform:uppercase;background:#171b2e}
.demo iframe{width:100%;height:calc(100% - 24px);border:0;background:#242842}
/* ---- COMBO ---- */
.combo{position:relative;width:1080px;height:1920px;overflow:hidden;transform-origin:top left}
.combo iframe{position:absolute;left:0;top:0;width:1080px;height:1920px;border:0;background:transparent;transform-origin:top left;pointer-events:none}
`;

const COMBO_PARTS = ["playlista", "tapy", "donejt", "armata", "odblokowanie", "ranking"];
const COMBO_DEFAULT_LAYOUT = {};
for (const k of COMBO_PARTS) COMBO_DEFAULT_LAYOUT[k] = { x: 0, y: 0, scale: 1, enabled: true };

function page(body, script, title) {
  return `<!DOCTYPE html><html lang="pl"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>${title || "SING_SHOW widget"}</title><style>${CSS}</style></head><body>${body}<script>${SHARED_SCRIPT}${script}</script></body></html>`;
}

function widgetHtml(kind) {
  let body = "", script = "";
  if (kind === "playlista") {
    body = `<div class="layer"><div class="glass pl" id="card">
<div class="lbl acc">♫ Teraz śpiewam</div><div class="now-title" id="nowT">—</div><div class="now-artist" id="nowA"></div>
<div class="sep"></div>
<div class="lbl" id="nextL">Następna</div><div class="next-title" id="nextT">—</div>
<div id="barWrap"><div class="bar"><i id="barFill"></i></div><div class="meta"><span><span class="heart">♥</span> <span class="big" id="tp">0</span> / <span id="tt">500</span> tapów</span><span id="left">odblokuj tapami</span></div></div>
<div class="queue" id="queue"></div><div class="orders" id="orders"></div></div></div>`;
    script = `
var lastSig='';
function render(s){
  var song=s.song||{}, taps=s.taps||{};
  var sig=JSON.stringify([song.now,song.next,song.queue,song.ordered,taps.progress,taps.threshold]);
  if(sig===lastSig) return; lastSig=sig;
  var now=song.now, next=song.next;
  document.getElementById('nowT').innerHTML=now?esc(now.title):'<span class="empty">Czekam na start playlisty…</span>';
  document.getElementById('nowA').textContent=now&&now.artist?now.artist:'';
  var nt=document.getElementById('nextT'), nl=document.getElementById('nextL'), bw=document.getElementById('barWrap');
  if(next){
    nt.textContent=(next.artist?next.artist+' – ':'')+next.title;
    var unl=next.status==='unlocked'||next.status==='now';
    nt.classList.toggle('unlocked',unl);
    nl.textContent=unl?'Następna ✓ odblokowana':'Następna — odblokuj tapami';
    bw.style.display=unl?'none':'';
  } else { nt.textContent='— koniec playlisty —'; nl.textContent='Następna'; bw.style.display='none'; }
  var p=Number(taps.progress)||0, t=Math.max(1,Number(taps.threshold)||1);
  document.getElementById('barFill').style.width=Math.min(100,Math.round(p/t*100))+'%';
  document.getElementById('tp').textContent=p.toLocaleString('pl-PL'); document.getElementById('tt').textContent=t.toLocaleString('pl-PL');
  document.getElementById('left').textContent=(p>=t)?'odblokowana!':('brakuje '+(t-p).toLocaleString('pl-PL')+' ♥');
  var q=(song.queue||[]).slice(0,5);
  document.getElementById('queue').innerHTML=q.map(function(it){var u=it.status==='unlocked';return '<div class="q '+(u?'unlocked':'')+'"><span class="lock">'+(u?'✓':'🔒')+'</span><span>'+songLabel(it)+'</span></div>';}).join('');
  var o=(song.ordered||[]).slice(0,4);
  document.getElementById('orders').innerHTML=o.length?('<div class="lbl acc" style="margin-bottom:.2em">★ Zamówione</div>'+o.map(function(it){return '<div class="o"><span class="star">★</span><span>'+songLabel(it)+'</span><span class="amt">'+fmtPln(it.order&&it.order.amount)+'</span><span class="by">'+esc(it.order&&it.order.by||'')+'</span></div>';}).join('')):'';
}
async function loop(){render(await getState())} loop(); setInterval(loop,1000);`;
  } else if (kind === "tapy") {
    body = `<div class="layer"><div class="glass tapbar"><div class="row"><span class="heart">♥</span><div class="bar"><i id="fill"></i></div><span class="num"><b id="p">0</b> / <span id="t">500</span></span></div><div class="sub" id="sub">Tapuj — odblokuj następną piosenkę</div></div></div>`;
    script = `
var last='';
function render(s){var taps=s.taps||{},next=(s.song||{}).next;var p=Number(taps.progress)||0,t=Math.max(1,Number(taps.threshold)||1);
var sig=p+'|'+t+'|'+(next?next.title+next.status:'');if(sig===last)return;last=sig;
document.getElementById('fill').style.width=Math.min(100,Math.round(p/t*100))+'%';document.getElementById('p').textContent=p.toLocaleString('pl-PL');document.getElementById('t').textContent=t.toLocaleString('pl-PL');
var sub=document.getElementById('sub');
if(!next) sub.innerHTML='Tapuj ♥ — koniec playlisty, dzięki!';
else if(next.status==='unlocked') sub.innerHTML='Następna: <strong>'+songLabel(next)+'</strong> ✓ odblokowana';
else sub.innerHTML='Tapuj, żeby odblokować: <strong>'+songLabel(next)+'</strong>';}
async function loop(){render(await getState())} loop(); setInterval(loop,700);`;
  } else if (kind === "donejt") {
    body = `<div class="layer"><div class="glass don" id="don"><div class="top"><span class="coin">💸</span><span class="nick" id="nick"></span><span class="amt" id="amt"></span></div><div class="msg" id="msg"></div><div class="goal" id="goal"></div><span class="tag" id="tag" style="display:none">★ zamówienie piosenki</span></div></div>`;
    script = `
var shownId=null;
function render(s){var d=(s.donations||{}).alert; var el=document.getElementById('don'); var secs=Number((s.donations||{}).alertSeconds)||8;
if(!d||!d.at||Date.now()-d.at>secs*1000){el.classList.remove('show');shownId=null;return;}
if(shownId!==d.id+'|'+d.at){shownId=d.id+'|'+d.at;document.getElementById('nick').textContent=d.nick||'Ktoś';document.getElementById('amt').textContent=fmtPln(d.amount);document.getElementById('msg').textContent=d.message||'';document.getElementById('goal').textContent=d.goal?('na: '+d.goal):'';document.getElementById('tag').style.display=d.order?'':'none';}
el.classList.add('show');}
async function loop(){render(await getState())} loop(); setInterval(loop,600);`;
  } else if (kind === "odblokowanie") {
    const dots = Array.from({ length: 18 }, (_, i) => { const a = (i / 18) * Math.PI * 2; const r = 180 + (i % 3) * 60; return `<i style="--dx:${Math.round(Math.cos(a) * r)}px;--dy:${Math.round(Math.sin(a) * r)}px"></i>`; }).join("");
    body = `<div class="layer"><div class="glass unl" id="unl"><div class="burst">${dots}</div><div class="k">✓ Odblokowano piosenkę</div><div class="t" id="t"></div><div class="s" id="s"></div></div></div>`;
    script = `
var lastAt=0;
function render(s){var u=s.unlock||{};var el=document.getElementById('unl');
if(!u.lastAt||Date.now()-u.lastAt>4500){el.classList.remove('show');return;}
if(u.lastAt!==lastAt){lastAt=u.lastAt;document.getElementById('t').textContent=(u.artist?u.artist+' – ':'')+(u.title||'');document.getElementById('s').textContent=u.by?('dzięki: '+u.by):'dzięki za tapy ♥';el.classList.remove('show');void el.offsetWidth;}
el.classList.add('show');}
async function loop(){render(await getState())} loop(); setInterval(loop,500);`;
  } else if (kind === "armata") {
    const conf = Array.from({ length: 24 }, (_, i) => `<i style="--dx:${Math.round((Math.random() - .5) * 520)}px;--dy:${Math.round(-120 - Math.random() * 520)}px;animation-delay:${(i % 6) * 60}ms"></i>`).join("");
    body = `<div class="layer"><div class="glass can" id="can"><div class="boom">💥</div><div class="conf">${conf}</div><div class="fired" id="fired">WYSTRZAŁ!</div><div class="k" id="k">Armata giftów</div><div class="tube"><i id="fill"></i></div><div class="n"><span id="c">0</span><small>/ <span id="t">1000</span> monet</small></div><div class="shots" id="shots"></div></div></div>`;
    script = `
var lastFire=0,last='';
function render(s){var c=s.cannon||{};var el=document.getElementById('can');
if(c.enabled===false){el.style.display='none';return;} el.style.display='';
var ch=Number(c.charge)||0,t=Math.max(1,Number(c.threshold)||1);
var sig=ch+'|'+t+'|'+(c.shots||0)+'|'+(c.label||'');
if(sig!==last){last=sig;document.getElementById('fill').style.height=Math.min(100,Math.round(ch/t*100))+'%';document.getElementById('c').textContent=ch.toLocaleString('pl-PL');document.getElementById('t').textContent=t.toLocaleString('pl-PL');document.getElementById('shots').textContent=c.shots?('wystrzałów: '+c.shots):'';document.getElementById('k').textContent=c.label||'Armata giftów';}
if(c.fireAt&&c.fireAt!==lastFire&&Date.now()-c.fireAt<3000){lastFire=c.fireAt;document.getElementById('fired').textContent='WYSTRZAŁ!'+(c.lastBy?' dzięki '+c.lastBy:'');el.classList.remove('fire');void el.offsetWidth;el.classList.add('fire');setTimeout(function(){el.classList.remove('fire')},2600);}}
async function loop(){render(await getState())} loop(); setInterval(loop,600);`;
  } else if (kind === "ranking") {
    body = `<div class="ticker-wrap"><div class="ticker-note">Ranking widzów ♥</div><div id="root"></div><div class="promo-lane" id="promoLane"></div></div>`;
    script = `
var lastRankingSignature='',pendingRankingHtml=null,pendingRankingEmpty=false,tickerRunning=false,currentTickerEmpty=true;
var TICKER_SPEED_PX_PER_SEC=28,TICKER_MIN_DURATION_MS=58000,TICKER_MAX_DURATION_MS=210000,tickerScrollTimer=null;
function itemsToHtml(items){return '<div id="ticker" class="ticker">'+items.map(function(it,i){var likes=Number(it.points!=null?it.points:it.likes)||0;var empty=it.empty?' ticker-empty':'';return '<div class="tick'+empty+'"><span class="place">#'+(i+1)+'</span><span class="heart">♥</span><strong>'+esc(it.nick||'-')+'</strong><span class="points">'+esc(likes)+'</span><span class="unit">pkt</span></div>';}).join('')+'</div>';}
function buildRankingTicker(s){var r=(s.ranking||[]).filter(Boolean);var isEmpty=!r.length;var items=r.length?r:[{nick:'Czekam na widzów',points:0,empty:true}];
var sig=JSON.stringify(items.map(function(it){return {n:it.nick||'',p:Number(it.points)||0,e:!!it.empty};}));
if(sig===lastRankingSignature){if(!tickerRunning)startTicker();return;}
lastRankingSignature=sig;var html=itemsToHtml(items);
if(!tickerRunning||currentTickerEmpty||isEmpty){document.getElementById('root').innerHTML=html;currentTickerEmpty=isEmpty;pendingRankingHtml=null;startTicker();}else{pendingRankingHtml=html;pendingRankingEmpty=isEmpty;}}
function startTicker(){var ticker=document.getElementById('ticker');if(!ticker){tickerRunning=false;return;}if(tickerScrollTimer)clearTimeout(tickerScrollTimer);
var winW=Math.max(1,window.innerWidth||1080);var trackW=Math.max(1,ticker.scrollWidth||1);var fromX=winW+48,toX=-(trackW+48);var distance=fromX-toX;
var durationMs=Math.max(TICKER_MIN_DURATION_MS,Math.min(TICKER_MAX_DURATION_MS,Math.round((distance/TICKER_SPEED_PX_PER_SEC)*1000)));
tickerRunning=true;ticker.classList.remove('is-scrolling');ticker.style.setProperty('--from-x',fromX+'px');ticker.style.setProperty('--to-x',toX+'px');ticker.style.setProperty('--ticker-duration',durationMs+'ms');ticker.style.transform='translateX('+fromX+'px)';void ticker.offsetWidth;ticker.classList.add('is-scrolling');
tickerScrollTimer=setTimeout(function(){tickerRunning=false;if(pendingRankingHtml!==null){document.getElementById('root').innerHTML=pendingRankingHtml;currentTickerEmpty=pendingRankingEmpty;pendingRankingHtml=null;}startTicker();},durationMs+120);}
function restartTickerScroll(){if(tickerScrollTimer)clearTimeout(tickerScrollTimer);tickerRunning=false;startTicker();}
function updateRankingNote(s){var note=document.querySelector('.ticker-note');var c=s&&s.top1;if(c&&c.nick){note.textContent='⭐ TOP 1: '+c.nick+' → '+(c.label||'DEDYKACJA');note.classList.add('ticker-note-top1');}else{note.textContent='Ranking widzów ♥';note.classList.remove('ticker-note-top1');}}
var PROMO_PASS_MS=16000,lastPromoAt=0,promoIdx=0,promoSig='';
function ensurePromo(s){var texts=((s.texts||{}).promo||[]).filter(Boolean);var sig=JSON.stringify(texts);if(sig===promoSig)return;promoSig=sig;var lane=document.getElementById('promoLane');lane.innerHTML=texts.map(function(t){return '<div class="promo-tile"><span>♥</span><strong>'+esc(t)+'</strong></div>';}).join('');}
function maybeRunPromo(){var lane=document.getElementById('promoLane');var tiles=lane.querySelectorAll('.promo-tile');if(!tiles.length)return;var now=Date.now();if(now-lastPromoAt<PROMO_PASS_MS)return;lastPromoAt=now;var tile=tiles[promoIdx%tiles.length];promoIdx++;tile.style.setProperty('--promo-dur',PROMO_PASS_MS+'ms');tile.classList.remove('is-running');void tile.offsetWidth;tile.classList.add('is-running');tile.addEventListener('animationend',function(){tile.classList.remove('is-running')},{once:true});}
function render(s){buildRankingTicker(s);updateRankingNote(s);ensurePromo(s);maybeRunPromo();}
async function loop(){render(await getState())} loop(); setInterval(loop,1600); window.addEventListener('resize',restartTickerScroll);`;
  } else if (kind === "wszystko") {
    body = `<div class="combo" id="combo">${COMBO_PARTS.map((p) => `<iframe data-part="${p}" src="/widget-${p}.html"></iframe>`).join("")}</div>`;
    script = `
function fit(){var sx=window.innerWidth/1080,sy=window.innerHeight/1920;var sc=Math.min(sx,sy);var c=document.getElementById('combo');c.style.transform='scale('+sc+')';c.style.left=Math.round((window.innerWidth-1080*sc)/2)+'px';c.style.position='absolute';}
var lastLayout='';
function applyLayout(s){var L=(s&&s.comboLayout)||{};var sig=JSON.stringify(L);if(sig===lastLayout)return;lastLayout=sig;
document.querySelectorAll('iframe[data-part]').forEach(function(f){var p=f.getAttribute('data-part');var l=L[p]||{x:0,y:0,scale:1,enabled:true};f.style.display=l.enabled===false?'none':'';f.style.transform='translate('+(l.x||0)+'px,'+(l.y||0)+'px) scale('+(l.scale||1)+')';});}
async function loop(){applyLayout(await getState())} fit(); loop(); setInterval(loop,1000); window.addEventListener('resize',fit);`;
  }
  return page(body, script, "SING_SHOW — " + kind);
}

function demoHtml(port) {
  const kinds = ["wszystko", "playlista", "tapy", "donejt", "odblokowanie", "armata", "ranking"];
  return `<!DOCTYPE html><html lang="pl"><head><meta charset="UTF-8"><title>SING_SHOW — podgląd widgetów</title><style>${CSS}</style></head><body><div class="demo">${kinds.map((k) => `<div class="cell"><h4>${k}</h4><iframe src="http://127.0.0.1:${port}/widget-${k}.html"></iframe></div>`).join("")}</div></body></html>`;
}

function pilotHtml() {
  return `<!DOCTYPE html><html lang="pl"><head><meta charset="UTF-8"><title>SING_SHOW — pilot</title><style>
body{margin:0;background:#0f1220;color:#f3f4fb;font-family:system-ui,-apple-system,sans-serif;padding:12px}
.row{display:flex;gap:8px;flex-wrap:wrap;margin-bottom:10px}
button{flex:1;min-width:90px;padding:14px 10px;border:0;border-radius:10px;font-weight:900;font-size:15px;color:#fff;cursor:pointer;letter-spacing:.06em}
.g{background:#21a366}.o{background:#e08a1e}.r{background:#c9354a}.p{background:#ff4d8d}.b{background:#3a4470}
.now{font-size:14px;color:#cfd3e6;margin:6px 0 12px}.now b{color:#fff}
.don{font-size:13px;color:#ffd166;margin-top:4px}
</style></head><body>
<div class="now">Teraz: <b id="now">—</b><br>Następna: <b id="next">—</b><div class="don" id="don"></div></div>
<div class="row"><button class="r" onclick="go('prev')">← WSTECZ</button><button class="o" onclick="go('skip')">POMIŃ</button><button class="g" onclick="go('next')">DALEJ →</button></div>
<div class="row"><button class="b" onclick="go('unlock')">ODBLOKUJ RĘCZNIE</button><button class="p" onclick="go('read')">PRZECZYTANE ✓</button></div>
<script>
function go(a){fetch('/pilot/'+a).catch(function(){})}
async function loop(){try{var s=await (await fetch('/widget_state_slim.json?ts='+Date.now(),{cache:'no-store'})).json();var so=s.song||{};
document.getElementById('now').textContent=so.now?((so.now.artist?so.now.artist+' – ':'')+so.now.title):'—';
document.getElementById('next').textContent=so.next?((so.next.artist?so.next.artist+' – ':'')+so.next.title+(so.next.status==='unlocked'?' ✓':' 🔒')):'—';
var d=(s.donations||{}).current;document.getElementById('don').textContent=d?('Do przeczytania: '+d.nick+' '+(d.amount||0)+' zł — '+(d.message||'')):'';}catch(e){}}
loop();setInterval(loop,1000);
</script></body></html>`;
}

module.exports = { widgetHtml, demoHtml, pilotHtml, COMBO_PARTS, COMBO_DEFAULT_LAYOUT };
