// Wspólne drobiazgi paneli SING_SHOW.
window.PC = (() => {
  const $ = (id) => document.getElementById(id);
  const esc = (s) => String(s == null ? "" : s).replace(/[&<>"']/g, (m) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[m]));
  const pln = (n) => { n = Number(n) || 0; return n.toLocaleString("pl-PL", { minimumFractionDigits: n % 1 ? 2 : 0, maximumFractionDigits: 2 }) + " zł"; };
  const label = (it) => (it.artist ? esc(it.artist) + " – " : "") + esc(it.title || "");
  const fmtTime = (ts) => { try { return new Date(ts).toLocaleTimeString("pl-PL", { hour: "2-digit", minute: "2-digit", second: "2-digit" }); } catch { return ""; } };
  let toastT = null;
  function toast(t) { let el = $("toast"); if (!el) { el = document.createElement("div"); el.id = "toast"; el.className = "toast"; document.body.appendChild(el); } el.textContent = t; el.classList.add("show"); clearTimeout(toastT); toastT = setTimeout(() => el.classList.remove("show"), 1800); }
  function debounce(fn, ms) { let t = null; return (...a) => { clearTimeout(t); t = setTimeout(() => fn(...a), ms); }; }
  // Zapis pola do profilu: data-path="tipped.readThreshold", data-type="number|bool|text|list"
  function bindProfileFields(root, getProfile, onSaved) {
    const els = (root || document).querySelectorAll("[data-path]");
    const save = debounce(async (patch) => { const p = await window.api.profileUpdate(patch); if (onSaved) onSaved(p); toast("Zapisano"); }, 350);
    els.forEach((el) => {
      const ev = el.type === "checkbox" || el.tagName === "SELECT" || el.type === "color" || el.type === "range" ? "change" : "input";
      el.addEventListener(ev, () => {
        const path = el.dataset.path.split("."); const type = el.dataset.type || (el.type === "checkbox" ? "bool" : el.type === "number" || el.type === "range" ? "number" : "text");
        let v = type === "bool" ? el.checked : type === "number" ? Number(el.value) : type === "list" ? el.value.split("\n").map((s) => s.trim()).filter(Boolean) : el.value;
        const patch = {}; let cur = patch; for (let i = 0; i < path.length - 1; i++) { cur[path[i]] = {}; cur = cur[path[i]]; } cur[path[path.length - 1]] = v;
        if (el.type === "range" && el.dataset.out) { const o = $(el.dataset.out); if (o) o.textContent = el.value; }
        save(patch);
      });
    });
  }
  function fillProfileFields(root, profile) {
    (root || document).querySelectorAll("[data-path]").forEach((el) => {
      const v = el.dataset.path.split(".").reduce((o, k) => (o && o[k] !== undefined ? o[k] : undefined), profile);
      if (v === undefined) return;
      const type = el.dataset.type || (el.type === "checkbox" ? "bool" : "text");
      if (type === "bool") el.checked = !!v; else if (type === "list") el.value = (Array.isArray(v) ? v : []).join("\n"); else el.value = v;
      if (el.type === "range" && el.dataset.out) { const o = $(el.dataset.out); if (o) o.textContent = el.value; }
    });
  }
  function head(title, extraHtml) {
    return `<div class="panel-head"><h1>${esc(title)}</h1><span class="sp"></span>${extraHtml || ""}<div class="zoombtns"><button class="btn tiny" id="panel-zoom-minus">−</button><button class="btn tiny" id="panel-zoom-plus">+</button></div></div>`;
  }
  document.addEventListener("keydown", (e) => { if (e.key === "Escape" && !e.target.matches("input,textarea,select")) window.close(); });
  return { $, esc, pln, label, fmtTime, toast, debounce, bindProfileFields, fillProfileFields, head };
})();
